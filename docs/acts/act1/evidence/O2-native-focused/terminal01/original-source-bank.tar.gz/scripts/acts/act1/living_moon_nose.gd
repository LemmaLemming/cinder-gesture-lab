class_name CinderAct1LivingMoonNose
extends Node3D
## B02's actual stationary nose source; one fixed world cone per cycle.
## Uses the public shared Scheduler, Geometry and ThreatCue, never Lane's
## unsupported cone path. The parent owns boss HP/eye opening and phase order.
## Parent artwork reads state_changed; nose/source coordinates do not animate.
## Raw numbers below are conservative provisional greybox tuning, not balance.
## Public paired transport retains sampled Hero paths/dedupes without retiming.

signal state_changed(nose_state: Dictionary)
signal hit_resolved(hero_id: String, cycle: int, result: Dictionary)

const Geometry = preload("res://scripts/combat/threat_geometry.gd")
const Difficulty = preload("res://scripts/combat/difficulty.gd")
const Codec = preload("res://scripts/campaign/snapshot_codec.gd")
const CueScript = preload("res://scripts/cues/threat_cue.gd")
const API_REVISION: String = "act1-living-moon-nose-1"
const SchedulerScript = preload("res://scripts/combat/threat_scheduler.gd")
const PlayerScript = preload("res://scripts/player.gd")
const Motion = preload("res://scripts/combat/lunge_motion.gd")
const BodySweep = preload("res://scripts/combat/body_sweep.gd")
const HERO_ID: String = "hero"
const CONE_KEYS: Array[String] = ["kind", "origin", "direction", "reach", "min_dot", "origin_radius"]
# Role transport requires positive max_hp; this compatibility field creates
# no health component. A genuine zero approach speed denotes this fixed source.
const DEFAULT_RAW_ROLE: Dictionary = {"raw_damage": 8.0, "windup_s": 2.2, "lock_s": 1.0, "active_s": 0.22, "recovery_s": 2.6, "attack_interval_s": 2.8, "max_hp": 1.0, "move_speed": 0.0}
const DEFAULT_TIMING_FLOORS: Dictionary = {"windup_s": 2.2, "lock_s": 1.0, "recovery_s": 2.6}
const EXCHANGE_KEYS: Array[String] = ["id", "source_position", "geometry", "opening_position", "start_s", "lock_from_s", "active_from_s", "active_until_s", "recovery_until_s", "cooldown_until_s", "profile_id", "world_revision"]
const RESPONSE_KEYS: Array[String] = ["encounter_id", "world_revision", "recognition_s", "attack_input_margin_s", "escape_directions", "return_directions", "floor_regions"]
const MAX_PENDING_SEGMENTS: int = 256

var last_error: String = ""
var last_snapshot_error: String = ""
var _configured: bool = false
var _configuration: Dictionary = {}
var _scheduler: CinderThreatScheduler
var _world_root: Node3D
var _opening_owner: Node3D
var _native_parents: Dictionary = {}
var _native_scripts: Dictionary = {}
var _source_transform: Transform3D
var _opening_transform: Transform3D
var _hero_collision: CollisionShape3D
var _hero_capsule: CapsuleShape3D
var _hero_signature: Dictionary = {}
var _heroes: Dictionary = {}
var _cue: CinderThreatCue
var _status: String = "idle"
var _phase: String = "clear"
var _cycle: int = 0
var _resolved_role: Dictionary = {}
var _exchange: Dictionary = {}
var _exchange_encounter_id: String = ""
var _samples: Dictionary = {}
var _hit_ids: Dictionary = {}
var _pending_segments: Dictionary = {}
var _last_cancel_reason: String = ""
var _transaction_depth: int = 0
var _snapshot_busy: bool = false
var _cancelling: bool = false
var _presentation_guard: Callable = Callable()
var _presentation_guard_required: bool = false
var _presentation_guard_busy: bool = false
var _presentation_guard_invalidated: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	# Scheduler/hero default priority is zero. Sample their completed physics
	# tick and its clock together, independent of authored tree ordering.
	process_physics_priority = 100
	_cue = CueScript.new()
	_cue.name = "ThreatCue"
	add_child(_cue)


func configure(source_id: String, cone: Dictionary, opening_position: Vector3, raw_role: Dictionary = DEFAULT_RAW_ROLE, timing_floors: Dictionary = DEFAULT_TIMING_FLOORS) -> bool:
	if _transaction_depth > 0 or _snapshot_busy or is_instance_valid(_scheduler):
		return _reject("Configure immutable nose data before binding")
	if not _stable_id(source_id) or not Codec.keys_error(cone, CONE_KEYS).is_empty() or cone.get("kind") != "cone" or not Geometry.error(cone).is_empty() or not Geometry.finite_vector(opening_position):
		return _reject("Stable source ID, exact finite cone and actual eye opening position required")
	if not Codec.keys_error(raw_role, DEFAULT_RAW_ROLE.keys()).is_empty() or not Codec.value_error(raw_role).is_empty() or not Codec.keys_error(timing_floors, DEFAULT_TIMING_FLOORS.keys()).is_empty() or not Codec.value_error(timing_floors).is_empty() or raw_role.get("move_speed") != 0.0 or raw_role.get("max_hp") != 1.0:
		return _reject("Stationary raw role/timing schema required; max_hp=1 is compatibility data, not boss health")
	var difficulty = Difficulty.new()
	if difficulty.resolve_role(raw_role, "standard", timing_floors).is_empty():
		return _reject(difficulty.last_error)
	var next: Dictionary = {"source_id": source_id, "geometry": _copy_geometry(cone), "opening_position": opening_position, "raw_role": raw_role.duplicate(true), "timing_floors": timing_floors.duplicate(true)}
	if _configured and next != _configuration:
		return _reject("Configured raw nose data is immutable")
	_configuration = next
	_configured = true
	last_error = ""
	return true


func bind(scheduler: CinderThreatScheduler, hero: CinderPlayer, world_root: Node3D, opening_owner: Node3D = null) -> bool:
	## Bind the actual stationary eye receiver too. Caller world points alone
	## cannot substitute for the one boss body/ordinary-primary opening.
	if not is_inside_tree() or not is_node_ready() or not _configured or _transaction_depth > 0 or _snapshot_busy:
		return _reject("Bind a ready configured nose outside callbacks")
	if not is_instance_valid(world_root) or not world_root.is_inside_tree() or world_root.is_queued_for_deletion():
		return _reject("Actual containing native world root required")
	for node: Node3D in [scheduler, hero, world_root, opening_owner]:
		if not is_instance_valid(node) or not node.is_inside_tree() or not node.is_node_ready() or node.is_queued_for_deletion() or node.get_world_3d() != get_world_3d():
			return _reject("Actual live same-world Scheduler/Hero/world/eye receiver required")
		if world_root != node and not world_root.is_ancestor_of(node):
			return _reject("Actual world must contain the Scheduler, Hero and eye receiver")
	if not world_root.is_ancestor_of(self) or scheduler.get_script() != SchedulerScript or hero.get_script() != PlayerScript or scheduler.process_physics_priority >= process_physics_priority or hero.process_physics_priority >= process_physics_priority:
		return _reject("Retain canonical earlier-physics Scheduler/Hero and actual contained source")
	if global_position != _configuration.geometry.origin or opening_owner.global_position != _configuration.opening_position or not _finite_transform(global_transform) or not _finite_transform(opening_owner.global_transform):
		return _reject("Configured source/eye opening must match their actual native positions")
	if opening_owner is CharacterBody3D and (opening_owner as CharacterBody3D).velocity != Vector3.ZERO:
		return _reject("The actual eye opening must be stationary")
	var description: Dictionary = Motion.source_description(hero)
	if description.has("error") or BodySweep.source_description(hero).has("error"):
		return _reject("Actual shared Hero collision/support contract required")
	if is_instance_valid(_scheduler):
		return true if _scheduler == scheduler and _heroes == {HERO_ID: hero} and _world_root == world_root and _opening_owner == opening_owner and _native_binding_error().is_empty() else _reject("Nose native bindings are immutable")
	_scheduler = scheduler
	_heroes = {HERO_ID: hero}
	_world_root = world_root
	_opening_owner = opening_owner
	_source_transform = global_transform
	_opening_transform = opening_owner.global_transform
	_hero_collision = description.collision
	_hero_capsule = _hero_collision.shape as CapsuleShape3D
	_hero_signature = description.signature.duplicate(true)
	for key: String in ["source", "scheduler", "hero", "world", "eye", "cue"]:
		var node: Node3D = {"source": self, "scheduler": _scheduler, "hero": hero, "world": _world_root, "eye": _opening_owner, "cue": _cue}[key]
		_native_parents[key] = weakref(node.get_parent())
		_native_scripts[key] = node.get_script()
	_scheduler.reservation_invalidated.connect(_on_invalidated)
	last_error = ""
	return true


func set_presentation_guard(provider: Callable) -> bool:
	## One-shot ephemeral parent custody. Bind before the first cycle, including
	## fresh paused restore recipients. Never serialized or called by codecs.
	## provider(source_id: String, current_state: Dictionary) -> bool;
	## it may synchronously pause/cancel, but must not yield or mutate authority.
	if not _live_bindings() or _transaction_depth > 0 or _snapshot_busy or _cancelling or _presentation_guard_busy or _cycle != 0 or _status != "idle" or _presentation_guard_required or not provider.is_valid() or provider.get_argument_count() != 2:
		return _reject("Bind one valid current-view parent presentation guard before the first cycle outside callbacks")
	_presentation_guard = provider
	_presentation_guard_required = true
	last_error = ""
	return true


func start(response_context: Dictionary, opening_position: Variant = null, bearing: Variant = null, preview: Dictionary = {}) -> Dictionary:
	var hero_id: String = HERO_ID
	last_error = ""
	if _transaction_depth > 0 or _snapshot_busy or _cancelling or not _live_bindings() or not _presentation_guard_required or not _presentation_guard.is_valid() or _status == "running" or get_tree().paused or not is_visible_in_tree() or not _cue.is_visible_in_tree() or _cycle >= Codec.MAX_SAFE_INTEGER:
		return _denied("Start requires an idle retained unpaused nose and bound current-view guard outside callbacks")
	if not _heroes.has(hero_id) or not Codec.keys_error(response_context, RESPONSE_KEYS).is_empty() or not _stable_id(response_context.get("encounter_id")):
		return _denied("Authored encounter epoch, floor and finite response candidates required")
	var current_control: Dictionary = _scheduler.source_control_state(self)
	if response_context.encounter_id != current_control.get("encounter_id") or response_context.world_revision != current_control.get("world_revision"):
		return _denied("The nose must use the actual current shared encounter epoch")
	if global_position != _configuration.geometry.origin:
		return _denied("The actual stationary nose must remain at its configured cone origin")
	if opening_position != null and (not Geometry.finite_vector(opening_position) or opening_position != _opening_owner.global_position):
		return _denied("Per-cycle eye opening must be the actual retained finite world position")
	# The eye receiver remains the same real body throughout this attack.
	# The parent owns its exposure/HP; an arbitrary distant point cannot replace it.
	var cycle_opening: Vector3 = _configuration.opening_position if opening_position == null else opening_position
	var difficulty = Difficulty.new()
	var profile: Dictionary = _scheduler.encounter_profile()
	var resolved: Dictionary = difficulty.resolve_role(_configuration.raw_role, String(profile.get("id", "")), _configuration.timing_floors)
	if resolved.is_empty():
		return _denied(difficulty.last_error)
	var hero: CinderPlayer = _heroes[hero_id]
	var response: Dictionary = hero.get_threat_response_state()
	for key: String in RESPONSE_KEYS:
		if key != "encounter_id":
			response[key] = response_context[key]
	var cycle_geometry: Dictionary = _selected_geometry(bearing)
	if cycle_geometry.is_empty():
		return _denied("A cone bearing must be a finite normalized planar direction fixed for the cycle")
	var threat: Dictionary = {"role": resolved, "geometry": cycle_geometry, "source_stationary": true, "opening_stationary": true, "opening_position": cycle_opening, "cooldown_remaining_s": 0.0}
	var containing_root: Node3D = _preview_world_root(hero, response_context)
	if not is_instance_valid(containing_root):
		return _denied("Actual cone floors must belong to the retained native world")
	response["world_root"] = containing_root
	if not preview.is_empty():
		var prospective: Dictionary = preview_start(response_context, opening_position, bearing)
		if not prospective.get("accepted", false): return _denied(String(prospective.get("reason", "Preview rejected")))
		# The same native common-root derivation must reach Scheduler admission.
		response["world_root"] = _preview_world_root(hero, response_context)
	_transaction_depth += 1
	var current_preview: Dictionary = preview if not preview.is_empty() else _scheduler.preview_stationary(self, threat, response)
	var answer: Dictionary = {"accepted": false, "reason": String(current_preview.get("reason", "Stationary preview rejected"))}
	if current_preview.get("accepted", false):
		answer = _scheduler.request_attack(self, threat, response, current_preview)
	if answer.get("accepted", false):
		var reservation: Dictionary = _live_reservation(String(answer.reservation_id))
		if reservation.is_empty():
			_scheduler.cancel(String(answer.reservation_id), "missing_accepted_reservation")
			answer = _denied("Accepted exchange lost its actual reservation")
		else:
			_exchange = _exchange_data(reservation)
			_exchange_encounter_id = response_context.encounter_id
			_resolved_role = resolved.duplicate(true)
			_cycle += 1
			_hit_ids.clear()
			_pending_segments.clear()
			_samples.clear()
			_sample_heroes(_scheduler.get_clock())
			_status = "running"
			_last_cancel_reason = ""
			_set_phase("warning")
			if _presentation_guard_required: _damage_boundary_ready()
	else:
		last_error = String(answer.get("reason", "Reservation rejected"))
	_transaction_depth -= 1
	return answer.duplicate(true)


func preview_start(response_context: Dictionary, opening_position: Variant = null, bearing: Variant = null) -> Dictionary:
	var hero_id: String = HERO_ID
	## Exact pure camera preflight; no child cue, phase, cycle or diagnostic
	## changes and no lease allocation. Pass this result to start's fourth arg.
	if _transaction_depth > 0 or _snapshot_busy or _cancelling or not _live_bindings() or not _presentation_guard_required or not _presentation_guard.is_valid() or _status == "running" or get_tree().paused or not is_visible_in_tree() or not _cue.is_visible_in_tree() or _cycle >= Codec.MAX_SAFE_INTEGER:
		return {"accepted": false, "reason": "Preview requires an idle retained unpaused nose and bound current-view guard outside callbacks"}
	if not _heroes.has(hero_id) or not Codec.keys_error(response_context, RESPONSE_KEYS).is_empty() or not _stable_id(response_context.get("encounter_id")):
		return {"accepted": false, "reason": "Authored encounter epoch, floor and finite response candidates required"}
	var current_control: Dictionary = _scheduler.source_control_state(self)
	if response_context.encounter_id != current_control.get("encounter_id") or response_context.world_revision != current_control.get("world_revision"):
		return {"accepted": false, "reason": "The nose must use the actual current shared encounter epoch"}
	if global_position != _configuration.geometry.origin or (opening_position != null and (not Geometry.finite_vector(opening_position) or opening_position != _opening_owner.global_position)):
		return {"accepted": false, "reason": "Actual stationary source and finite per-cycle opening required"}
	var shape: Dictionary = _selected_geometry(bearing)
	if shape.is_empty():
		return {"accepted": false, "reason": "A cone bearing must be a finite normalized planar direction fixed for the cycle"}
	var difficulty = Difficulty.new()
	var resolved: Dictionary = difficulty.resolve_role(_configuration.raw_role, String(_scheduler.encounter_profile().get("id", "")), _configuration.timing_floors)
	if resolved.is_empty():
		return {"accepted": false, "reason": difficulty.last_error}
	var response: Dictionary = (_heroes[hero_id] as CinderPlayer).get_threat_response_state()
	for key: String in RESPONSE_KEYS:
		if key != "encounter_id": response[key] = response_context[key]
	var root: Node3D = _preview_world_root(_heroes[hero_id] as CinderPlayer, response_context)
	if not is_instance_valid(root):
		return {"accepted": false, "reason": "Actual nose/Scheduler/Hero/floors must retain the containing same-world root"}
	response["world_root"] = root
	var opening: Vector3 = _configuration.opening_position if opening_position == null else opening_position
	var threat := {"role": resolved, "geometry": shape, "source_stationary": true, "opening_stationary": true, "opening_position": opening, "cooldown_remaining_s": 0.0}
	return _scheduler.preview_stationary(self, threat, response)


func _preview_world_root(hero: CinderPlayer, context: Dictionary) -> Node3D:
	## Use the retained native root, never arbitrary copied caller custody.
	if not _native_binding_error().is_empty() or hero != _heroes.get(HERO_ID) or not context.get("floor_regions") is Array or context.floor_regions.is_empty() or context.floor_regions.size() > 32:
		return null
	for region: Variant in context.floor_regions:
		if not region is Dictionary:
			return null
		var collision: CollisionShape3D = region.get("collision") as CollisionShape3D
		if not is_instance_valid(collision) or not collision.is_inside_tree() or collision.is_queued_for_deletion() or not _world_root.is_ancestor_of(collision) or collision.get_world_3d() != get_world_3d():
			return null
	return _world_root


func _selected_geometry(bearing: Variant) -> Dictionary:
	var shape: Dictionary = _copy_geometry(_configuration.geometry)
	if bearing != null:
		if not Geometry.finite_vector(bearing): return {}
		shape["direction"] = bearing
	return shape if Geometry.error(shape).is_empty() else {}


func _cycle_geometry() -> Dictionary:
	return _exchange.get("geometry", _configuration.get("geometry", {}))


func _committed_geometry_matches(encoded: Dictionary) -> bool:
	if not Codec.keys_error(encoded, CONE_KEYS).is_empty() or not Codec.is_vector3(encoded.get("direction")):
		return false
	var shape: Dictionary = _selected_geometry(Codec.read_vector3(encoded.direction))
	return not shape.is_empty() and _same_exact(encoded, _encode_geometry(shape))


func cancel(reason: String = "nose_cancelled") -> bool:
	if reason.is_empty() or reason.length() > 512:
		return _reject("Cancellation retains a finite nonempty reason")
	if _snapshot_busy or _cancelling:
		return false
	_cancelling = true
	_transaction_depth += 1
	var id: String = String(_exchange.get("id", "")) if _status == "running" else ""
	_status = "cancelled" if _cycle > 0 else "idle"
	_pending_segments.clear()
	_last_cancel_reason = reason
	if not id.is_empty() and is_instance_valid(_scheduler):
		_scheduler.cancel(id, reason)
	_set_phase("clear")
	_transaction_depth -= 1
	_cancelling = false
	return true


func clear(reason: String = "nose_cleared") -> bool:
	return cancel(reason)


func get_cue() -> CinderThreatCue:
	return _cue


func state() -> Dictionary:
	var remaining: float = 0.0
	if _status == "running" and is_instance_valid(_scheduler):
		var key: String = {"warning": "lock_from_s", "lock": "active_from_s", "active": "active_until_s", "recovery": "recovery_until_s"}.get(_phase, "")
		if not key.is_empty():
			remaining = maxf(float(_exchange[key]) - _scheduler.get_clock(), 0.0)
	var hits: Array = _hit_ids.keys()
	hits.sort()
	return {"api_revision": API_REVISION, "source_id": _configuration.get("source_id", ""), "status": _status, "phase": _phase, "remaining_s": remaining, "cycle": _cycle, "reservation_id": _exchange.get("id", "") if _status == "running" else "", "geometry": _cycle_geometry().duplicate(true), "source_position": global_position, "opening_position": _exchange.get("opening_position", _configuration.get("opening_position")), "resolved_role": _resolved_role.duplicate(true), "hit_ids": hits, "last_cancel_reason": _last_cancel_reason}


func _physics_process(_delta: float) -> void:
	if _status != "running" or not is_instance_valid(_scheduler) or get_tree().paused or _transaction_depth > 0:
		return
	_transaction_depth += 1
	if _damage_boundary_ready():
		var now: float = _scheduler.get_clock()
		# Sample completed actor physics before every observer. On resume append
		# the real new segment to an unresolved path; never collapse its turns.
		if _stage_hero_segments(now):
			_set_phase(_phase_at(now, _exchange))
			if _damage_boundary_ready():
				_resolve_pending_segments()
	_transaction_depth -= 1


func _stage_hero_segments(now: float) -> bool:
	var ids: Array = _heroes.keys()
	ids.sort()
	for id: String in ids:
		var hero: CinderPlayer = _heroes[id]
		var previous: Dictionary = _samples[id]
		if not hero.dead and not _hit_ids.has(id):
			var path: Array = _pending_segments.get(id, [])
			if path.size() >= MAX_PENDING_SEGMENTS:
				cancel("pending_path_budget_exceeded")
				return false
			path.append({"from": previous.position, "to": hero.global_position, "start_s": previous.clock_s, "end_s": now})
			_pending_segments[id] = path
		_samples[id] = {"position": hero.global_position, "clock_s": now}
	return true


func _resolve_pending_segments() -> void:
	for id: String in _pending_segments.keys():
		if not _damage_boundary_ready():
			return
		var hero: CinderPlayer = _heroes[id]
		var path: Array[Dictionary] = []
		for segment: Dictionary in _pending_segments[id]: path.append(segment)
		# Commit this entry before any synchronous actor/art callback. A pause
		# keeps only the unprocessed entries, never a second hit for this hero.
		_pending_segments.erase(id)
		if hero.dead or _hit_ids.has(id) or not _active_path_hits(path):
			continue
		# Consume the opportunity before entering the player's synchronous
		# hurt/death callbacks. Invulnerability may legitimately reject damage.
		_hit_ids[id] = true
		var hp_before: float = hero.hp
		hero.take_damage(float(_resolved_role.damage), Vector3.ZERO)
		var result: Dictionary = {"opportunity_consumed": true, "accepted": hero.hp < hp_before, "raw_damage": float(_resolved_role.damage), "hp_damage": maxf(hp_before - hero.hp, 0.0), "impulse": Vector3.ZERO}
		var hurt_boundary_ready: bool = _damage_boundary_ready()
		hit_resolved.emit(id, _cycle, result.duplicate(true))
		var hit_boundary_ready: bool = _damage_boundary_ready()
		if not hurt_boundary_ready or not hit_boundary_ready:
			return


func _active_path_hits(path: Array[Dictionary]) -> bool:
	for segment: Dictionary in path:
		# Spatial tolerances cannot advance a damage opportunity into the last
		# lock tick when binary64 clock accumulation falls just below active_from.
		if maxf(float(segment.start_s), float(_exchange.active_from_s)) > minf(float(segment.end_s), float(_exchange.active_until_s)):
			continue
		if Geometry.timed_path_hits(_cycle_geometry(), [segment], float(_exchange.active_from_s), float(_exchange.active_until_s), CinderThreatScheduler.CAPSULE_RADIUS):
			return true
	return false


func _damage_boundary_ready() -> bool:
	if _presentation_guard_busy:
		return false
	if not _native_damage_boundary_ready():
		return false
	if not _presentation_guard_required:
		return true
	_presentation_guard_busy = true
	# A native lease recheck may itself prune a foreign source and notify parent
	# observers. Reauthorize after that notification once, never use the earlier
	# parent answer across it. Further notification churn fails closed.
	for _attempt: int in range(2):
		if not _presentation_guard.is_valid() or _presentation_guard.get_argument_count() != 2:
			_presentation_guard_busy = false
			cancel("required_parent_presentation_unavailable")
			return false
		_presentation_guard_invalidated = false
		_transaction_depth += 1
		var result: Variant = _presentation_guard.call(_configuration.source_id, state())
		_transaction_depth -= 1
		if _status != "running":
			_presentation_guard_busy = false
			return false # Preserve the owner's precise synchronous cancel reason.
		if not _presentation_guard.is_valid() or _presentation_guard.get_argument_count() != 2 or not result is bool or not result:
			_presentation_guard_busy = false
			cancel("required_parent_presentation_unavailable")
			return false
		if not _native_damage_boundary_ready():
			_presentation_guard_busy = false
			return false
		if not _presentation_guard_invalidated:
			_presentation_guard_busy = false
			return true
	_presentation_guard_busy = false
	cancel("parent_presentation_guard_unstable_lease_observers")
	return false


func _native_damage_boundary_ready() -> bool:
	if _status != "running":
		return false
	if not _live_bindings() or is_queued_for_deletion() or not is_visible_in_tree() or not _opening_owner.is_visible_in_tree() or not _required_cue_available():
		cancel("required_source_or_bindings_unavailable")
		return false
	if get_tree().paused:
		return false
	var reservation: Dictionary = _live_reservation(String(_exchange.id))
	if _status != "running":
		return false
	if reservation.is_empty():
		if _scheduler.get_clock() > float(_exchange.recovery_until_s):
			_status = "complete"
			_pending_segments.clear()
			_set_phase("clear")
		else:
			cancel("reservation_missing")
		return false
	if _exchange_data(reservation) != _exchange:
		cancel("committed_exchange_changed")
		return false
	# Scheduler cleanup can itself notify authored observers.
	if not _live_bindings() or not is_visible_in_tree() or not _required_cue_available():
		cancel("required_source_or_bindings_unavailable")
		return false
	return not get_tree().paused


func _required_cue_available() -> bool:
	if not is_instance_valid(_cue) or not _cue.is_visible_in_tree():
		return false
	var current: Dictionary = _cue.state()
	if _cue.get_script() != CueScript or _cue.get_parent() != self or _cue.is_queued_for_deletion() or current.phase != _phase or current.geometry != _cycle_geometry() or current.source_position != global_position:
		return false
	var required: Array[String] = ["RequiredSourceMarker"]
	if _phase != "recovery": required.append("RequiredFootprintOutline")
	if _phase == "active": required.append("RequiredFootprintFill")
	for part_name: String in required:
		var part: MeshInstance3D = _cue.get_node_or_null(part_name) as MeshInstance3D
		if not is_instance_valid(part) or part.is_queued_for_deletion() or not part.is_visible_in_tree() or part.mesh == null:
			return false
	return true


func _sample_heroes(now: float) -> void:
	for id: String in _heroes:
		_samples[id] = {"position": (_heroes[id] as CinderPlayer).global_position, "clock_s": now}


func _set_phase(phase: String, notify: bool = true) -> void:
	var changed: bool = _phase != phase
	_phase = phase
	if is_instance_valid(_cue):
		if phase == "clear":
			_cue.clear()
		else:
			if not _cue.present(_cycle_geometry(), phase):
				cancel("required_cue_presentation_rejected")
		# A cue callback may synchronously cancel this nose. Its cue
		# rejected nested clear, so clear again after that callback returns.
		if _phase == "clear":
			_cue.clear()
	# Parent exit cleanup may run after this child has left the native tree.
	# Retire its phase/cue/lease normally, but publish world state only while live.
	if changed and notify and _phase == phase and is_inside_tree():
		state_changed.emit(state())


func _on_invalidated(id: String, reason: String) -> void:
	# Observe foreign invalidations too: their synchronous listeners can revoke
	# required parent presentation while the nose's own lease stays live.
	if _presentation_guard_busy: _presentation_guard_invalidated = true
	if _status == "running" and id == _exchange.get("id") and not _cancelling:
		cancel(reason)


func _exit_tree() -> void:
	if is_instance_valid(_scheduler):
		if _scheduler.reservation_invalidated.is_connected(_on_invalidated):
			_scheduler.reservation_invalidated.disconnect(_on_invalidated)
		_scheduler.cancel_owner(self, "nose_removed")
	# Release any captured native parent references. Removal cannot unopt this
	# instance: the required flag stays true and an invalid guard fails closed.
	_presentation_guard = Callable()


func _finite_transform(value: Transform3D) -> bool:
	return value.origin.is_finite() and value.basis.x.is_finite() and value.basis.y.is_finite() and value.basis.z.is_finite()


func _live_bindings() -> bool:
	return _native_binding_error().is_empty()


func _native_binding_error() -> String:
	if not _configured or not is_inside_tree() or not is_node_ready() or is_queued_for_deletion() or _heroes.size() != 1 or not _heroes.has(HERO_ID):
		return "Ready configured sole-Hero nose source required"
	if not is_instance_valid(_world_root) or not _world_root.is_inside_tree() or _world_root.is_queued_for_deletion():
		return "Actual containing nose world was removed"
	var hero: CinderPlayer = _heroes[HERO_ID]
	var nodes: Dictionary = {"source": self, "scheduler": _scheduler, "hero": hero, "world": _world_root, "eye": _opening_owner, "cue": _cue}
	for key: String in nodes:
		var node: Node3D = nodes[key] as Node3D
		if not is_instance_valid(node) or not node.is_inside_tree() or not node.is_node_ready() or node.is_queued_for_deletion() or node.get_world_3d() != get_world_3d() or not _native_parents.has(key) or not _native_scripts.has(key) or node.get_parent() != (_native_parents[key] as WeakRef).get_ref() or node.get_script() != _native_scripts[key]:
			return "Actual nose native parent/script/world bindings changed: " + key
		if node != _world_root and not _world_root.is_ancestor_of(node):
			return "Actual nose native containment changed: " + key
	if _scheduler.get_script() != SchedulerScript or hero.get_script() != PlayerScript or _cue.get_script() != CueScript or _cue.get_parent() != self or _scheduler.process_physics_priority >= process_physics_priority or hero.process_physics_priority >= process_physics_priority:
		return "Canonical earlier-physics source/Hero/Scheduler/cue bindings required"
	if global_transform != _source_transform or global_position != _configuration.geometry.origin or _opening_owner.global_transform != _opening_transform or _opening_owner.global_position != _configuration.opening_position:
		return "Stationary actual nose/eye transforms changed"
	if _opening_owner is CharacterBody3D and (_opening_owner as CharacterBody3D).velocity != Vector3.ZERO:
		return "Stationary actual eye opening moved"
	if not is_instance_valid(_hero_collision) or not is_instance_valid(_hero_capsule) or _hero_collision.get_parent() != hero or _hero_collision != hero.get_node_or_null("BodyCollision") or _hero_collision.shape != _hero_capsule:
		return "Actual retained Hero collision resource changed"
	var description: Dictionary = Motion.source_description(hero)
	if description.has("error") or BodySweep.source_description(hero).has("error") or not _same_exact(description.get("signature", {}), _hero_signature):
		return "Actual retained Hero body contract changed"
	return ""


func _live_reservation(id: String) -> Dictionary:
	for record: Dictionary in _scheduler.reservations():
		if record.id == id and int(record.source_instance_id) == get_instance_id():
			return record
	return {}


func _exchange_data(record: Dictionary) -> Dictionary:
	var result: Dictionary = {}
	for key: String in EXCHANGE_KEYS:
		result[key] = record[key]
	return result.duplicate(true)


func _phase_at(now: float, exchange: Dictionary) -> String:
	return "warning" if now < float(exchange.lock_from_s) else ("lock" if now < float(exchange.active_from_s) else ("active" if now <= float(exchange.active_until_s) else "recovery"))


func _stable_id(value: Variant) -> bool:
	if not value is String or value.is_empty() or value.length() > 128:
		return false
	var pattern := RegEx.new()
	pattern.compile("^[A-Za-z0-9_./:-]+$")
	var matched: RegExMatch = pattern.search(value)
	return matched != null and matched.get_string() == value


func _reject(reason: String) -> bool:
	last_error = reason
	return false


func _denied(reason: String) -> Dictionary:
	last_error = reason
	return {"accepted": false, "reason": reason}


## Paired paused transport. Prevalidation may use a staged scheduler envelope
## and its owner_positions; commit ONLY accepts the actually restored scheduler.
## Rebuild cues silently; level artwork should re-read state after aggregate
## commit. No reservation request, damage, phase/hit/cue event or timing reset.
func snapshot_state(scheduler_bindings: Dictionary) -> Dictionary:
	last_snapshot_error = _snapshot_access_error()
	if not last_snapshot_error.is_empty():
		return {}
	_snapshot_busy = true
	var paired: Dictionary = _scheduler.snapshot_state(scheduler_bindings)
	var snapshot: Dictionary = {}
	if paired.is_empty():
		last_snapshot_error = _scheduler.last_snapshot_error
	else:
		var hits: Array = _hit_ids.keys()
		hits.sort()
		var samples: Dictionary = {}
		for id: String in _samples:
			samples[id] = {"position": Codec.vector3(_samples[id].position), "clock_s": _samples[id].clock_s}
		snapshot = {"api_revision": API_REVISION, "schema_version": 1, "source_id": _configuration.source_id, "configuration": _encode_configuration(), "status": _status, "phase": _phase, "cycle": _cycle, "clock_s": paired.clock_s, "resolved_role": _resolved_role.duplicate(true), "exchange_encounter_id": _exchange_encounter_id, "exchange": _encode_exchange(_exchange), "hero_samples": samples, "hit_ids": hits, "last_cancel_reason": _last_cancel_reason}
		if not _pending_segments.is_empty():
			snapshot.schema_version = 2
			snapshot["pending_segments"] = {}
			for id: String in _pending_segments:
				snapshot.pending_segments[id] = []
				for segment: Dictionary in _pending_segments[id]:
					snapshot.pending_segments[id].append({"from": Codec.vector3(segment.from), "to": Codec.vector3(segment.to), "start_s": segment.start_s, "end_s": segment.end_s})
		last_snapshot_error = _snapshot_plan_error(snapshot, scheduler_bindings, paired, true)
	_snapshot_busy = false
	return snapshot.duplicate(true) if last_snapshot_error.is_empty() else {}


func snapshot_error(snapshot: Dictionary, scheduler_bindings: Dictionary, staged_scheduler_snapshot: Dictionary = {}) -> String:
	var error: String = _snapshot_access_error()
	if not error.is_empty():
		return error
	_snapshot_busy = true
	var paired: Dictionary = staged_scheduler_snapshot.duplicate(true) if not staged_scheduler_snapshot.is_empty() else _scheduler.snapshot_state(scheduler_bindings)
	error = _scheduler.snapshot_error(paired, scheduler_bindings) if not paired.is_empty() else _scheduler.last_snapshot_error
	if error.is_empty():
		error = _snapshot_plan_error(snapshot, scheduler_bindings, paired)
	_snapshot_busy = false
	return error


func restore_state(snapshot: Dictionary, scheduler_bindings: Dictionary) -> bool:
	last_snapshot_error = _snapshot_access_error()
	if not last_snapshot_error.is_empty():
		return false
	_snapshot_busy = true
	var paired: Dictionary = _scheduler.snapshot_state(scheduler_bindings)
	last_snapshot_error = _scheduler.last_snapshot_error if paired.is_empty() else _snapshot_plan_error(snapshot, scheduler_bindings, paired, true)
	if last_snapshot_error.is_empty() and global_position != _configuration.geometry.origin:
		last_snapshot_error = "Apply validated actual nose position before scheduler/nose commit"
	if not last_snapshot_error.is_empty():
		_snapshot_busy = false
		return false
	var accepted: Dictionary = snapshot.duplicate(true)
	_status = accepted.status
	_phase = accepted.phase
	_cycle = int(accepted.cycle)
	_resolved_role = accepted.resolved_role
	_exchange_encounter_id = accepted.exchange_encounter_id
	_exchange = _decode_exchange(accepted.exchange)
	_samples.clear()
	for id: String in accepted.hero_samples:
		_samples[id] = {"position": Codec.read_vector3(accepted.hero_samples[id].position), "clock_s": float(accepted.hero_samples[id].clock_s)}
	_hit_ids.clear()
	for id: String in accepted.hit_ids:
		_hit_ids[id] = true
	_pending_segments.clear()
	for id: String in accepted.get("pending_segments", {}):
		_pending_segments[id] = []
		for segment: Dictionary in accepted.pending_segments[id]:
			_pending_segments[id].append({"from": Codec.read_vector3(segment.from), "to": Codec.read_vector3(segment.to), "start_s": float(segment.start_s), "end_s": float(segment.end_s)})
	_last_cancel_reason = accepted.last_cancel_reason
	var was_blocked: bool = _cue.is_blocking_signals()
	_cue.set_block_signals(true)
	_cue.clear()
	_set_phase(_phase, false)
	_cue.set_block_signals(was_blocked)
	_snapshot_busy = false
	return true


func _snapshot_access_error() -> String:
	if not _live_bindings() or not _presentation_guard_required or not _presentation_guard.is_valid() or not get_tree().paused:
		return "Nose snapshots require retained native bindings at the paused shell barrier"
	if _snapshot_busy or _transaction_depth > 0 or _cancelling:
		return "Nose snapshots cannot run inside phase/hit/physics/cancellation callbacks"
	return ""


func _encode_configuration() -> Dictionary:
	return {"source_id": _configuration.source_id, "geometry": _encode_geometry(_configuration.geometry), "opening_position": Codec.vector3(_configuration.opening_position), "raw_role": _configuration.raw_role.duplicate(true), "timing_floors": _configuration.timing_floors.duplicate(true)}


func _encode_geometry(shape: Dictionary) -> Dictionary:
	return {"kind": "cone", "origin": Codec.vector3(shape.origin), "direction": Codec.vector3(shape.direction), "reach": shape.reach, "min_dot": shape.min_dot, "origin_radius": shape.origin_radius}


func _copy_geometry(shape: Dictionary) -> Dictionary:
	return Geometry.cone(shape.origin, shape.direction, float(shape.reach), float(shape.min_dot), float(shape.origin_radius))


func _geometry_source(shape: Dictionary) -> Vector3:
	return shape["origin"]


func _encode_exchange(exchange: Dictionary) -> Dictionary:
	if exchange.is_empty():
		return {}
	var result: Dictionary = exchange.duplicate(true)
	result.geometry = _encode_geometry(exchange.geometry)
	result.source_position = Codec.vector3(exchange.source_position)
	result.opening_position = Codec.vector3(exchange.opening_position)
	return result


func _decode_exchange(exchange: Dictionary) -> Dictionary:
	if exchange.is_empty(): return {}
	var result: Dictionary = exchange.duplicate(true)
	var shape: Dictionary = exchange.geometry
	result.geometry = Geometry.cone(Codec.read_vector3(shape.origin), Codec.read_vector3(shape.direction), float(shape.reach), float(shape.min_dot), float(shape.origin_radius))
	result.source_position = Codec.read_vector3(exchange.source_position)
	result.opening_position = Codec.read_vector3(exchange.opening_position)
	return result


func _snapshot_plan_error(snapshot: Dictionary, bindings: Dictionary, paired: Dictionary, actual_heroes: bool = false) -> String:
	var error: String = Codec.value_error(snapshot)
	if error.is_empty():
		var keys: Array = ["api_revision", "schema_version", "source_id", "configuration", "status", "phase", "cycle", "clock_s", "resolved_role", "exchange_encounter_id", "exchange", "hero_samples", "hit_ids", "last_cancel_reason"]
		if snapshot.get("schema_version") == 2: keys.append("pending_segments")
		error = Codec.keys_error(snapshot, keys)
	if not error.is_empty():
		return error
	if snapshot.api_revision != API_REVISION or not Codec.is_integer(snapshot.schema_version, 1, 2) or snapshot.source_id != _configuration.source_id or not snapshot.configuration is Dictionary or not _same_exact(snapshot.configuration, _encode_configuration()) or not Codec.is_integer(snapshot.cycle) or snapshot.status not in ["idle", "running", "cancelled", "complete"] or not snapshot.phase is String or not snapshot.resolved_role is Dictionary or not snapshot.exchange is Dictionary or not snapshot.hero_samples is Dictionary or not snapshot.hit_ids is Array or not snapshot.last_cancel_reason is String or not snapshot.exchange_encounter_id is String:
		return "Invalid immutable nose identity/configuration/schema"
	var pending: Variant = snapshot.get("pending_segments", {})
	if not pending is Dictionary or (snapshot.schema_version == 2 and (pending.is_empty() or snapshot.status != "running" or pending.size() > _heroes.size())):
		return "Pending schema2 requires a bounded unprocessed running hero batch"
	if not Codec.is_number(snapshot.clock_s) or float(snapshot.clock_s) != float(paired.clock_s) or bindings.get("world_root") != _world_root or not bindings.get("owners") is Dictionary or bindings.owners.get(_configuration.source_id) != self:
		return "Nose must share the actual/staged scheduler clock and stable source binding"
	if bindings.has("hero_positions") and not bindings.hero_positions is Dictionary:
		return "Staged hero_positions must name finite actual actor positions"
	for id: Variant in bindings.get("hero_positions", {}):
		if not _heroes.has(id) or not Geometry.finite_vector(bindings.hero_positions[id]):
			return "Staged hero_positions require stable bound actor IDs"
	var owned: Dictionary = {}
	for record: Dictionary in paired.reservations:
		if record.source_id == _configuration.source_id:
			owned = record
	if snapshot.status == "idle":
		for cooldown: Dictionary in paired.cooldowns:
			if cooldown.source_id == _configuration.source_id:
				return "Idle nose cannot forget a consumed source cooldown/cycle"
		return "Idle nose cannot retain exchange/phase/hit state" if snapshot.cycle != 0 or snapshot.phase != "clear" or not snapshot.exchange.is_empty() or not snapshot.resolved_role.is_empty() or not snapshot.hero_samples.is_empty() or not snapshot.hit_ids.is_empty() or not snapshot.exchange_encounter_id.is_empty() or not owned.is_empty() else ""
	if not Codec.is_integer(snapshot.cycle, 1) or not _stable_id(snapshot.exchange_encounter_id) or not Codec.keys_error(snapshot.exchange, EXCHANGE_KEYS).is_empty():
		return "Executed nose requires its finite cycle and exact committed exchange"
	var exchange: Dictionary = snapshot.exchange
	if not exchange.id is String or not exchange.id.begins_with("threat-") or not Codec.is_vector3(exchange.source_position) or not Codec.is_vector3(exchange.opening_position) or not exchange.geometry is Dictionary or not _committed_geometry_matches(exchange.geometry) or (Codec.read_vector3(exchange.source_position) != _configuration.geometry.origin or Codec.read_vector3(exchange.opening_position) != _configuration.opening_position) or not exchange.profile_id is String or not Codec.is_integer(exchange.world_revision, 1):
		return "Committed source/geometry/opening no longer matches actual nose configuration"
	if not exchange.id.substr(7).is_valid_int() or not Codec.is_integer(int(exchange.id.substr(7)), 1) or exchange.id != "threat-%d" % int(exchange.id.substr(7)):
		return "Committed reservation ID must preserve its exact finite scheduler serial"
	var difficulty = Difficulty.new()
	var resolved: Dictionary = difficulty.resolve_role(_configuration.raw_role, exchange.profile_id, _configuration.timing_floors)
	if resolved.is_empty() or not _same_exact(snapshot.resolved_role, resolved):
		return "Saved role must resolve once from immutable raw data and its catalogue profile"
	for key: String in ["start_s", "lock_from_s", "active_from_s", "active_until_s", "recovery_until_s", "cooldown_until_s"]:
		if not Codec.in_range(exchange[key], 0.0, 1000000000.0):
			return "Committed nose deadlines must be finite and nonnegative"
	var active_from: float = float(exchange.start_s) + float(resolved.windup_s)
	var expected: Dictionary = {"lock_from_s": active_from - float(resolved.lock_s), "active_from_s": active_from, "active_until_s": active_from + float(resolved.active_s), "recovery_until_s": active_from + float(resolved.active_s) + float(resolved.recovery_s), "cooldown_until_s": active_from + float(resolved.attack_interval_s)}
	for key: String in expected:
		if float(exchange[key]) != float(expected[key]):
			return "Saved deadlines disagree with the original resolved cycle"
	if snapshot.status == "running":
		if owned.is_empty() or snapshot.exchange_encounter_id != paired.encounter_id or snapshot.phase != _phase_at(float(snapshot.clock_s), _decode_exchange(exchange)) or not snapshot.last_cancel_reason.is_empty():
			return "Running phase requires the same actually/staged reserved encounter"
		for key: String in EXCHANGE_KEYS:
			if not _same_exact(exchange[key], owned[key]):
				return "Running nose and scheduler reservation disagree"
	else:
		if snapshot.phase != "clear" or not owned.is_empty():
			return "Inactive nose cannot hide a retained danger reservation"
		if snapshot.status == "cancelled" and snapshot.last_cancel_reason.is_empty():
			return "Cancelled nose requires its explicit cancellation reason"
		if snapshot.status == "complete" and snapshot.exchange_encounter_id == paired.encounter_id and float(snapshot.clock_s) <= float(exchange.recovery_until_s):
			return "Completed cycle cannot discard remaining recovery"
	if snapshot.exchange_encounter_id == paired.encounter_id and float(exchange.cooldown_until_s) > float(snapshot.clock_s):
		var has_cooldown: bool = false
		for cooldown: Dictionary in paired.cooldowns:
			if cooldown.source_id == _configuration.source_id and float(cooldown.ready_s) == float(exchange.cooldown_until_s):
				has_cooldown = true
		if not has_cooldown:
			return "Cancelled/live cycle cannot refresh its original source cooldown"
	if snapshot.hero_samples.size() != _heroes.size():
		return "Stable hero samples must retain every bound actor"
	for id: Variant in snapshot.hero_samples:
		var sample: Variant = snapshot.hero_samples[id]
		if not _heroes.has(id) or not sample is Dictionary or not Codec.keys_error(sample, ["position", "clock_s"]).is_empty() or not Codec.is_vector3(sample.position) or not Codec.in_range(sample.clock_s, float(exchange.start_s), float(exchange.recovery_until_s)):
			return "Malformed finite hero path sample"
		if snapshot.status == "running":
			var hero: CinderPlayer = _heroes[id]
			var position: Vector3 = hero.global_position if actual_heroes else bindings.get("hero_positions", {}).get(id, hero.global_position)
			if float(sample.clock_s) != float(snapshot.clock_s) or Codec.read_vector3(sample.position) != position:
				return "Running hero path sample must match the same actual/staged actor tick"
	var seen: Dictionary = {}
	for id: Variant in snapshot.hit_ids:
		if not id is String or not _heroes.has(id) or seen.has(id):
			return "Hit dedupe must use unique stable bound hero IDs"
		seen[id] = true
		if float(snapshot.hero_samples[id].clock_s) < float(exchange.active_from_s):
			return "A hero opportunity cannot be consumed before the active interval"
	var latest_batch_start: float = -1.0
	for id: Variant in pending:
		var path: Variant = pending[id]
		if not id is String or not _heroes.has(id) or seen.has(id) or not path is Array or path.is_empty() or path.size() > MAX_PENDING_SEGMENTS:
			return "Pending segments require unique unconsumed stable heroes and finite sampled paths"
		var previous: Dictionary = {}
		for segment: Variant in path:
			if not segment is Dictionary or not Codec.keys_error(segment, ["from", "to", "start_s", "end_s"]).is_empty() or not Codec.is_vector3(segment.from) or not Codec.is_vector3(segment.to) or not Codec.in_range(segment.start_s, float(exchange.start_s), float(snapshot.clock_s)) or not Codec.in_range(segment.end_s, float(segment.start_s), float(snapshot.clock_s)) or float(segment.end_s) - float(segment.start_s) > 1.0 / float(Engine.physics_ticks_per_second) + Geometry.EPSILON:
				return "Every pending segment must retain a finite actual single-physics-tick interval"
			if not previous.is_empty() and (float(segment.start_s) != float(previous.end_s) or not _same_exact(segment.from, previous.to)):
				return "Pending path must preserve exact contiguous piecewise samples"
			previous = segment
		if float(previous.end_s) != float(snapshot.clock_s) or not _same_exact(previous.to, snapshot.hero_samples[id].position):
			return "Pending path must retain the exact paired current endpoint and clock"
		if latest_batch_start >= 0.0 and float(previous.start_s) != latest_batch_start:
			return "Pending heroes must share the latest authoritative sampled batch"
		latest_batch_start = float(previous.start_s)
	return ""


func _same_exact(left: Variant, right: Variant) -> bool:
	# Legacy full-precision JSON may change int representation, never a copied
	# clock, immutable field or reservation identity. No epsilon for transport.
	if Codec.is_number(left) and Codec.is_number(right):
		return float(left) == float(right)
	if left is Dictionary and right is Dictionary:
		if left.size() != right.size():
			return false
		for key: String in left:
			if not right.has(key) or not _same_exact(left[key], right[key]):
				return false
		return true
	if left is Array and right is Array:
		if left.size() != right.size():
			return false
		for index: int in range(left.size()):
			if not _same_exact(left[index], right[index]):
				return false
		return true
	return typeof(left) == typeof(right) and left == right
