class_name Act1MushroomSelenite
extends CharacterBody3D
## C31 / A1-E2 and C32 / A1-E3 bounded greybox consumers. The shared scheduler
## owns attack deadlines, cooldowns, proof and C31 ground-lunge motion. Actor HP,
## hurt settling, sampled damage and presentation remain authored. C31 approach
## is explicitly opt-in. Genuine shared26 environmental motion is optional and
## belongs to the bound consumer/Route; there is no auto-cycle or second clock.
## Native phases and genuine environmental stamps select clockless costume pixels.
## Capture/restore uses one exact Player+actor+Scheduler aggregate; an actor
## record is never converted into an AshEnemy envelope.

signal state_changed(actor_state: Dictionary)
signal defeated(source_id: String)
signal hit_resolved(hero_id: String, cycle: int, result: Dictionary)

const Geometry = preload("res://scripts/combat/threat_geometry.gd")
const Difficulty = preload("res://scripts/combat/difficulty.gd")
const Motion = preload("res://scripts/combat/lunge_motion.gd")
const BodySweep = preload("res://scripts/combat/body_sweep.gd")
const Codec = preload("res://scripts/campaign/snapshot_codec.gd")
const ExactJson = preload("res://scripts/campaign/exact_json.gd")
const CueScript = preload("res://scripts/cues/threat_cue.gd")
const ArtScript = preload("res://scripts/acts/act1/mushroom_selenite_art.gd")
const NativeCodec = preload("res://scripts/acts/act1/mushroom_selenite_codec.gd")
const Approach = preload("res://scripts/acts/act1/mushroom_selenite_approach.gd")
const API_REVISION: String = "act1-mushroom-selenite-3"
const SNAPSHOT_SCHEMA_VERSION: int = 1
const PENDING_SNAPSHOT_SCHEMA_VERSION: int = 2
const BOUND_SNAPSHOT_SCHEMA_VERSION: int = 3
const BOUND_PENDING_SNAPSHOT_SCHEMA_VERSION: int = 4
const SPORE_ACTOR_REVISION: String = "scheduler-spore-actor-1"
const RepulsionRoute = preload("res://scripts/combat/repulsion_route.gd")
const SPORE_PHASES: Array[String] = ["none", "recoil", "turn", "retreat", "hold", "regroup", "interrupted", "failed"]
const MAX_PENDING_SEGMENTS: int = 256
const HERO_ID: String = "hero"
const GRAVITY: float = 24.0
const HURT_BRAKING: float = 5.0
const HURT_S: float = 0.22
const ROLE_SWARM: String = "A1-E2"
const ROLE_GUARD: String = "A1-E3"
const SWARM_RAW_ROLE: Dictionary = {"raw_damage": 6.0, "windup_s": 1.85, "lock_s": 0.85, "active_s": 0.4, "recovery_s": 1.8, "attack_interval_s": 2.0, "max_hp": 16.0, "move_speed": 4.0}
const GUARD_RAW_ROLE: Dictionary = {"raw_damage": 8.0, "windup_s": 1.85, "lock_s": 0.85, "active_s": 0.2, "recovery_s": 2.4, "attack_interval_s": 2.0, "max_hp": 24.0, "move_speed": 0.0}
const SWARM_LUNGE: Dictionary = {"speed": 4.0, "distance": 1.0, "damage_radius": 0.38, "body_collision_path": "BodyCollision"}
const GUARD_LANE: Dictionary = {"length": 2.0, "radius": 0.38}
# Narrow court-only entry; these values are not a new role or attack adapter.
const COURT_SCRIPT_PATH: String = "res://scripts/acts/act1/selenite_court.gd"
const COURT_HELPER_IDS: Array[String] = ["court-helper-west", "court-helper-east"]
const COURT_ENTRY_KEYS: Array[String] = ["active", "from", "to", "start_s", "end_s", "speed"]
const COURT_ENTRY_DISTANCE: float = 0.7
const COURT_ENTRY_SPEED: float = 1.4
const CONTEXT_KEYS: Array[String] = ["encounter_id", "world_revision", "recognition_s", "attack_input_margin_s", "escape_directions", "return_directions", "floor_regions", "world_root"]
const SNAPSHOT_KEYS: Array[String] = ["api_revision", "schema_version", "role_id", "source_id", "configuration", "hp", "dead", "dormant", "motion", "hurt_left_s", "approach_driving", "role_encounter_id", "profile_id", "resolved_role", "reservation_id", "cycle", "sample", "hit_ids", "last_cancel_reason"]

var hp: float = 16.0
var max_hp: float = 16.0
var dead: bool = false
var dormant: bool = false
## Parent grants this source only immediately after successful fresh begin_encounter.
## The pure callable receives source_id and must return literal true. Parent clears
## entitlement after every activation attempt; same-tick cancellation never grants it.
var activation_guard: Callable
## Pure renderer-owned admission/sampling guard; a nonempty reason cancels.
var presentation_guard: Callable
## Required for opt-in C31 movement. Pure callback receives a native proposal and
## returns a literal String. Parent guards full next/braking body/art/world/spacing
## from retained actual bindings and cached state, without pruning Scheduler calls.
## No environmental/source-control protocol is implied by this ordinary guard.
var approach_guard: Callable
## Optional for ordinary consumers; the parent opts in before environmental bind.
## Receives one closed native-boundary proposal and returns a literal String.
## A required callable and its identity are retained at bind, never transported
## as actor state. It grants no Route, motion, clock, HP or camera authority.
var spore_route_guard: Callable
var spore_route_guard_required: bool = false
var last_error: String = ""
var last_snapshot_error: String = ""
var _configuration: Dictionary = {}
var _native_codec: RefCounted = NativeCodec.new()
var _approach: RefCounted = Approach.new()
var _approach_driving: bool = false
var _scheduler: CinderThreatScheduler
var _hero: CinderPlayer
var _collision: CollisionShape3D
var _body_signature: Dictionary = {}
var _retained_capsule: CapsuleShape3D
var _native_body_properties: Dictionary = {}
var _cue: CinderThreatCue
var _visual: Node3D
var _body: MeshInstance3D
var _sprite_art: Node3D
var _facing: Vector3 = Vector3.FORWARD
var _hurt_left_s: float = 0.0
var _restored_floor_contact: int = -1
var _role_encounter_id: String = ""
var _profile_id: String = ""
var _resolved_role: Dictionary = {}
var _reservation_id: String = ""
var _cycle: int = 0
var _sample: Dictionary = {}
var _pending_segments: Array[Dictionary] = []
var _hit_ids: Array[String] = []
var _last_cancel_reason: String = ""
var _phase: String = "clear"
var _transaction_depth: int = 0
var _snapshot_busy: bool = false
var _cancelling: bool = false
# Only the actual bound consumer owns episode generation, progress and Route.
# Weak identity survives quiet reconstruction; never serialize object handles.
var _spore_consumer_ref: WeakRef
var _spore_consumer_id: String = ""
var _spore_episode_id: String = ""
var _spore_phase: String = "none"
var _spore_direction: Vector3 = Vector3.FORWARD
var _spore_progress: float = 0.0
var _spore_cancel_delivering: bool = false
var _spore_nested_damage_used: bool = false
var _bound_spore_route_guard: Callable
var _bound_spore_route_guard_required: bool = false
# Transient construction custody only. Never actor configuration or wire data.
var _restore_recipient_constructed: bool = false
# Construction custody, not wire state. The court transports its own once/entry
# history together with this actor's unchanged native motion envelope.
var _court_entry_consumed: bool = false
var _restore_level_ref: WeakRef
var _restore_level_script: Script
var _restore_source_parent: WeakRef
var _restore_source_script: Script
var _restore_source_transform: Transform3D
var _restore_source_facing: Vector3
var _restore_configuration_sha256: String = ""
var _restore_scheduler_parent: WeakRef
var _restore_scheduler_script: Script
var _restore_hero_parent: WeakRef
var _restore_hero_script: Script
var _restore_hero_collision: CollisionShape3D
var _restore_hero_capsule: CapsuleShape3D
var _restore_hero_body_signature: Dictionary = {}


func configure(role_id: String, source_id: String, initially_dormant: bool = true, approach_enabled: bool = false) -> bool:
	if is_instance_valid(_scheduler) or _transaction_depth > 0 or _snapshot_busy:
		return _reject("Configure immutable Mushroom Selenite data before binding")
	var selected: String = ROLE_SWARM if role_id in ["C31", ROLE_SWARM] else (ROLE_GUARD if role_id in ["C32", ROLE_GUARD] else "")
	if selected.is_empty() or not _stable_id(source_id):
		return _reject("Only canonical C31/A1-E2 or C32/A1-E3 and a stable source ID are supported")
	if approach_enabled and selected != ROLE_SWARM:
		return _reject("Only C31 can opt in to authored approach; C32 stays stationary")
	var approach: Dictionary = Approach.PROVISIONAL_TUNING.duplicate(true)
	approach.enabled = approach_enabled
	var raw: Dictionary = (SWARM_RAW_ROLE if selected == ROLE_SWARM else GUARD_RAW_ROLE).duplicate(true)
	var floors: Dictionary = {"windup_s": raw.windup_s, "lock_s": raw.lock_s, "recovery_s": raw.recovery_s}
	var difficulty = Difficulty.new()
	for profile_id: String in ["assisted", "standard", "challenge"]:
		var role: Dictionary = difficulty.resolve_role(raw, profile_id, floors)
		if role.is_empty(): return _reject(difficulty.last_error)
		if selected == ROLE_SWARM and float(SWARM_LUNGE.distance) / float(SWARM_LUNGE.speed) > float(role.active_s):
			return _reject("Canonical grounded hop must fit its complete native active window")
	var next: Dictionary = {"role_id": selected, "entity_id": "C31" if selected == ROLE_SWARM else "C32", "source_id": source_id, "raw_role": raw, "timing_floors": floors, "lunge": SWARM_LUNGE.duplicate(true) if selected == ROLE_SWARM else {}, "lane": GUARD_LANE.duplicate(true) if selected == ROLE_GUARD else {}, "initially_dormant": initially_dormant, "approach": approach}
	if not _configuration.is_empty():
		if not _same(next, _configuration): return _reject("Configured role identity and provisional tuning are immutable")
		last_error = ""
		return true
	_configuration = next
	max_hp = float(raw.max_hp)
	hp = max_hp
	dormant = initially_dormant
	_approach_driving = false
	if is_node_ready(): _apply_lifecycle_flags()
	last_error = ""
	return true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	process_physics_priority = 100
	collision_layer = 2
	collision_mask = 1
	_collision = CollisionShape3D.new()
	_collision.name = "BodyCollision"
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.45
	_collision.shape = capsule
	_collision.position = Vector3(0.0, 0.73, 0.0)
	add_child(_collision)
	_body_signature = Motion.source_description(self).get("signature", {}).duplicate(true)
	_retained_capsule = capsule
	_native_body_properties = _read_native_body_properties()
	_cue = CueScript.new()
	_cue.name = "ThreatCue"
	add_child(_cue)
	_build_greybox()
	_apply_lifecycle_flags()
	var restore_owner: CinderLevel = _restore_owner_level()
	_restore_level_ref = weakref(restore_owner) if restore_owner != null else null
	_restore_level_script = restore_owner.get_script() as Script if restore_owner != null else null
	_restore_source_parent = weakref(get_parent())
	_restore_source_script = get_script() as Script
	_restore_source_transform = global_transform
	_restore_source_facing = _facing
	_restore_configuration_sha256 = ExactJson.stringify(_configuration).sha256_text() if not _configuration.is_empty() else ""


const RESTORE_RECIPIENT_API: String = "act1-restore-recipient-construction-1"
const RESTORE_RECIPIENT_KEYS: Array[String] = ["api_revision", "source_id", "room_id", "installed_rooms", "installed_fields", "configuration_sha256", "authored_position"]


func construct_restore_recipient(candidate: CinderLevel, descriptor: Dictionary) -> bool:
	# This does not restore an actor. It only exposes a genuine pristine living
	# native recipient in an actual paused, nonplayable candidate for real bind.
	var error: String = _restore_recipient_error(candidate, descriptor, 0)
	if not error.is_empty(): return _reject(error)
	_transaction_depth += 1
	var decision: Variant = candidate.call("restore_recipient_construction_error", self, descriptor.duplicate(true))
	# Parent must be literally pure. Recheck actual aliases/resources/pristine
	# state after the call; a copied source ID/empty string is not sole custody.
	error = _restore_recipient_error(candidate, descriptor, 1)
	if not decision is String or not String(decision).is_empty() or not error.is_empty():
		_transaction_depth -= 1
		return _reject(error if not error.is_empty() else (String(decision) if decision is String else "Owned restore entitlement must return a literal String"))
	# Consume before the first lifecycle property changes. No ordinary activation,
	# role/profile/cycle/HP/sample/hurt/pose/ground/stamp write, draw or signal.
	_restore_recipient_constructed = true
	dormant = false
	_apply_lifecycle_flags()
	error = _retained_body_error()
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty(): error = art_binding_error()
	_transaction_depth -= 1
	# A post-property failure consumes this partial candidate; the owner disposes
	# it. Do not heal/rewind or reuse a failed constructor as a new native source.
	if not error.is_empty(): return _reject("Dispose partial native restore recipient: " + error)
	last_error = ""
	return true


func _restore_recipient_error(candidate: CinderLevel, descriptor: Dictionary, depth: int) -> String:
	if _restore_recipient_constructed or _transaction_depth != depth or _snapshot_busy or _cancelling or _spore_cancel_delivering:
		return "One-shot restore construction must run outside actor state/cancellation callbacks"
	if not is_instance_valid(candidate) or not candidate.is_inside_tree() or candidate.is_queued_for_deletion() or not candidate.is_restore_candidate() or not get_tree().paused:
		return "Actual fresh paused CinderLevel restore candidate required"
	var owner: Variant = _restore_level_ref.get_ref() if _restore_level_ref != null else null
	var parent: Variant = _restore_source_parent.get_ref() if _restore_source_parent != null else null
	if owner != candidate or _restore_owner_level() != candidate or get_parent() != parent or candidate.get_script() != _restore_level_script or get_script() != _restore_source_script or _restore_source_script == null or _restore_source_script.resource_path != "res://scripts/acts/act1/mushroom_selenite.gd":
		return "Retain the actual ready source/script/parent and nearest owning candidate"
	if not candidate.has_method("restore_recipient_construction_error") or not _live_bindings() or candidate.hero != _hero or candidate.get("scheduler") != _scheduler or candidate.get_world_3d() != get_world_3d():
		return "Owned saved-prefix entitlement and actual same-candidate Hero/Scheduler aliases required"
	var scheduler_parent: Variant = _restore_scheduler_parent.get_ref() if _restore_scheduler_parent != null else null
	var player_parent: Variant = _restore_hero_parent.get_ref() if _restore_hero_parent != null else null
	if not candidate.is_ancestor_of(_scheduler) or _scheduler.get_parent() != scheduler_parent or _scheduler.get_script() != _restore_scheduler_script or _hero.get_parent() != player_parent or _hero.get_script() != _restore_hero_script:
		return "Retain actual earlier-physics Scheduler/Player script and native parent identities"
	if global_transform != _restore_source_transform or _facing != _restore_source_facing or _restored_floor_contact != -1:
		return "Fresh recipient keeps its actual authored native transform/facing and unset restoration floor cache"
	var error: String = _retained_body_error()
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty(): error = art_binding_error()
	if not error.is_empty(): return error
	if not dormant or not _configuration.get("initially_dormant", false) or not _dormant_state_error().is_empty():
		return "Only a genuinely pristine configured initially-dormant full-HP recipient can be constructed"
	if _cue.get_script() != CueScript or _sprite_art.get_script() != ArtScript or _native_codec.get_script() != NativeCodec:
		return "Retain actual owned codec/role-art and shared cue scripts"
	error = String(_native_codec.call("configuration_error", _configuration))
	if not error.is_empty(): return error
	if _restore_configuration_sha256.is_empty() or ExactJson.stringify(_configuration).sha256_text() != _restore_configuration_sha256:
		return "Retain the actual immutable ready-time source configuration"
	if _spore_consumer_ref != null or not _spore_consumer_id.is_empty() or not _spore_episode_id.is_empty() or _spore_phase != "none" or _spore_progress != 0.0 or _spore_direction != Vector3.FORWARD or _spore_nested_damage_used or _bound_spore_route_guard.is_valid() or _bound_spore_route_guard_required:
		return "Fresh native restore recipient cannot retain a prior environment binding/stamp/history"
	var player_body: Dictionary = Motion.source_description(_hero)
	if player_body.has("error") or player_body.get("collision") != _restore_hero_collision or not is_instance_valid(_restore_hero_collision) or _restore_hero_collision.shape != _restore_hero_capsule or _hero.get_node_or_null("BodyCollision") != _restore_hero_collision or not _same(player_body.get("signature", {}), _restore_hero_body_signature):
		return "Retain the actual shared Player capsule node/resource/native properties"
	var control: Dictionary = _scheduler.source_control_state(self)
	if control.get("api_revision") != "scheduler-source-control-1" or not control.get("source_instance_id") is int or control.source_instance_id != get_instance_id() or not control.get("outside_transaction") is bool or control.outside_transaction != true or not control.get("encounter_id") is String or control.encounter_id != "" or not control.get("clock_s") is float or control.clock_s != 0.0 or not control.get("reservations") is Array or not control.reservations.is_empty() or not control.has("cooldown") or control.cooldown != null or not _scheduler.encounter_profile().is_empty() or _scheduler.get_clock() != 0.0 or _scheduler.has_committed_exchange():
		return "Actual fresh unbegun Scheduler must retain empty profile/clock/leases/readiness"
	error = _restore_descriptor_error(descriptor)
	return error


func _restore_descriptor_error(descriptor: Dictionary) -> String:
	var error: String = Codec.value_error(descriptor)
	if error.is_empty(): error = Codec.keys_error(descriptor, RESTORE_RECIPIENT_KEYS)
	if not error.is_empty(): return error
	if descriptor.api_revision != RESTORE_RECIPIENT_API or not descriptor.source_id is String or descriptor.source_id != _configuration.source_id or not descriptor.room_id is String or not _stable_id(descriptor.room_id) or not descriptor.installed_rooms is Array or descriptor.installed_rooms.is_empty() or descriptor.installed_rooms.size() > 5 or not descriptor.installed_fields is Array or descriptor.installed_fields.size() > 4 or not descriptor.configuration_sha256 is String or not Codec.is_vector3(descriptor.authored_position):
		return "Closed owned constructor source/room/prefix/field/configuration descriptor required"
	var rooms: Array = []
	for value: Variant in descriptor.installed_rooms:
		if not value is String or not _stable_id(value) or rooms.has(value): return "Distinct bounded installed room IDs required"
		rooms.append(value)
	var fields: Array = []
	for value: Variant in descriptor.installed_fields:
		if not value is String or not _stable_id(value) or fields.has(value): return "Distinct bounded installed field IDs required"
		fields.append(value)
	if not rooms.has(descriptor.room_id) or descriptor.configuration_sha256 != _restore_configuration_sha256 or not _same(descriptor.authored_position, Codec.vector3(_restore_source_transform.origin)):
		return "Constructor descriptor must match actual immutable source configuration/authored placement and installed room"
	# Ordered contiguous prefix, source->room membership, exact field subsets and
	# copied saved-stage correspondence remain the owning parent/aggregate codec's
	# single authority. No raw saved actor state is interpreted here.
	return ""


func _restore_owner_level() -> CinderLevel:
	var node: Node = get_parent()
	while is_instance_valid(node):
		if node is CinderLevel: return node as CinderLevel
		node = node.get_parent()
	return null

func activate() -> bool:
	if not _live_bindings() or _transaction_depth > 0 or _snapshot_busy or _cancelling or not activation_guard.is_valid():
		return _reject("Activation requires a parent fresh-boundary guard outside callbacks")
	var error: String = _activation_error()
	if not error.is_empty():
		return _reject(error)
	_transaction_depth += 1
	var entitled: Variant = activation_guard.call(String(_configuration.source_id))
	# Keep the barrier across the callback and recheck native/lifecycle/public state.
	error = _activation_error()
	if not entitled is bool or entitled != true or not error.is_empty():
		_transaction_depth -= 1
		return _reject(error if not error.is_empty() else "Parent did not grant this source at its actual fresh encounter boundary")
	dormant = false
	_apply_lifecycle_flags()
	last_error = ""
	state_changed.emit(state())
	_transaction_depth -= 1
	return true


## Sole production court may expose each pristine helper once in its ongoing
## King epoch. This never calls begin/end, assigns a role, or clears cooldowns.
func activate_court_entry(court: CinderLevel, encounter_id: String) -> bool:
	var error: String = _court_entry_activation_error(court, encounter_id, 0)
	if not error.is_empty(): return _reject(error)
	_transaction_depth += 1
	var boundary: Dictionary = _court_entry_boundary()
	var decision: Variant = court.call("court_entry_activation_error", self, encounter_id)
	error = _court_entry_activation_error(court, encounter_id, 1)
	if error.is_empty() and _court_entry_boundary() != boundary:
		error = "Pure court activation entitlement changed actual source/Player/Scheduler custody"
	if not decision is String or not String(decision).is_empty() or not error.is_empty():
		_transaction_depth -= 1
		return _reject(error if not error.is_empty() else (String(decision) if decision is String else "Court activation entitlement must return a literal String"))
	# A partial failed exposure is consumed; dispose its parent instead of healing
	# lifecycle flags or re-granting this native object's one-shot entitlement.
	_court_entry_consumed = true
	dormant = false
	_apply_lifecycle_flags()
	var exposed: Dictionary = boundary.duplicate(true)
	exposed.consumed = true
	exposed.actor.dormant = false
	exposed.actor.status = "idle"
	error = _court_motion_error(court, 1)
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty(): error = art_binding_error()
	if error.is_empty() and _court_entry_boundary() != exposed:
		error = "Court exposure must preserve all actual native state except its consumed lifecycle"
	if error.is_empty():
		state_changed.emit(state())
		error = _court_motion_error(court, 1)
		if error.is_empty() and _court_entry_boundary() != exposed:
			error = "Court activation observer changed the actual native exposure boundary"
	_transaction_depth -= 1
	if not error.is_empty(): return _reject("Dispose partial court helper exposure: " + error)
	last_error = ""
	return true


func _court_parent_error(court: CinderLevel, depth: int) -> String:
	if _transaction_depth != depth or _snapshot_busy or _cancelling or _spore_cancel_delivering or not _live_bindings():
		return "Court entry requires actual retained native bindings outside nested callbacks"
	if not is_instance_valid(court) or not court.is_inside_tree() or not court.is_node_ready() or court.is_queued_for_deletion() or court.is_restore_candidate() or court.level_id != "A1-L4" or get_tree().paused or _hero.dead:
		return "Actual ready unpaused playable A1-L4 court and living shared Player required"
	var owner: Variant = _restore_level_ref.get_ref() if _restore_level_ref != null else null
	var parent: Variant = _restore_source_parent.get_ref() if _restore_source_parent != null else null
	if owner != court or _restore_owner_level() != court or get_parent() != parent or court.get_script() != _restore_level_script or _restore_level_script == null or _restore_level_script.resource_path != COURT_SCRIPT_PATH or get_script() != _restore_source_script or _restore_source_script == null or _restore_source_script.resource_path != "res://scripts/acts/act1/mushroom_selenite.gd":
		return "Court entry retains the exact ready-time owning court/source scripts and parent"
	if _configuration.get("role_id") != ROLE_GUARD or _configuration.get("entity_id") != "C32" or _configuration.get("source_id") not in COURT_HELPER_IDS or _configuration.get("initially_dormant") != true or _configuration.get("approach", {}).get("enabled") != false:
		return "Only the court's two canonical initially-dormant C32 helper identities can enter"
	var scheduler_parent: Variant = _restore_scheduler_parent.get_ref() if _restore_scheduler_parent != null else null
	var player_parent: Variant = _restore_hero_parent.get_ref() if _restore_hero_parent != null else null
	if court.hero != _hero or court.get("scheduler") != _scheduler or not court.is_ancestor_of(_scheduler) or court.get_world_3d() != get_world_3d() or _scheduler.get_parent() != scheduler_parent or _scheduler.get_script() != _restore_scheduler_script or _hero.get_parent() != player_parent or _hero.get_script() != _restore_hero_script:
		return "Court entry retains actual same-world bound Player/Scheduler aliases and parents"
	var player_body: Dictionary = Motion.source_description(_hero)
	if player_body.has("error") or player_body.get("collision") != _restore_hero_collision or not is_instance_valid(_restore_hero_collision) or _restore_hero_collision.shape != _restore_hero_capsule or not _same(player_body.get("signature", {}), _restore_hero_body_signature):
		return "Court entry retains the actual shared Player capsule and native body properties"
	var error: String = _retained_body_error()
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty(): error = art_binding_error()
	if not error.is_empty(): return error
	if _restore_configuration_sha256.is_empty() or ExactJson.stringify(_configuration).sha256_text() != _restore_configuration_sha256 or _native_codec.get_script() != NativeCodec or _cue.get_script() != CueScript or _sprite_art.get_script() != ArtScript:
		return "Court entry retains immutable native configuration, codec, cue and role art"
	if error.is_empty() and get_parent() is Node3D and not (get_parent() as Node3D).is_visible_in_tree():
		error = "Court entry cannot reveal a helper under a hidden parent"
	return error


func _court_entry_activation_error(court: CinderLevel, encounter_id: String, depth: int) -> String:
	var error: String = _court_parent_error(court, depth)
	if not error.is_empty(): return error
	if _court_entry_consumed or _restore_recipient_constructed or not dormant or not _dormant_state_error().is_empty() or global_transform != _restore_source_transform or _facing != _restore_source_facing or _restored_floor_contact != -1:
		return "Court helper exposure requires its one-shot pristine authored placement/facing"
	if not court.has_method("court_entry_activation_error") or not _stable_id(encounter_id):
		return "Actual court must supply its literal one-shot entry entitlement and stable epoch"
	if not _court_entry_environment_error().is_empty(): return _court_entry_environment_error()
	return _court_entry_control_error(encounter_id)


func _court_entry_control_error(encounter_id: String = "") -> String:
	var control: Dictionary = _scheduler.source_control_state(self)
	var profile: Dictionary = _scheduler.encounter_profile()
	if control.get("api_revision") != "scheduler-source-control-1" or control.get("source_instance_id") != get_instance_id() or control.get("outside_transaction") != true or not control.get("encounter_id") is String or not _stable_id(control.encounter_id) or (not encounter_id.is_empty() and control.encounter_id != encounter_id) or not control.get("clock_s") is float or not Codec.in_range(control.clock_s, 0.0, 1000000000.0) or control.clock_s != _scheduler.get_clock() or profile.is_empty() or not control.get("reservations") is Array or not control.reservations.is_empty() or not control.has("cooldown") or control.cooldown != null:
		return "Court helper must retain the ongoing nonempty native epoch/profile and no own lease/readiness"
	return ""


func _court_entry_environment_error() -> String:
	if _spore_consumer_ref != null or not _spore_consumer_id.is_empty() or not _spore_episode_id.is_empty() or _spore_phase != "none" or _spore_progress != 0.0 or _spore_direction != Vector3.FORWARD or _spore_nested_damage_used or _bound_spore_route_guard.is_valid() or _bound_spore_route_guard_required:
		return "Court entry cannot repurpose a genuine environment binding/stamp/history"
	return ""


## Pure local callback witness; no pruning accessor or paused capture is used.
func _court_entry_boundary() -> Dictionary:
	return {"actor": pure_presentation_state(), "transform": global_transform,
		"ground": _restored_floor_contact, "cue": _cue.state(),
		"consumed": _court_entry_consumed, "constructed": _restore_recipient_constructed,
		"control": _scheduler.source_control_state(self), "profile": _scheduler.encounter_profile(),
		"hero_transform": _hero.global_transform, "hero_hp": _hero.hp,
		"hero_shells": _hero.shells, "hero_response": _hero.get_threat_response_state()}


func _activation_error() -> String:
	if not _live_bindings():
		return "Activation requires retained ready source, scheduler and Player bindings"
	if not _configuration.get("initially_dormant", false) or not dormant or dead or not _dormant_state_error().is_empty():
		return "Only a pristine initially dormant source can activate once"
	if _scheduler.encounter_profile().is_empty() or _scheduler.get_clock() != 0.0 or _scheduler.has_committed_exchange():
		return "Parent must establish a fresh nonempty encounter/profile before activation"
	var error: String = _retained_body_error()
	if error.is_empty():
		error = _lifecycle_error()
	if error.is_empty():
		error = art_binding_error()
	if error.is_empty() and get_parent() is Node3D and not (get_parent() as Node3D).is_visible_in_tree():
		error = "Activation cannot reveal a source under a hidden ancestor"
	return error


func bind(scheduler: CinderThreatScheduler, hero: CinderPlayer) -> bool:
	if _transaction_depth > 0 or _snapshot_busy or not is_inside_tree() or not is_node_ready() or _configuration.is_empty():
		return _reject("Bind a ready configured C31/C32 outside callbacks")
	if not is_instance_valid(scheduler) or not scheduler.is_inside_tree() or scheduler.get_world_3d() != get_world_3d() or scheduler.process_physics_priority >= process_physics_priority or not is_instance_valid(hero) or not hero.is_inside_tree() or hero.is_queued_for_deletion() or hero.get_world_3d() != get_world_3d() or hero.process_physics_priority >= process_physics_priority:
		return _reject("Same-world earlier-physics scheduler and actual shared hero required")
	if is_instance_valid(_scheduler):
		return true if _scheduler == scheduler and _hero == hero else _reject("C31/C32 scheduler and hero bindings are immutable")
	_scheduler = scheduler
	_hero = hero
	_restore_scheduler_parent = weakref(scheduler.get_parent())
	_restore_scheduler_script = scheduler.get_script() as Script
	_restore_hero_parent = weakref(hero.get_parent())
	_restore_hero_script = hero.get_script() as Script
	var restore_player_body: Dictionary = Motion.source_description(hero)
	_restore_hero_body_signature = restore_player_body.get("signature", {}).duplicate(true)
	_restore_hero_collision = hero.get_node_or_null("BodyCollision") as CollisionShape3D
	_restore_hero_capsule = _restore_hero_collision.shape as CapsuleShape3D if _restore_hero_collision != null else null
	_scheduler.reservation_invalidated.connect(_on_invalidated)
	last_error = ""
	return true


## context has exactly CONTEXT_KEYS, including the actual common world_root.
## Target selects a continuous planar direction; distance is canonical role data.
## This pure preview grants no lease, cycle, role/profile assignment or movement.
func preview_start(target: Vector3, context: Dictionary) -> Dictionary:
	var direction: Vector3 = _target_direction(target)
	var prepared: Dictionary = _prepare_start(context, direction, context.get("world_root") as Node3D)
	if not prepared.get("accepted", false): return prepared
	return _scheduler.preview_lunge(self, prepared.threat, prepared.response) if _configuration.role_id == ROLE_SWARM else _scheduler.preview_stationary(self, prepared.threat, prepared.response)


func start(target: Vector3, context: Dictionary, preview: Dictionary = {}) -> Dictionary:
	var direction: Vector3 = _target_direction(target)
	var prepared: Dictionary = _prepare_start(context, direction, context.get("world_root") as Node3D)
	if not prepared.get("accepted", false): return _denied(String(prepared.reason))
	# Require a complete fresh native correspondence even when the caller has
	# no copied preview. The explicit root supports actual custody/framing data.
	var selected: Dictionary = preview
	if selected.is_empty():
		selected = _scheduler.preview_lunge(self, prepared.threat, prepared.response) if _configuration.role_id == ROLE_SWARM else _scheduler.preview_stationary(self, prepared.threat, prepared.response)
	if not selected.get("accepted", false): return _denied(String(selected.get("reason", "Native admission preview rejected")))
	_transaction_depth += 1
	var answer: Dictionary = _scheduler.request_lunge(self, prepared.threat, prepared.response, selected) if _configuration.role_id == ROLE_SWARM else _scheduler.request_attack(self, prepared.threat, prepared.response, selected)
	if answer.get("accepted", false):
		_reservation_id = String(answer.reservation_id)
		_role_encounter_id = context.encounter_id
		_profile_id = String(prepared.profile_id)
		_resolved_role = prepared.role.duplicate(true)
		_cycle += 1
		# Opt-in direction is already the stopped aligned native facing. The
		# default component path retains its original target-facing behavior.
		_facing = direction
		_approach_driving = false
		_hit_ids.clear()
		_pending_segments.clear()
		_sample_now()
		_last_cancel_reason = ""
		_present(_scheduler.reservation_state(_reservation_id))
	else:
		last_error = String(answer.get("reason", "Native attack rejected"))
	_transaction_depth -= 1
	return answer.duplicate(true)


func _target_direction(target: Vector3) -> Vector3:
	if not target.is_finite(): return Vector3.ZERO
	var delta: Vector3 = target - global_position
	var planar := Vector3(delta.x, 0.0, delta.z)
	if not planar.is_finite() or planar.length() <= Motion.EPSILON: return Vector3.ZERO
	var direction: Vector3 = planar.normalized()
	if _configuration.get("approach", {}).get("enabled", false):
		# Reuse the actual gradual heading; admission cannot snap it to a target.
		return _facing if direction.distance_to(_facing) <= Motion.EPSILON else Vector3.ZERO
	return direction


func _prepare_start(response_context: Dictionary, direction: Vector3, world_root: Node3D) -> Dictionary:
	if not _live_bindings() or _transaction_depth > 0 or _snapshot_busy or _cancelling or dead or dormant or get_tree().paused or not _reservation_id.is_empty() or _hurt_left_s > 0.0 or velocity != Vector3.ZERO or _approach_driving or not is_visible_in_tree() or _cycle >= Codec.MAX_SAFE_INTEGER:
		return {"accepted": false, "reason": "Start requires an activated live stopped unpaused idle C31/C32 outside callbacks"}
	if not Codec.keys_error(response_context, CONTEXT_KEYS).is_empty() or not _stable_id(response_context.get("encounter_id")) or not Geometry.finite_vector(direction) or absf(direction.y) > Motion.EPSILON or absf(direction.length() - 1.0) > Motion.EPSILON:
		return {"accepted": false, "reason": "Authored encounter context and fixed normalized world direction required"}
	if not is_instance_valid(world_root) or not world_root.is_inside_tree() or world_root.is_queued_for_deletion() or world_root.get_world_3d() != get_world_3d() or not world_root.is_ancestor_of(self) or not world_root.is_ancestor_of(_hero) or not world_root.is_ancestor_of(_scheduler):
		return {"accepted": false, "reason": "Actual containing same-world root must retain actor, hero and scheduler"}
	var guard_error: String = _spore_fresh_error()
	if guard_error.is_empty():
		guard_error = _retained_body_error()
	if guard_error.is_empty():
		guard_error = _lifecycle_error()
	if guard_error.is_empty():
		guard_error = art_binding_error()
	if guard_error.is_empty():
		guard_error = _presentation_error()
	if not guard_error.is_empty():
		return {"accepted": false, "reason": guard_error}
	var response: Dictionary = _hero.get_threat_response_state()
	if not String(response.get("pending_weapon_id", "")).is_empty():
		return {"accepted": false, "reason": "Wait for the actual pending weapon application"}
	for key: String in CONTEXT_KEYS:
		if key not in ["encounter_id", "world_root"]:
			response[key] = response_context[key]
	if world_root != null:
		response.world_root = world_root
	var profile: Dictionary = _scheduler.encounter_profile()
	var profile_id: String = String(profile.get("id", ""))
	var difficulty = Difficulty.new()
	var role: Dictionary = _resolved_role.duplicate(true)
	if _role_encounter_id != response_context.encounter_id:
		role = difficulty.resolve_role(_configuration.raw_role, profile_id, _configuration.timing_floors)
	elif _profile_id != profile_id:
		return {"accepted": false, "reason": "Resolve the fixed encounter profile only once"}
	if role.is_empty():
		return {"accepted": false, "reason": difficulty.last_error}
	var threat: Dictionary
	if _configuration.role_id == ROLE_SWARM:
		var lunge: Dictionary = _configuration.lunge.duplicate(true)
		lunge["direction"] = direction
		threat = {"role": role, "source_stationary": false, "opening_stationary": true, "cooldown_remaining_s": 0.0, "lunge": lunge}
	else:
		var lane: Dictionary = Geometry.lane(global_position, global_position + direction * float(_configuration.lane.length), float(_configuration.lane.radius))
		threat = {"role": role, "source_stationary": true, "opening_stationary": true, "cooldown_remaining_s": 0.0, "geometry": lane, "opening_position": global_position}
	return {"accepted": true, "threat": threat, "response": response, "role": role, "profile_id": profile_id}


func take_damage(amount: float, impulse: Vector3) -> Dictionary:
	var result: Dictionary = {"accepted": false, "hp_damage": 0.0, "target_id": get_instance_id(), "target_alive_before_hit": hp > 0.0 and not dead and not dormant and not is_queued_for_deletion()}
	# Exactly ONE real injury may arrive from the native spore-cancel delivery.
	# No phase/hit/snapshot/general recursive damage boundary is relaxed.
	var nested: bool = _transaction_depth == 1 and _cancelling and _spore_cancel_delivering and not _spore_nested_damage_used
	if not _live_bindings() or _snapshot_busy or (_transaction_depth > 0 and not nested) or not result.target_alive_before_hit or not is_finite(amount) or amount <= 0.0 or not impulse.is_finite():
		return result
	if nested: _spore_nested_damage_used = true
	_transaction_depth += 1
	# Outer native cancellation already cleared this exchange before observers.
	# Recursively cancelling it would destroy the bounded injury delivery order.
	if nested:
		_last_cancel_reason = "actual_player_damage"
	else:
		cancel("actual_player_damage")
	_approach_driving = false
	var before: float = hp
	hp = maxf(0.0, hp - amount)
	result.accepted = true
	result.hp_damage = before - hp
	if hp == 0.0:
		dead = true
		_hurt_left_s = 0.0
		velocity = Vector3.ZERO
		_spore_episode_id = ""
		_spore_phase = "none"
		_spore_progress = 0.0
		_scheduler.cancel_owner(self, "source_defeated")
		collision_layer = 0
		collision_mask = 0
		# Immediate genuine death state is needed by the synchronous native
		# protocol post-callback lifecycle proof, before defeat observers.
		_collision.disabled = true
		remove_from_group("enemies")
		visible = false
	else:
		velocity += impulse
		_hurt_left_s = HURT_S
		if not _spore_episode_id.is_empty():
			_spore_phase = "interrupted"
			_spore_progress = 0.0
	# A bound real injury/death changes the stamp before any observer. Select
	# quiet standing now; inherited death visibility remains actor-owned.
	if not _spore_consumer_id.is_empty(): _draw_greybox()
	# Real HP/impulse/hurt and the stamp precede Route release and all defeat/
	# state observers. Native release never overwrites an external impulse.
	var consumer: CinderSporeRepulsion = _spore_consumer()
	if consumer != null:
		consumer.source_interrupted(self, "actual_death" if dead else "actual_damage")
	if dead:
		defeated.emit(String(_configuration.source_id))
	state_changed.emit(state())
	_transaction_depth -= 1
	return result


func cancel(reason: String = "mushroom_selenite_cancelled") -> bool:
	if _snapshot_busy or _cancelling:
		return false
	_approach_driving = false
	if dormant:
		return true
	_cancelling = true
	_transaction_depth += 1
	var id: String = _reservation_id
	_reservation_id = ""
	_sample.clear()
	_pending_segments.clear()
	_hit_ids.clear()
	_last_cancel_reason = reason
	if not id.is_empty() and is_instance_valid(_scheduler):
		_scheduler.cancel(id, reason)
	_present({}, true)
	_transaction_depth -= 1
	_cancelling = false
	return true


func state() -> Dictionary:
	var record: Dictionary = _scheduler.reservation_state(_reservation_id) if is_instance_valid(_scheduler) and not _reservation_id.is_empty() else {}
	return _presentation_state(record)


## Quiet parent cache refresh: raw source control never prunes or emits.
func pure_presentation_state() -> Dictionary:
	var control: Dictionary = _scheduler.source_control_state(self) if is_instance_valid(_scheduler) else {}
	var records: Array = control.get("reservations", [])
	return _presentation_state(records[0] if records.size() == 1 else {})


func _presentation_state(record: Dictionary) -> Dictionary:
	var phase: String = String(record.get("state", "clear"))
	var status: String = "dormant" if dormant else ("defeated" if dead else ("running" if not record.is_empty() else ("hurt" if _hurt_left_s > 0.0 else "idle")))
	var result: Dictionary = {"api_revision": API_REVISION, "role_id": _configuration.get("role_id", ""), "entity_id": _configuration.get("entity_id", ""), "spore_support": not _spore_consumer_id.is_empty(), "presentation_status": "authored_C31_C32_pose_pixels", "source_id": _configuration.get("source_id", ""), "hp": hp, "dead": dead, "dormant": dormant, "status": status, "phase": phase, "reservation_id": _reservation_id, "cycle": _cycle, "source_position": global_position, "opening_position": record.get("opening_position", global_position), "geometry": record.get("geometry", {}).duplicate(true), "resolved_role": _resolved_role.duplicate(true), "hit_ids": _hit_ids.duplicate(), "hurt_left_s": _hurt_left_s, "approach_enabled": _configuration.get("approach", {}).get("enabled", false), "approach_driving": _approach_driving, "velocity": velocity, "facing": _facing, "last_cancel_reason": _last_cancel_reason}
	if not _spore_consumer_id.is_empty():
		result["repulsion"] = _encode_repulsion()
	for key: String in ["start_s", "lock_from_s", "active_from_s", "active_until_s", "recovery_until_s", "cooldown_until_s", "armed", "adapter"]:
		if record.has(key):
			result[key] = record[key].duplicate(true) if record[key] is Dictionary else record[key]
	return result


## Pure retained native binding, deliberately distinct from state() which prunes.
func get_spore_native_bindings() -> Dictionary:
	if not _live_bindings() or not _retained_body_error().is_empty(): return {}
	return {"api_revision": SPORE_ACTOR_REVISION, "actor_revision": API_REVISION, "source_id": _configuration.source_id, "scheduler": _scheduler, "player": _hero, "codec": _native_codec, "configuration": _configuration.duplicate(true)}


## Common live response has no Scheduler reservation/cooldown query or callback.
## Dead retained bodies stay available for genuine defeat/tombstone validation.
func get_spore_response_state() -> Dictionary:
	if not _live_bindings() or not _retained_body_error().is_empty() or not _lifecycle_error().is_empty(): return {}
	var direction: Vector3 = _facing if _spore_consumer_id.is_empty() else _spore_direction
	return {"api_revision": SPORE_ACTOR_REVISION, "source_id": _configuration.source_id, "consumer_id": _spore_consumer_id, "alive": not dead and not dormant, "grounded": _grounded(), "position": global_position, "velocity": velocity, "facing": _facing, "hurt_remaining_s": _hurt_left_s, "body_collision_path": "BodyCollision", "support_radius": float(_retained_capsule.radius) + RepulsionRoute.FLOOR_SKIN, "height": float(_retained_capsule.height), "episode_id": _spore_episode_id, "phase": _spore_phase, "direction": direction, "progress": _spore_progress, "outside_transaction": _transaction_depth == 0 and not _snapshot_busy and not _cancelling}


func spore_bind_error(consumer: Node, source_id: String) -> String:
	if not _live_bindings() or dead or dormant or _transaction_depth > 0 or _snapshot_busy or _cancelling or source_id != _configuration.source_id:
		return "Bind a living actual C31/C32 outside actor callbacks"
	var actual: CinderSporeRepulsion = consumer as CinderSporeRepulsion
	if not is_instance_valid(actual) or not actual.is_inside_tree() or actual.is_queued_for_deletion() or actual.get_world_3d() != get_world_3d() or not _stable_id(actual.consumer_id()) or not actual.source_binding_matches(self, source_id):
		return "Actual same-world consumer must already stage this permanent source"
	var error: String = _retained_body_error()
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty() and spore_route_guard_required and not spore_route_guard.is_valid():
		error = "Required owned spore route guard is unavailable"
	if error.is_empty() and not _spore_consumer_id.is_empty(): error = _spore_binding_error()
	if not error.is_empty(): return error
	var control: Dictionary = _scheduler.source_control_state(self)
	if control.is_empty() or not control.get("outside_transaction", false):
		return "Bind outside the actual Scheduler transaction"
	if not _spore_consumer_id.is_empty():
		return "" if _spore_consumer() == consumer and _spore_consumer_id == actual.consumer_id() else "Environmental consumer identity is immutable"
	if not _spore_episode_id.is_empty() or _spore_phase != "none":
		return "Fresh unbound source cannot carry an environmental episode"
	return ""


## Silent one-shot commit after parent/protocol pairwise prevalidation.
func bind_spore_repulsion(consumer: Node, source_id: String) -> bool:
	var error: String = spore_bind_error(consumer, source_id)
	if not error.is_empty(): return _reject(error)
	if not _spore_consumer_id.is_empty(): return true
	_bound_spore_route_guard = spore_route_guard
	_bound_spore_route_guard_required = spore_route_guard_required
	_spore_consumer_ref = weakref(consumer)
	_spore_consumer_id = (consumer as CinderSporeRepulsion).consumer_id()
	_spore_direction = _facing
	return true


func cancel_attack_for_spores(consumer: Node, episode_id: String, direction: Vector3) -> bool:
	var error: String = _spore_hook_error(consumer, episode_id)
	if not error.is_empty() or get_tree().paused or not _spore_episode_id.is_empty() or _hurt_left_s != 0.0 or not _grounded() or absf(velocity.y) > Motion.EPSILON or not _unit_direction(direction):
		return _reject(error if not error.is_empty() else "Environmental cancellation requires an unharmed grounded fresh source")
	var record: Dictionary = (consumer as CinderSporeRepulsion).source_state(String(_configuration.source_id))
	var control: Dictionary = _scheduler.source_control_state(self)
	if record.get("episode_id") != episode_id or record.get("phase") != "recoil" or not record.get("direction") is Vector3 or not _same(Codec.vector3(record.direction), Codec.vector3(direction)) or record.get("progress") != 0.0 or control.is_empty() or not control.get("outside_transaction", false):
		return _reject("Actual consumer must publish its exact prepared recoil before native cancellation")
	error = _spore_route_guard_error(consumer, episode_id, direction, "cancel", record, control)
	if not error.is_empty(): return _reject(error)
	# Stamp and suppression precede every synchronous native cancellation/cue
	# observer. Leave original approach velocity until real Route.acquire; only
	# the Scheduler may stop an owned lunge while cancelling its exact lease.
	_spore_episode_id = episode_id
	_spore_phase = "recoil"
	_spore_direction = direction
	_spore_progress = 0.0
	_approach_driving = false
	# Show the actual committed recoil stamp before native cancel observers.
	# This selects pixels only; the Scheduler still cancels the real exchange.
	_draw_greybox()
	_spore_cancel_delivering = true
	_spore_nested_damage_used = false
	var accepted: bool = cancel("spore_repulsion")
	_spore_cancel_delivering = false
	return accepted


func present_spore_phase(consumer: Node, episode_id: String, phase: String, progress: float) -> bool:
	var error: String = _spore_hook_error(consumer, episode_id)
	if not error.is_empty() or episode_id != _spore_episode_id or phase == "none" or phase not in SPORE_PHASES or not is_finite(progress) or progress < 0.0 or progress > 1.0:
		return false
	var record: Dictionary = (consumer as CinderSporeRepulsion).source_state(String(_configuration.source_id))
	if record.get("episode_id") != episode_id or record.get("phase") != phase or not _same(record.get("progress"), progress) or not record.get("direction") is Vector3 or not _same(Codec.vector3(record.direction), Codec.vector3(_spore_direction)):
		return false
	# Existing facing follows authoritative turn progress without a turn timer
	# or serialized origin. It changes only the art/facing vector, never basis.
	if phase == "turn":
		var prior: float = _spore_progress if _spore_phase == "turn" else 0.0
		if progress < prior: return false
		var fraction: float = (progress - prior) / (1.0 - prior) if prior < 1.0 else 0.0
		_facing = _facing.rotated(Vector3.UP, _facing.signed_angle_to(_spore_direction, Vector3.UP) * fraction).normalized()
	elif phase in ["retreat", "hold", "regroup"]:
		_facing = _spore_direction
	_spore_phase = phase
	_spore_progress = progress
	_draw_greybox()
	return true


func resume_spore_retreat(consumer: Node, episode_id: String, direction: Vector3) -> bool:
	var error: String = _spore_hook_error(consumer, episode_id)
	if not error.is_empty() or get_tree().paused or episode_id != _spore_episode_id or _spore_phase != "interrupted" or _hurt_left_s != 0.0 or not _grounded() or velocity != Vector3.ZERO or not _reservation_id.is_empty() or not _unit_direction(direction): return false
	var record: Dictionary = (consumer as CinderSporeRepulsion).source_state(String(_configuration.source_id))
	var control: Dictionary = _scheduler.source_control_state(self)
	if record.get("episode_id") != episode_id or record.get("phase") != "interrupted" or control.is_empty() or not control.get("outside_transaction", false) or not control.reservations.is_empty(): return false
	error = _spore_route_guard_error(consumer, episode_id, direction, "continue", record, control)
	if not error.is_empty(): return _reject(error)
	# Shared consumer assigns the continued direction AFTER actual acquisition.
	# Do not compare this new prepared direction with its previous record value.
	_spore_direction = direction
	_spore_phase = "retreat"
	_spore_progress = 0.0
	_approach_driving = false
	_draw_greybox()
	return true


func finish_spore_episode(consumer: Node, episode_id: String) -> bool:
	var error: String = _spore_hook_error(consumer, episode_id)
	if not error.is_empty() or episode_id != _spore_episode_id or _spore_phase != "regroup" or _hurt_left_s != 0.0 or velocity != Vector3.ZERO or not _reservation_id.is_empty(): return false
	var record: Dictionary = (consumer as CinderSporeRepulsion).source_state(String(_configuration.source_id))
	if record.get("episode_id") != episode_id or record.get("phase") != "regroup": return false
	_spore_episode_id = ""
	_spore_phase = "none"
	_spore_progress = 0.0
	# The coordinator keeps this tick held after finishing, so redraw the
	# cleared stamp synchronously instead of leaving regroup pixels stale.
	_draw_greybox()
	# Retain consumer, HP/profile/cooldown and unit direction. No fresh admission.
	return true


func get_cue() -> CinderThreatCue:
	return _cue


func get_art() -> Node3D:
	return _sprite_art


## Pure actual body/resource/lifecycle check for the parent's neighbor queries.
## No Scheduler accessor, callbacks, pose changes or motion permission.
func body_binding_error() -> String:
	var error: String = _retained_body_error()
	return _lifecycle_error() if error.is_empty() else error


func art_binding_error() -> String:
	# The billboard must remain at this real actor's feet. An inherited hidden
	# parent cannot be excused by the sprite's own local visible flag.
	if not is_instance_valid(_visual) or not _visual.is_inside_tree() or _visual.is_queued_for_deletion() or _visual.get_parent() != self or _visual.is_set_as_top_level() or not _visual.visible:
		return "C31/C32 requires its visible retained actor presentation parent"
	if _visual.position != Vector3.ZERO or _visual.scale != Vector3.ONE or _visual.rotation.x != 0.0 or _visual.rotation.z != 0.0 or not is_finite(_visual.rotation.y):
		return "C31/C32 presentation must retain its unscaled foot origin and planar facing"
	if not is_instance_valid(_sprite_art) or not _sprite_art.is_inside_tree() or _sprite_art.is_queued_for_deletion() or _sprite_art.get_parent() != _visual or not _sprite_art.visible:
		return "C31/C32 requires its retained pixel presentation"
	var error: String = String(_sprite_art.call("binding_error"))
	if not error.is_empty(): return error
	var art_phase: String = _art_phase()
	var pose: String = "standing" if art_phase in ["clear", "idle"] else art_phase
	if String(_sprite_art.call("role_id")) != String(_configuration.role_id) or String(_sprite_art.call("pose_name")) != pose:
		return "C31/C32 costume must match its actual immutable role and selected native/environmental phase"
	return ""


func _physics_process(delta: float) -> void:
	if dead or dormant or not _live_bindings() or get_tree().paused or _transaction_depth > 0:
		return
	# Genuine coordinator step MUST precede this actor's ordinary transaction.
	# Route owns held motion; false permits only native hurt/airborne settlement
	# during an episode, never a second pursuit or new attack controller.
	var consumer: CinderSporeRepulsion = _spore_consumer()
	if not _spore_consumer_id.is_empty():
		if consumer == null:
			last_error = "Retained environmental consumer disappeared; fresh motion is suppressed"
			if _hurt_left_s <= 0.0 and _grounded() and velocity == Vector3.ZERO: return
		elif consumer.step_source(self, delta):
			return
		if dead or dormant or not _live_bindings() or get_tree().paused or _transaction_depth > 0:
			return
	# Only these two helpers in the exact retained court opt in. All previous
	# C31/C32 consumers follow their original physics branches unchanged.
	if _step_court_entry_if_active(delta): return
	_transaction_depth += 1
	if not _reservation_id.is_empty():
		var record: Dictionary = _damage_boundary_record(false)
		if not record.is_empty() and _stage_sample():
			# The real actor physics interval is retained before cue/phase observers.
			# A synchronous held pause must neither deliver nor discard this path.
			_present(record)
			record = _damage_boundary_record(true)
			if not record.is_empty():
				_resolve_pending_segments()
	else:
		var was_hurt: bool = _hurt_left_s > 0.0
		_hurt_left_s = maxf(0.0, _hurt_left_s - delta)
		var horizontal := Vector3(velocity.x, 0.0, velocity.z)
		# A native impulse can outlive its .22s hurt clock. Never reinterpret that
		# residual velocity as approach-owned: settle to exact zero first.
		if _configuration.approach.enabled and _spore_fresh_error().is_empty() and not was_hurt and (_approach_driving or horizontal == Vector3.ZERO) and _grounded() and velocity.y == 0.0:
			_step_approach(delta)
			_transaction_depth -= 1
			return
		_approach_driving = false
		# Original authored hurt/gravity settling, including default components.
		velocity.x = move_toward(velocity.x, 0.0, HURT_BRAKING * delta)
		velocity.z = move_toward(velocity.z, 0.0, HURT_BRAKING * delta)
		if not _grounded():
			velocity.y -= GRAVITY * delta
		elif velocity.y < 0.0:
			velocity.y = 0.0
		move_and_slide()
		_restored_floor_contact = -1
		_draw_greybox()
	_transaction_depth -= 1


## Record a genuinely shortened entry without rebasing its original clock/path.
## The parent calls this synchronously before marking the corresponding original
## entry terminal; its pure stop entitlement remains available after the corridor
## provider withdraws motion. Damage/death use their original native paths instead.
func stop_court_entry_motion(court: CinderLevel, original_context: Dictionary, reason: String) -> Dictionary:
	var error: String = _court_motion_error(court, 0)
	if error.is_empty(): error = _court_motion_context_error(original_context, 1.0 / float(Engine.physics_ticks_per_second))
	if error.is_empty() and (reason not in ["blocked", "king_defeated"] or not court.has_method("court_entry_stop_error")):
		error = "Court entry stop requires its literal blocked/king_defeated entitlement"
	if not error.is_empty(): return _denied(error)
	_transaction_depth += 1
	var boundary: Dictionary = _court_entry_boundary()
	var decision: Variant = court.call("court_entry_stop_error", self, original_context.duplicate(true), reason)
	error = _court_motion_error(court, 1)
	if error.is_empty(): error = _court_motion_context_error(original_context, 1.0 / float(Engine.physics_ticks_per_second))
	if error.is_empty() and _court_entry_boundary() != boundary:
		error = "Pure court stop entitlement changed the actual native entry boundary"
	if not decision is String or not String(decision).is_empty() or not error.is_empty():
		_transaction_depth -= 1
		return _denied(error if not error.is_empty() else (String(decision) if decision is String else "Court stop entitlement must return a literal String"))
	# This is the entry's own grounded, unhurt, unleased velocity only. Do not
	# cancel an attack, brake a damage impulse, set hurt, heal or alter facing/pose.
	velocity = Vector3.ZERO
	var stopped: Dictionary = boundary.duplicate(true)
	stopped.actor.velocity = Vector3.ZERO
	error = _court_motion_error(court, 1)
	if error.is_empty() and _court_entry_boundary() != stopped:
		error = "Stopping entry must preserve every native field except its own velocity"
	_transaction_depth -= 1
	if not error.is_empty(): return _denied(error)
	last_error = ""
	# Native vectors remain runtime observations. The whole parent codec encodes
	# the original six-key record and actual terminal endpoint/outcome together.
	return {"accepted": true, "outcome": reason, "actual_endpoint": global_position,
		"velocity": velocity, "clock_s": float(boundary.control.clock_s),
		"original_context": original_context.duplicate(true)}


## Parent-owned finite nonattack entry. Empty context means ordinary stationary
## C32 physics. Actual injury, leases and environmental movement stay in their
## original branches; entry never invents an approach/hurt/attack ownership bit.
func _step_court_entry_if_active(delta: float) -> bool:
	if _configuration.get("role_id") != ROLE_GUARD or _configuration.get("source_id") not in COURT_HELPER_IDS:
		return false
	var court: CinderLevel = _restore_owner_level()
	if not is_instance_valid(court) or court.get_script() != _restore_level_script or _restore_level_script == null or _restore_level_script.resource_path != COURT_SCRIPT_PATH or not court.has_method("court_entry_motion_context"):
		return false
	if dead or dormant or _hurt_left_s > 0.0 or not _reservation_id.is_empty() or hp != max_hp:
		return false
	var error: String = _court_parent_error(court, 0)
	if not error.is_empty():
		last_error = error
		return true
	_transaction_depth += 1
	var boundary: Dictionary = _court_entry_boundary()
	var answer: Variant = court.call("court_entry_motion_context", self)
	error = _court_parent_error(court, 1)
	if error.is_empty() and _court_entry_boundary() != boundary:
		error = "Pure court entry provider changed actual native source/Player/Scheduler custody"
	if error.is_empty() and not answer is Dictionary:
		error = "Court entry provider must return its closed native context or an empty Dictionary"
	if not error.is_empty():
		_transaction_depth -= 1
		last_error = error
		return true
	var context: Dictionary = answer
	if context.is_empty():
		_transaction_depth -= 1
		if velocity != Vector3.ZERO and _hurt_left_s == 0.0 and _grounded():
			last_error = "Court entry permission was withdrawn; record and stop its actual shortened entry"
			return true
		return false
	error = _court_motion_error(court, 1)
	if error.is_empty(): error = _court_motion_context_error(context, delta)
	if not error.is_empty():
		_transaction_depth -= 1
		last_error = error
		return true
	var clock: float = float(boundary.control.clock_s)
	var elapsed: float = clampf(clock - float(context.start_s), 0.0, float(context.end_s) - float(context.start_s))
	var desired: Vector3 = BodySweep.anchored_position(context.from, Vector3.BACK, COURT_ENTRY_SPEED * elapsed)
	var previous_elapsed: float = clampf(clock - float(context.start_s) - delta, 0.0, float(context.end_s) - float(context.start_s))
	var previous: Vector3 = BodySweep.anchored_position(context.from, Vector3.BACK, COURT_ENTRY_SPEED * previous_elapsed)
	# Native float32 world addition at Z-31 cannot stand in for clock custody.
	# Corroborate the previous anchor using the shared coordinate-rounding proof,
	# then use the existing lunge's measured move_and_collide primitive. A missed
	# prior step is refused; no catch-up, speed retune, position assignment or
	# original-deadline change is introduced.
	if global_position.distance_to(previous) > BodySweep.position_rounding_bound(global_position, previous) or desired.z < global_position.z - Motion.EPSILON:
		_transaction_depth -= 1
		last_error = "Court entry cannot rebase its clock or catch up delayed/collided motion"
		return true
	var step: Vector3 = desired - global_position
	var sweep: Dictionary = BodySweep.sweep(self, global_transform, step, court.call("response_context").floor_regions)
	if sweep.has("error") or sweep.get("collided", true):
		_transaction_depth -= 1
		last_error = "Actual finite court entry scenery query refused its anchored next step"
		return true
	velocity = Vector3.BACK * minf(COURT_ENTRY_SPEED, maxf(0.0, desired.z - previous.z) / delta)
	_facing = Vector3.BACK
	var frame_start: Vector3 = global_position
	var count: int = maxi(1, ceili((step.length() - Motion.EPSILON) / BodySweep.SWEEP_STEP))
	for index: int in range(count):
		var target: Vector3 = BodySweep.anchored_position(frame_start, step, float(index + 1) / float(count))
		var contact: KinematicCollision3D = move_and_collide(target - global_position, false, BodySweep.SAFE_MARGIN, false, 1)
		if contact != null: break
	# move_and_collide does not establish CharacterBody3D's move_and_slide floor
	# history on a freshly restored body. Certify the actual post-step feet/body
	# against the retained static support instead of discarding genuine support
	# or manufacturing an engine is_on_floor flag. Ordinary physics clears this
	# transported support after its next real move_and_slide as before.
	var support: Dictionary = BodySweep.sweep(self, global_transform, Vector3.ZERO, court.call("response_context").floor_regions)
	if support.has("error") or support.get("collided", true):
		_restored_floor_contact = 0
		_transaction_depth -= 1
		last_error = "Actual finite court entry lost native post-step floor/body support: " + String(support.get("error", "scenery contact"))
		return true
	_restored_floor_contact = 1
	# Stop only the entry's own finite velocity after its original deadline and
	# actual endpoint. A collision is retained and reported, never pose-snapped.
	if clock >= float(context.end_s) and Vector2(global_position.x, global_position.z).distance_to(Vector2(context.to.x, context.to.z)) <= Motion.EPSILON:
		velocity = Vector3.ZERO
	_draw_greybox()
	error = _court_motion_error(court, 1)
	if error.is_empty() and (_scheduler.source_control_state(self) != boundary.control or _scheduler.encounter_profile() != boundary.profile or _hero.global_transform != boundary.hero_transform or _hero.get_threat_response_state() != boundary.hero_response):
		error = "Native court entry changed retained Player/Scheduler custody"
	if error.is_empty() and (not _grounded() or velocity.y != 0.0 or absf(global_position.x - context.from.x) > Motion.EPSILON or global_position.z > context.to.z + Motion.EPSILON or global_position.z < context.from.z - Motion.EPSILON):
		error = "Native court entry departed its approved grounded straight corridor"
	if error.is_empty() and absf(global_position.z - desired.z) > Motion.EPSILON:
		error = "Native scenery collision shortened the original finite court entry"
	_transaction_depth -= 1
	last_error = error
	return true


func _court_motion_error(court: CinderLevel, depth: int) -> String:
	var error: String = _court_parent_error(court, depth)
	if not error.is_empty(): return error
	if not _court_entry_consumed and not _restore_recipient_constructed:
		return "Court entry motion requires a genuinely exposed or fresh restored helper"
	if dead or dormant or hp != max_hp or _hurt_left_s != 0.0 or _approach_driving or _cycle != 0 or _phase != "clear" or not _role_encounter_id.is_empty() or not _profile_id.is_empty() or not _resolved_role.is_empty() or not _reservation_id.is_empty() or not _sample.is_empty() or not _pending_segments.is_empty() or not _hit_ids.is_empty() or not _last_cancel_reason.is_empty():
		return "Court entry owns only pristine live unleased C32 motion before its first thrust"
	error = _court_entry_environment_error()
	return _court_entry_control_error() if error.is_empty() else error


func _court_motion_context_error(context: Dictionary, delta: float) -> String:
	if not Codec.keys_error(context, COURT_ENTRY_KEYS).is_empty() or not context.get("active") is bool or context.active != true or not context.get("from") is Vector3 or not context.get("to") is Vector3 or not context.from.is_finite() or not context.to.is_finite() or not context.get("start_s") is float or not context.get("end_s") is float or not context.get("speed") is float:
		return "Exact active/from/to/start_s/end_s/speed native court entry context required"
	if not is_finite(delta) or delta < 0.000001 or delta > 0.25 or not Codec.in_range(context.start_s, 0.0, 1000000000.0) or not Codec.in_range(context.end_s, context.start_s, 1000000000.0) or context.speed != COURT_ENTRY_SPEED or context.end_s != context.start_s + COURT_ENTRY_DISTANCE / COURT_ENTRY_SPEED or context.to != context.from + Vector3.BACK * COURT_ENTRY_DISTANCE:
		return "Court entry retains its original .7-unit +Z path at 1.4 units/s and half-second deadline"
	if context.from.x != _restore_source_transform.origin.x or context.from.z != _restore_source_transform.origin.z or absf(context.from.y - _restore_source_transform.origin.y) > 0.02 or absf(global_position.x - context.from.x) > Motion.EPSILON or absf(global_position.y - context.from.y) > Motion.EPSILON or global_position.z < context.from.z - Motion.EPSILON or global_position.z > context.to.z + Motion.EPSILON:
		return "Court entry must retain its actual authored settled feet and bounded straight corridor"
	if not _grounded() or velocity.y != 0.0 or velocity.x != 0.0 or velocity.z < 0.0 or velocity.z > COURT_ENTRY_SPEED + Motion.EPSILON or _scheduler.get_clock() < context.start_s:
		return "Native grounded finite entry velocity and original shared-clock start required"
	# The exact parent provider separately proves the full corridor against its
	# retained 14x44 floor, actual Hero/other actors, scenery and whole art/camera.
	# A copied context is not a substitute for those owned physical-world guards.
	return ""


## Pure forecast only. No guard callback, motion, state/event or Scheduler query.
## Root must separately guard the actual complete body/art/world/neighbor unit.
func propose_approach(target: Vector3, delta: float) -> Dictionary:
	var error: String = _approach_idle_error(false)
	if not error.is_empty(): return {"accepted": false, "error": error, "reason": "actor_not_ready"}
	return _approach.plan(global_position, velocity, _facing, target, delta, _configuration.approach)


func _approach_idle_error(inside_physics: bool) -> String:
	if not _live_bindings() or _snapshot_busy or _cancelling or (not inside_physics and _transaction_depth > 0) or dead or dormant or _hero.dead or get_tree().paused:
		return "Approach requires its live unpaused activated source/Player outside callbacks"
	var environmental_error: String = _spore_fresh_error()
	if not environmental_error.is_empty(): return environmental_error
	if _configuration.role_id != ROLE_SWARM or not _configuration.approach.enabled or not _reservation_id.is_empty() or not _sample.is_empty() or not _pending_segments.is_empty() or not _hit_ids.is_empty() or _hurt_left_s != 0.0:
		return "Only opt-in idle C31 without a native lease/sample/held delivery can approach"
	if not _grounded() or velocity.y != 0.0 or (not _approach_driving and Vector3(velocity.x, 0.0, velocity.z) != Vector3.ZERO):
		return "Approach cannot own airborne motion or residual native hurt/impulse"
	var error: String = _retained_body_error()
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty(): error = art_binding_error()
	return error


func _movement_error(plan: Dictionary) -> String:
	var consumer: CinderSporeRepulsion = _spore_consumer()
	if not _spore_consumer_id.is_empty():
		if consumer == null: return "Actual environmental consumer binding is unavailable"
		var motion: Vector3 = plan.next_position - global_position
		if not consumer.allows_source_step(self, global_position, motion):
			return "Actual active field forbids this source's approach reentry"
	if not approach_guard.is_valid(): return "Opt-in approach requires its parent's actual motion/framing guard"
	var result: Variant = approach_guard.call(plan.duplicate(true))
	return result if result is String else "Approach movement guard must return a literal String"


func _step_approach(delta: float) -> void:
	var error: String = _approach_idle_error(true)
	if not error.is_empty():
		last_error = error
		return
	var origin: Vector3 = global_position
	var original_velocity: Vector3 = velocity
	var original_facing: Vector3 = _facing
	var target: Vector3 = _hero.global_position
	var hp_before: float = hp
	var driving_before: bool = _approach_driving
	var plan: Dictionary = _approach.plan(origin, original_velocity, original_facing, target, delta, _configuration.approach)
	if not plan.get("accepted", false):
		last_error = String(plan.get("error", "Approach proposal rejected"))
		return
	plan["delta_s"] = delta
	error = _movement_error(plan)
	var boundary_error: String = _approach_idle_error(true)
	if not boundary_error.is_empty():
		last_error = boundary_error
		return
	var current_error: String = ""
	if not error.is_empty():
		# A guard may suppress pursuit. Braking remains finite owned motion and
		# must receive its own complete native world/body/art/spacing approval.
		var disabled: Dictionary = _configuration.approach.duplicate(true)
		disabled.enabled = false
		plan = _approach.plan(origin, original_velocity, original_facing, target, delta, disabled)
		if plan.get("accepted", false):
			plan["delta_s"] = delta
			error = _movement_error(plan)
		else: error = String(plan.get("error", "Approach braking rejected"))
		# The braking path can cross another parent observer. Keep its full fresh
		# proof even when planning fails; the success path has just checked the
		# first observer and performs only local branching before the pose guard.
		current_error = _approach_idle_error(true)
	if not current_error.is_empty(): error = current_error
	if global_position != origin or velocity != original_velocity or _facing != original_facing or _hero.global_position != target or hp != hp_before or _approach_driving != driving_before:
		error = "Pure movement guard changed the actual source/Player boundary"
	if not error.is_empty():
		# Reject unsafe motion without manufacturing a stop or discarding actual
		# velocity. Parent owns persistent unavailable-world cancellation/teardown.
		last_error = error
		return
	velocity = plan.velocity
	_facing = plan.facing
	_approach_driving = plan.driving
	move_and_slide()
	_restored_floor_contact = -1
	# Native collision can shorten/stop a proposal; retain actual ownership only.
	_approach_driving = Vector3(velocity.x, 0.0, velocity.z) != Vector3.ZERO and _grounded() and velocity.y == 0.0
	_draw_greybox()
	last_error = ""


func _stage_sample() -> bool:
	var previous: Dictionary = _sample.duplicate(true)
	_sample_now()
	if previous.is_empty():
		cancel("sampled_exchange_missing")
		return false
	if not _hero.dead and not _hit_ids.has(HERO_ID):
		if _pending_segments.size() >= MAX_PENDING_SEGMENTS:
			cancel("pending_path_budget_exceeded")
			return false
		_pending_segments.append({"from": previous.hero_position - previous.source_position, "to": _sample.hero_position - _sample.source_position, "start_s": previous.clock_s, "end_s": _sample.clock_s})
	return true


func _resolve_pending_segments() -> void:
	if _pending_segments.is_empty():
		return
	# Revalidate immediately before consuming the opportunity. Clear it before
	# Player hurt/death and hit observers, preserving exactly-once delivery.
	var current: Dictionary = _damage_boundary_record(true)
	if current.is_empty():
		return
	var path: Array[Dictionary] = _pending_segments.duplicate(true)
	_pending_segments.clear()
	if _hero.dead or _hit_ids.has(HERO_ID) or not current.get("armed", false):
		return
	var hit: bool = false
	for segment: Dictionary in path:
		# Geometry's spatial epsilon cannot advance an opportunity into lock.
		if maxf(float(segment.start_s), float(current.active_from_s)) > minf(float(segment.end_s), float(current.active_until_s)):
			continue
		var shape: Dictionary = Geometry.circle(Vector3.ZERO, float(current.adapter.damage_radius)) if _configuration.role_id == ROLE_SWARM else Geometry.lane(Vector3.ZERO, _facing * float(_configuration.lane.length), float(_configuration.lane.radius))
		if Geometry.timed_path_hits(shape, [segment], float(current.active_from_s), float(current.active_until_s), CinderThreatScheduler.CAPSULE_RADIUS):
			hit = true
			break
	if not hit:
		return
	_hit_ids.append(HERO_ID)
	var before: float = _hero.hp
	_hero.take_damage(float(_resolved_role.damage), Vector3.ZERO)
	var result: Dictionary = {"opportunity_consumed": true, "accepted": _hero.hp < before, "raw_damage": float(_resolved_role.damage), "hp_damage": maxf(before - _hero.hp, 0.0), "impulse": Vector3.ZERO}
	_damage_boundary_record(true)
	hit_resolved.emit(HERO_ID, _cycle, result)
	_damage_boundary_record(true)


func _damage_boundary_record(current_source_marker: bool) -> Dictionary:
	if _reservation_id.is_empty():
		return {}
	if dead or dormant or not _live_bindings() or is_queued_for_deletion() or not is_visible_in_tree():
		cancel("required_source_or_bindings_unavailable")
		return {}
	var record: Dictionary = _scheduler.reservation_state(_reservation_id)
	if _reservation_id.is_empty():
		return {}
	if record.is_empty():
		_reservation_id = ""
		_sample.clear()
		_pending_segments.clear()
		_hit_ids.clear()
		_present({})
		return {}
	var error: String = _retained_body_error()
	if error.is_empty(): error = _lifecycle_error()
	if error.is_empty(): error = art_binding_error()
	if error.is_empty(): error = _presentation_error()
	if not error.is_empty():
		cancel(error)
		return {}
	if not _required_cue_available(record, current_source_marker):
		cancel("required_source_or_cue_unavailable")
		return {}
	# A pure authored guard or scheduler cleanup may notify other observers.
	if _reservation_id.is_empty() or not _live_bindings() or dead or dormant or not is_visible_in_tree():
		return {}
	if get_tree().paused:
		return {}
	var latest: Dictionary = _scheduler.reservation_state(_reservation_id)
	if _reservation_id.is_empty(): return {}
	if latest != record or int(record.get("source_instance_id", 0)) != get_instance_id() or record.get("source_position") != global_position or (record.get("adapter", {}).get("current_velocity") != velocity if _configuration.role_id == ROLE_SWARM else velocity != Vector3.ZERO) or not _required_cue_available(record, current_source_marker) or get_tree().paused:
		cancel("committed_source_or_exchange_changed")
		return {}
	return record


func _required_cue_available(record: Dictionary, current_source_marker: bool) -> bool:
	if not is_instance_valid(_cue) or _cue.is_queued_for_deletion() or not _cue.is_visible_in_tree():
		return false
	var shown: Dictionary = _cue.state()
	if shown.phase != _phase or shown.geometry != record.geometry or (current_source_marker and shown.source_position != global_position):
		return false
	var names: Array[String] = ["RequiredSourceMarker"]
	if _phase != "recovery": names.append("RequiredFootprintOutline")
	if _phase == "active": names.append("RequiredFootprintFill")
	for part_name: String in names:
		var part: MeshInstance3D = _cue.get_node_or_null(part_name) as MeshInstance3D
		if not is_instance_valid(part) or part.is_queued_for_deletion() or not part.is_visible_in_tree() or part.mesh == null:
			return false
	return true


func _sample_now() -> void:
	_sample = {"clock_s": _scheduler.get_clock(), "source_position": global_position, "hero_position": _hero.global_position}


func _present(record: Dictionary, notify: bool = true) -> void:
	var next: String = String(record.get("state", "clear"))
	var changed: bool = next != _phase
	_phase = next
	if next == "clear":
		_cue.clear()
	else:
		var geometry: Dictionary = record.geometry.duplicate(true)
		geometry.source_position = global_position
		_cue.present(geometry, next)
	# Required cue callbacks may synchronously cancel the source.
	if _reservation_id.is_empty():
		_phase = "clear"
		_cue.clear()
	_draw_greybox()
	if notify and changed:
		state_changed.emit(state())


func _on_invalidated(id: String, reason: String) -> void:
	if id == _reservation_id and not _cancelling:
		cancel(reason)


func _presentation_error() -> String:
	if not presentation_guard.is_valid():
		return ""
	var result: Variant = presentation_guard.call()
	return result if result is String else "C31/C32 presentation guard must return a String"


func _live_bindings() -> bool:
	return not _configuration.is_empty() and is_inside_tree() and is_node_ready() and is_instance_valid(_scheduler) and _scheduler.is_inside_tree() and not _scheduler.is_queued_for_deletion() and _scheduler.get_world_3d() == get_world_3d() and _scheduler.process_physics_priority < process_physics_priority and is_instance_valid(_hero) and _hero.is_inside_tree() and not _hero.is_queued_for_deletion() and _hero.get_world_3d() == get_world_3d() and _hero.process_physics_priority < process_physics_priority and is_instance_valid(_collision) and _collision.is_inside_tree() and is_instance_valid(_cue) and _cue.is_inside_tree() and not _cue.is_queued_for_deletion() and is_instance_valid(_visual) and _visual.is_inside_tree() and is_instance_valid(_body) and _body.is_inside_tree()


func _grounded() -> bool:
	return _restored_floor_contact == 1 if _restored_floor_contact >= 0 else is_on_floor()


func _read_native_body_properties() -> Dictionary:
	var capsule := _collision.shape as CapsuleShape3D
	return {"collision_transform": _collision.transform, "radius": capsule.radius, "height": capsule.height, "margin": capsule.margin, "custom_solver_bias": capsule.custom_solver_bias, "safe_margin": safe_margin, "collision_priority": collision_priority, "up_direction": up_direction, "floor_snap_length": floor_snap_length, "motion_mode": motion_mode, "linear_axis_locks": [axis_lock_linear_x, axis_lock_linear_y, axis_lock_linear_z], "process_mode": process_mode, "physics_priority": process_physics_priority, "shape_owners": get_shape_owners()}


func _retained_body_error() -> String:
	# Owned node/resource/property validation works while disabled and unpaused.
	# It neither enables collision for measurement nor reproduces a shared solver.
	if not is_inside_tree() or not is_node_ready() or is_queued_for_deletion() or not is_instance_valid(_collision) or not _collision.is_inside_tree() or _collision.is_queued_for_deletion() or _collision.get_parent() != self or get_node_or_null("BodyCollision") != _collision or _collision.shape != _retained_capsule or not is_instance_valid(_retained_capsule) or _native_body_properties.is_empty() or _body_signature.is_empty():
		return "Retained actual C31/C32 capsule node/resource identity changed"
	if global_basis != Basis.IDENTITY or not global_position.is_finite() or not velocity.is_finite() or not get_collision_exceptions().is_empty() or not get_platform_velocity().is_zero_approx() or not get_platform_angular_velocity().is_zero_approx():
		return "Retained C31/C32 requires its upright finite fixed-world native body"
	var collider_count: int = 0
	for child: Node in get_children():
		if child is CollisionShape3D or child is CollisionPolygon3D:
			collider_count += 1
	var owners: PackedInt32Array = get_shape_owners()
	if collider_count != 1 or owners.size() != 1 or _read_native_body_properties() != _native_body_properties:
		return "Retained C31/C32 native capsule/body properties or registrations changed"
	var shape_owner_id: int = owners[0]
	if shape_owner_get_owner(shape_owner_id) != _collision or shape_owner_get_shape_count(shape_owner_id) != 1 or shape_owner_get_shape(shape_owner_id, 0) != _retained_capsule or shape_owner_get_transform(shape_owner_id) != _collision.transform or is_shape_owner_disabled(shape_owner_id) != _collision.disabled:
		return "Retained C31/C32 registered footprint differs from its actual capsule"
	return ""


func _lifecycle_error() -> String:
	var inactive: bool = dead or dormant
	if max_hp != float(_configuration.raw_role.max_hp) or not is_finite(hp) or hp < 0.0 or hp > max_hp or dead != (hp == 0.0):
		return "Actual C31/C32 HP/death disagrees with immutable role"
	if _collision.disabled != inactive or collision_layer != (0 if inactive else 2) or collision_mask != (0 if inactive else 1) or is_in_group("enemies") == inactive or visible == inactive:
		return "Actual C31/C32 lifecycle flags/group/visibility disagree with HP/dormancy"
	if not inactive and not is_visible_in_tree():
		return "Living C31/C32 cannot remain under an inherited hidden parent"
	if dormant:
		return _dormant_state_error()
	return ""


func _dormant_state_error() -> String:
	if not _configuration.get("initially_dormant", false) or dead or hp != max_hp or velocity != Vector3.ZERO or _hurt_left_s != 0.0 or _approach_driving or _cycle != 0 or _phase != "clear" or not _role_encounter_id.is_empty() or not _profile_id.is_empty() or not _resolved_role.is_empty() or not _reservation_id.is_empty() or not _sample.is_empty() or not _pending_segments.is_empty() or not _hit_ids.is_empty() or not _last_cancel_reason.is_empty():
		return "Dormant C31/C32 must retain pristine HP and no motion/combat history"
	if is_instance_valid(_cue) and _cue.state().phase != "clear":
		return "Dormant C31/C32 cannot hide a required hazard cue"
	return ""


func _apply_lifecycle_flags() -> void:
	var inactive: bool = dead or dormant
	collision_layer = 0 if inactive else 2
	collision_mask = 0 if inactive else 1
	_collision.disabled = inactive
	visible = not inactive
	if inactive:
		remove_from_group("enemies")
	else:
		add_to_group("enemies")


func _spore_consumer() -> CinderSporeRepulsion:
	var value: Variant = _spore_consumer_ref.get_ref() if _spore_consumer_ref != null else null
	if not is_instance_valid(value) or not value is CinderSporeRepulsion or not value.is_inside_tree() or value.is_queued_for_deletion() or value.get_world_3d() != get_world_3d(): return null
	return value as CinderSporeRepulsion


func _spore_binding_error() -> String:
	if _spore_consumer_id.is_empty(): return ""
	if spore_route_guard_required != _bound_spore_route_guard_required or spore_route_guard != _bound_spore_route_guard or (_bound_spore_route_guard_required and not _bound_spore_route_guard.is_valid()):
		return "Retain the configured owned spore route guard and requirement"
	var consumer: CinderSporeRepulsion = _spore_consumer()
	if consumer == null or consumer.consumer_id() != _spore_consumer_id or not consumer.source_binding_matches(self, String(_configuration.source_id)):
		return "Retain the actual immutable environmental consumer/source binding"
	return ""


func _spore_fresh_error() -> String:
	if not _spore_episode_id.is_empty(): return "Actual environmental episode suppresses fresh attack/approach"
	var error: String = _spore_binding_error()
	if not error.is_empty(): return error
	if not _spore_consumer_id.is_empty() and not _spore_consumer().placement_accepted():
		return "Actual environmental custody rejection suppresses fresh attack/approach"
	return ""


func _spore_hook_error(consumer: Node, episode_id: String) -> String:
	if not _live_bindings() or dead or dormant or _transaction_depth > 0 or _snapshot_busy or _cancelling:
		return "Environmental hook requires a living actual source outside actor callbacks"
	var error: String = _spore_binding_error()
	if not error.is_empty(): return error
	if _spore_consumer_id.is_empty() or _spore_consumer() != consumer or not _stable_id(episode_id) or not episode_id.begins_with(_spore_consumer_id + "/episode-"):
		return "Environmental hook must name the retained consumer's genuine episode"
	return ""


func _spore_route_guard_error(consumer: Node, episode_id: String, direction: Vector3, boundary: String, record: Dictionary, control: Dictionary) -> String:
	# Coordinator is deliberately busy here. Do not demand its snapshot barrier,
	# call a paused writer, choose a second endpoint, or acquire a private Route.
	if not _bound_spore_route_guard.is_valid():
		return "Required owned spore route guard is unavailable" if _bound_spore_route_guard_required else ""
	var response: Dictionary = get_spore_response_state()
	var player_response: Dictionary = _hero.get_threat_response_state()
	var original_hp: float = hp
	var original_player_hp: float = _hero.hp
	var original_player_shells: int = _hero.shells
	var original_driving: bool = _approach_driving
	if response.is_empty() or not response.outside_transaction: return "Actual native source response required before route guard"
	var proposal: Dictionary = {"source_id": String(_configuration.source_id), "consumer": consumer, "episode_id": episode_id, "boundary": boundary, "direction": direction}
	var result: Variant = _bound_spore_route_guard.call(proposal)
	var error: String = _spore_hook_error(consumer, episode_id)
	if not error.is_empty(): return error
	if get_tree().paused or hp != original_hp or _hero.hp != original_player_hp or _hero.shells != original_player_shells or _approach_driving != original_driving or get_spore_response_state() != response or _hero.get_threat_response_state() != player_response or _scheduler.source_control_state(self) != control or (consumer as CinderSporeRepulsion).source_state(String(_configuration.source_id)) != record:
		return "Owned spore route guard must preserve actual source/Player/controller/episode custody"
	if not body_binding_error().is_empty() or not art_binding_error().is_empty(): return "Owned spore route guard changed actual body/presentation custody"
	return result if result is String else "Owned spore route guard must return a literal String"


func _unit_direction(value: Vector3) -> bool:
	return value.is_finite() and absf(value.y) <= Motion.EPSILON and absf(value.length() - 1.0) <= Motion.EPSILON


func _encode_repulsion() -> Dictionary:
	return {"api_revision": SPORE_ACTOR_REVISION, "consumer_id": _spore_consumer_id, "source_id": _configuration.source_id, "episode_id": _spore_episode_id, "phase": _spore_phase, "direction": Codec.vector3(_spore_direction), "progress": _spore_progress}


func _snapshot_access_error() -> String:
	var art_error: String = art_binding_error()
	if not art_error.is_empty():
		return art_error
	if not _live_bindings() or not get_tree().paused or is_queued_for_deletion():
		return "C31/C32 snapshots require retained ready bindings at the paused deferred barrier"
	if _transaction_depth > 0 or _snapshot_busy or _cancelling:
		return "C31/C32 snapshots cannot run inside actor/phase/hit/cancellation callbacks"
	# Pure identity only: querying the coordinator's snapshot validator here
	# would recurse while it is validating this same complete native actor unit.
	var environmental_error: String = _spore_binding_error()
	if not environmental_error.is_empty(): return environmental_error
	var retained_error: String = _retained_body_error()
	if not retained_error.is_empty():
		return retained_error
	var description: Dictionary = Motion.staged_source_description(self, _live_collision_state())
	if description.has("error") or not _same(description.get("signature", {}), _body_signature):
		return "Actual retained C31/C32 capsule/registration/transform no longer matches its immutable body"
	if global_basis != Basis.IDENTITY or not global_position.is_finite() or not velocity.is_finite():
		return "Actual C31/C32 motion must retain its upright finite body frame"
	return ""


func capture_state(paired_scheduler: Dictionary) -> Dictionary:
	return _capture_state(paired_scheduler, {})


## Complete paired writer; helper never reconstructs a native actor envelope.
func spore_snapshot_state(paired_scheduler: Dictionary, saved_player: Dictionary) -> Dictionary:
	if saved_player.is_empty():
		last_snapshot_error = "Complete actual paired Player required by environmental native capture"
		return {}
	return _capture_state(paired_scheduler, saved_player)


func _capture_state(paired_scheduler: Dictionary, supplied_player: Dictionary) -> Dictionary:
	last_snapshot_error = _snapshot_access_error()
	if not last_snapshot_error.is_empty():
		return {}
	var current_player: Dictionary = _hero.snapshot_state()
	if current_player.is_empty() or (not supplied_player.is_empty() and not _same(current_player, supplied_player)):
		last_snapshot_error = "Captured actor must use the exact actual paused Player unit"
		return {}
	_snapshot_busy = true
	var saved: Dictionary = {"api_revision": API_REVISION, "schema_version": SNAPSHOT_SCHEMA_VERSION, "role_id": _configuration.role_id, "source_id": _configuration.source_id, "configuration": _configuration.duplicate(true), "hp": hp, "dead": dead, "dormant": dormant, "motion": {"position": Codec.vector3(global_position), "velocity": Codec.vector3(velocity), "facing": Codec.vector3(_facing), "grounded": _grounded()}, "hurt_left_s": _hurt_left_s, "approach_driving": _approach_driving, "role_encounter_id": _role_encounter_id, "profile_id": _profile_id, "resolved_role": _resolved_role.duplicate(true), "reservation_id": _reservation_id, "cycle": _cycle, "sample": _encode_sample(), "hit_ids": _hit_ids.duplicate(), "last_cancel_reason": _last_cancel_reason}
	if not _pending_segments.is_empty():
		saved["schema_version"] = PENDING_SNAPSHOT_SCHEMA_VERSION
		saved["pending_segments"] = []
		for segment: Dictionary in _pending_segments:
			saved.pending_segments.append({"from": Codec.vector3(segment.from), "to": Codec.vector3(segment.to), "start_s": segment.start_s, "end_s": segment.end_s})
	if not _spore_consumer_id.is_empty():
		saved["schema_version"] = BOUND_PENDING_SNAPSHOT_SCHEMA_VERSION if not _pending_segments.is_empty() else BOUND_SNAPSHOT_SCHEMA_VERSION
		saved["repulsion"] = _encode_repulsion()
	last_snapshot_error = _actor_error(saved, paired_scheduler, current_player)
	if last_snapshot_error.is_empty():
		last_snapshot_error = _lifecycle_error()
	_snapshot_busy = false
	return saved if last_snapshot_error.is_empty() else {}


func snapshot_error(saved: Dictionary, paired_scheduler: Dictionary, saved_player: Dictionary) -> String:
	var error: String = _snapshot_access_error()
	if not error.is_empty():
		return error
	_snapshot_busy = true
	error = _actor_error(saved, paired_scheduler, saved_player)
	_snapshot_busy = false
	return error


func staged_actor_bindings(saved: Dictionary) -> Dictionary:
	# Caller first validates the complete actor/player/scheduler aggregate. These
	# maps are native staging, never local transport or substitute geometry.
	if not _snapshot_access_error().is_empty() or not _schema_error(saved).is_empty():
		return {}
	var result: Dictionary = {"owner_positions": {String(saved.source_id): Codec.read_vector3(saved.motion.position)}, "owner_velocities": {String(saved.source_id): Codec.read_vector3(saved.motion.velocity)}, "owner_collision_states": {}}
	if not saved.reservation_id.is_empty():
		if saved.dead or saved.dormant:
			return {}
		result.owner_collision_states[String(saved.source_id)] = _live_collision_state()
	return result


func restore_actor_state(saved: Dictionary) -> bool:
	## First commit after ROOT whole-aggregate prevalidation. Do not run configure,
	## damage/death/cancel/request paths or yield. Exchange commit follows scheduler.
	last_snapshot_error = _snapshot_access_error()
	if last_snapshot_error.is_empty():
		last_snapshot_error = _schema_error(saved)
	if not last_snapshot_error.is_empty():
		return false
	_snapshot_busy = true
	global_position = Codec.read_vector3(saved.motion.position)
	velocity = Codec.read_vector3(saved.motion.velocity)
	_facing = Codec.read_vector3(saved.motion.facing)
	hp = float(saved.hp)
	dead = saved.dead
	dormant = saved.dormant
	_hurt_left_s = float(saved.hurt_left_s)
	_approach_driving = saved.approach_driving
	_restored_floor_contact = 1 if saved.motion.grounded else 0
	# An unexposed helper in a FRESH court candidate is still its genuine
	# ready-time cold body, not a previously grounded recipient. Preserve that
	# unset cache so its later one-shot entry birth can prove pristine custody.
	# The serialized grounded=false value is unchanged; no floor flag is forged.
	var court: CinderLevel = _restore_owner_level()
	if dormant and _configuration.source_id in COURT_HELPER_IDS and not _court_entry_consumed and not _restore_recipient_constructed and not is_on_floor() and is_instance_valid(court) and court.is_restore_candidate() and court.get_script() == _restore_level_script and _restore_level_script.resource_path == COURT_SCRIPT_PATH and global_transform == _restore_source_transform:
		_restored_floor_contact = -1
	_apply_lifecycle_flags()
	_snapshot_busy = false
	return true


func restore_exchange_state(saved: Dictionary) -> bool:
	## Second commit only after the actual source and shared scheduler commit.
	last_snapshot_error = _snapshot_access_error()
	if last_snapshot_error.is_empty():
		last_snapshot_error = _schema_error(saved)
	if not last_snapshot_error.is_empty():
		return false
	var inactive: bool = dead or dormant
	if hp != saved.hp or dead != saved.dead or dormant != saved.dormant or _hurt_left_s != saved.hurt_left_s or _approach_driving != saved.approach_driving or not _same(Codec.vector3(_facing), saved.motion.facing) or not _same(Codec.vector3(global_position), saved.motion.position) or not _same(Codec.vector3(velocity), saved.motion.velocity) or _collision.disabled != inactive or collision_layer != (0 if inactive else 2) or collision_mask != (0 if inactive else 1) or is_in_group("enemies") == inactive or visible == inactive:
		last_snapshot_error = "Apply the exact validated actual C31/C32 lifecycle/motion before exchange commit"
		return false
	# Quiet actual source-control read: no pruning, cancellation, clocks or cue
	# callbacks are permitted between the aggregate's physical/native commits.
	var control: Dictionary = _scheduler.source_control_state(self)
	if control.is_empty() or not control.get("outside_transaction", false):
		last_snapshot_error = "Actual restored Scheduler must be outside its native transaction"
		return false
	if inactive and control.cooldown != null:
		last_snapshot_error = "Actual inactive C31/C32 cannot retain its native owner cooldown"
		return false
	var records: Array = control.reservations
	var record: Dictionary = records[0] if records.size() == 1 else {}
	if not saved.reservation_id.is_empty():
		if record.is_empty() or record.get("id") != saved.reservation_id or int(record.source_instance_id) != get_instance_id() or control.clock_s != saved.sample.clock_s or not _same(Codec.vector3(record.source_position), saved.motion.position) or not _same(Codec.vector3(record.get("adapter", {}).get("current_velocity", Vector3.ZERO)), saved.motion.velocity) or not _same(Codec.vector3(_hero.global_position), saved.sample.hero_position):
			last_snapshot_error = "Actual restored scheduler/source/hero must match the validated sampled exchange"
			return false
		var current_pair: Dictionary = {"clock_s": control.clock_s, "encounter_id": control.encounter_id, "profile": _scheduler.encounter_profile(), "reservations": [_encode_public_record(record)], "cooldowns": []}
		last_snapshot_error = _actor_error(saved, current_pair, _hero.snapshot_state())
		if not last_snapshot_error.is_empty():
			return false
	elif not records.is_empty():
		last_snapshot_error = "Inactive C31/C32 cannot hide an actual retained reservation"
		return false
	_snapshot_busy = true
	_role_encounter_id = saved.role_encounter_id
	_profile_id = saved.profile_id
	_resolved_role = saved.resolved_role.duplicate(true)
	_reservation_id = saved.reservation_id
	_cycle = int(saved.cycle)
	_sample = {} if saved.sample.is_empty() else {"clock_s": saved.sample.clock_s, "source_position": Codec.read_vector3(saved.sample.source_position), "hero_position": Codec.read_vector3(saved.sample.hero_position)}
	_pending_segments.clear()
	for segment: Dictionary in saved.get("pending_segments", []):
		_pending_segments.append({"from": Codec.read_vector3(segment.from), "to": Codec.read_vector3(segment.to), "start_s": segment.start_s, "end_s": segment.end_s})
	_hit_ids.clear()
	for id: String in saved.hit_ids:
		_hit_ids.append(id)
	_last_cancel_reason = saved.last_cancel_reason
	# Stamp is the final quiet actor exchange commit, after actual physical
	# actors/Player and native Scheduler. Coordinator Route restore comes last.
	if saved.has("repulsion"):
		_spore_episode_id = saved.repulsion.episode_id
		_spore_phase = saved.repulsion.phase
		_spore_direction = Codec.read_vector3(saved.repulsion.direction)
		_spore_progress = saved.repulsion.progress
	var blocked: bool = _cue.is_blocking_signals()
	_cue.set_block_signals(true)
	_cue.clear()
	_present(record, false)
	_cue.set_block_signals(blocked)
	_snapshot_busy = false
	return true


## Alias for callers using the existing paired actor naming convention.
func snapshot_state(paired_scheduler: Dictionary) -> Dictionary:
	return capture_state(paired_scheduler)


func actor_snapshot_error(saved: Dictionary, paired_scheduler: Dictionary, saved_player: Dictionary) -> String:
	return snapshot_error(saved, paired_scheduler, saved_player)


## Final quiet exchange commit only. Whole-aggregate validation and physical
## restore_actor_state -> shared Scheduler restore MUST already have succeeded.
## This alias does not move or restore the Scheduler and cannot replace that order.
func restore_state(saved: Dictionary) -> bool:
	return restore_exchange_state(saved)


func _schema_error(saved: Dictionary) -> String:
	var error: String = String(_native_codec.call("schema_error", saved, _configuration))
	if not error.is_empty(): return error
	var bound: bool = not _spore_consumer_id.is_empty()
	if bound != saved.has("repulsion"):
		return "Saved native conditional stamp must agree with actual environmental binding"
	if bound:
		return String(_native_codec.call("repulsion_error", saved.repulsion, String(_configuration.source_id), _spore_consumer_id))
	return ""


func _actor_error(saved: Dictionary, paired: Dictionary, saved_player: Dictionary) -> String:
	# Keep native physical/resource validation here. The independent codec only
	# compares the complete copied actor/controller/Player unit and measured
	# immutable signature; it cannot authorize a changed actual body or world.
	var error: String = _schema_error(saved)
	if not error.is_empty(): return error
	if not saved.reservation_id.is_empty() and _configuration.role_id == ROLE_SWARM:
		var description: Dictionary = Motion.staged_source_description(self, _live_collision_state())
		if description.has("error") or not _same(description.get("signature", {}), _body_signature):
			return "Native lunge must retain the actual unchanged capsule"
	return String(_native_codec.call("context_error", saved, paired, saved_player, _configuration, _body_signature))


func _encode_sample() -> Dictionary:
	return {} if _sample.is_empty() else {"clock_s": _sample.clock_s, "source_position": Codec.vector3(_sample.source_position), "hero_position": Codec.vector3(_sample.hero_position)}


func _encode_public_record(record: Dictionary) -> Dictionary:
	# Root has prevalidated the complete native Scheduler envelope/bindings.
	var result: Dictionary = {"id": record.id, "source_id": _configuration.source_id, "source_position": Codec.vector3(record.source_position), "opening_position": Codec.vector3(record.opening_position), "geometry": _encode_geometry(record.geometry)}
	if record.get("adapter", {}).get("kind") == "lunge":
		result["adapter"] = record.adapter.duplicate(true)
		for key: String in ["start", "planned_endpoint", "current_position", "current_velocity", "direction"]:
			result.adapter[key] = Codec.vector3(record.adapter[key])
	for key: String in ["start_s", "lock_from_s", "active_from_s", "active_until_s", "recovery_until_s", "cooldown_until_s"]:
		result[key] = record[key]
	return result


func _encode_geometry(shape: Dictionary) -> Dictionary:
	var encoded: Dictionary = shape.duplicate(true)
	for key: String in encoded:
		if encoded[key] is Vector3: encoded[key] = Codec.vector3(encoded[key])
	return encoded


func _live_collision_state() -> Dictionary:
	return {"collision_path": "BodyCollision", "enabled": true, "layer": 2, "mask": 1}


func _same(left: Variant, right: Variant) -> bool:
	var encoded: String = ExactJson.stringify(left)
	return not encoded.is_empty() and encoded == ExactJson.stringify(right)


func _stable_id(value: Variant) -> bool:
	if not value is String or value.is_empty() or value.length() > 128:
		return false
	var pattern := RegEx.new()
	pattern.compile("^[A-Za-z0-9_./:-]+$")
	var found: RegExMatch = pattern.search(value)
	return found != null and found.get_string() == value


func _denied(reason: String) -> Dictionary:
	last_error = reason
	return {"accepted": false, "reason": reason}


func _reject(reason: String) -> bool:
	last_error = reason
	return false


func _build_greybox() -> void:
	_visual = Node3D.new()
	_visual.name = "MushroomSelenitePresentation"
	add_child(_visual)
	_body = MeshInstance3D.new()
	_body.name = "StandingCrouchingBody"
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.25
	mesh.height = 1.15
	_body.mesh = mesh
	_body.visible = false
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.76, 0.78, 0.80)
	_body.material_override = material
	_visual.add_child(_body)
	_sprite_art = ArtScript.new()
	_sprite_art.name = "CostumePixels"
	if not _sprite_art.call("configure", String(_configuration.role_id)):
		last_error = "Configure the actual immutable C31/C32 costume role before adding its art"
		_sprite_art.free()
		_sprite_art = null
		return
	_visual.add_child(_sprite_art)
	_draw_greybox()


func _art_phase() -> String:
	# Derived presentation only. Episode, turn, movement and deadlines remain
	# the actual consumer's stamp; never serialize a second art phase/clock.
	if not _spore_consumer_id.is_empty() and not _spore_episode_id.is_empty():
		match _spore_phase:
			"recoil", "turn": return "recoil"
			"retreat": return "retreat"
			"hold", "regroup": return "regroup"
			"interrupted", "failed": return "clear"
	return _phase


func _draw_greybox() -> void:
	if not is_instance_valid(_visual): return
	_visual.rotation.y = atan2(_facing.x, _facing.z)
	# The invisible initial capsule mesh is not a runtime pose dependency. The
	# native role and actual environmental stamp select fixed pixels without a clock.
	if is_instance_valid(_sprite_art):
		_sprite_art.call("set_pose", _art_phase(), _facing, get_viewport().get_camera_3d())


func _exit_tree() -> void:
	# Parent retires its complete field/coordinator unit. This narrow source
	# hook releases only genuine retained Route custody; never fakes HP/death.
	var consumer: CinderSporeRepulsion = _spore_consumer()
	if consumer != null:
		consumer.source_interrupted(self, "actual_death" if dead else "source_removed")
	if is_instance_valid(_scheduler):
		if _scheduler.reservation_invalidated.is_connected(_on_invalidated):
			_scheduler.reservation_invalidated.disconnect(_on_invalidated)
		_scheduler.cancel_owner(self, "mushroom_selenite_removed")
