class_name CinderCampaignShell
extends "res://scripts/game.gd"
## Desktop consumer over the existing portrait view, controller and recognizer.
## Every durable operation runs at a deferred paused barrier. Scene candidates
## have their own World3D and are fully validated before the live world changes.

const Registry = preload("res://scripts/campaign/registry.gd")
const Attempts = preload("res://scripts/campaign/attempts.gd")
const Store = preload("res://scripts/campaign/save_store.gd")
const Settings = preload("res://scripts/settings/game_settings.gd")
const Menu = preload("res://scripts/ui/campaign_menu.gd")
const Equipment = preload("res://scripts/equipment.gd")
const Codec = preload("res://scripts/campaign/snapshot_codec.gd")
const Difficulty = preload("res://scripts/combat/difficulty.gd")
const FreshCaptureExact = preload("res://scripts/campaign/exact_json.gd")
const FreshCapturePlayer = preload("res://scripts/player.gd")
const SHELL_API: String = "campaign-shell-1"

var registry: CinderCampaignRegistry
var attempts: CinderCampaignAttempts
var settings: CinderGameSettings
var menu: CinderCampaignMenu
var campaign_error: String = ""
var _save_path: String = "user://cinder/campaign.json"
var _settings_path: String = "user://cinder/settings.json"
var _preferences_path: String = "user://cinder/preferences.json"
var _preferences_store: CinderSaveStore
var _difficulty_preference: String = "standard"
var _difficulty_at_entry: String = "standard"
var _preview_mode: bool = false
var _operations: Array[Dictionary] = []
var _draining: bool = false
var _drain_queued: bool = false
var _validation_candidates: Dictionary = {}
var _failed_operations: Array[Dictionary] = []
var _old_auto_quit: bool = true
var _resume_after_drain: bool = false
var _registered_snapshots: Dictionary = {}
var _registration_epoch: int = 0
var _registration_ready: bool = false
var _registration_pending: bool = false
var _registration_inflight: bool = false
var _registration_cancelled: bool = false
var _registration_error: String = ""
var _snapshot_validation_busy: bool = false

## Test harnesses may inject accepted fixture metadata and isolated user paths
## before entering the tree. This never edits the canonical campaign registry.
func configure_runtime(raw_registry: Dictionary = {}, save_path: String = "user://cinder/campaign.json", settings_path: String = "user://cinder/settings.json", preferences_path: String = "user://cinder/preferences.json") -> bool:
	if is_inside_tree():
		return false
	registry = Registry.new(raw_registry)
	if not registry.last_error.is_empty():
		campaign_error = registry.last_error
		return false
	_save_path = save_path
	_settings_path = settings_path
	_preferences_path = preferences_path
	return true

func _ready() -> void:
	for argument: String in OS.get_cmdline_user_args():
		if argument.begins_with("--level-scene") or argument == "--capture" or argument == "--capture-polish":
			_preview_mode = true
	if _preview_mode:
		super._ready()
		return
	_build_view()
	if registry == null:
		registry = Registry.new()
	settings = Settings.new(_settings_path)
	settings.load_settings()
	settings.apply_runtime()
	_apply_cosmetic_policy()
	_preferences_store = Store.new(_preferences_path)
	_preferences_store.payload_validator = _preferences_error
	var preferences: Dictionary = _preferences_store.read_payload()
	if _preferences_error(preferences).is_empty():
		_difficulty_preference = preferences.profile_id
	attempts = Attempts.new(registry, Store.new(_save_path))
	attempts.snapshot_validator = _snapshot_problem
	hud = HUDScript.new()
	add_child(hud)
	hud.set_campaign_mode()
	hud.hide_overlay()
	hud.restart_requested.connect(request_retry)
	hud.bench_requested.connect(request_pause)
	hud.start_requested.connect(resume_campaign)
	hud.visible = false
	menu = Menu.new()
	menu.configure(registry, attempts, settings)
	add_child(menu)
	menu.set_difficulty_preference(_difficulty_preference)
	menu.begin_story_requested.connect(func() -> void: _enqueue("begin"))
	menu.continue_story_requested.connect(func() -> void: _enqueue("continue"))
	menu.optional_requested.connect(func(id: String) -> void: _enqueue("side", {"kind": "optional", "level_id": id}))
	menu.replay_requested.connect(func(id: String, loadout: Dictionary) -> void: _enqueue("side", {"kind": "replay", "level_id": id, "loadout": loadout.duplicate(true)}))
	menu.restart_replay_requested.connect(func(id: String, loadout: Dictionary) -> void: _enqueue("restart_replay", {"level_id": id, "loadout": loadout.duplicate(true)}))
	menu.resume_requested.connect(resume_campaign)
	menu.retry_requested.connect(request_retry)
	menu.leave_side_requested.connect(func() -> void: _enqueue("leave_side"))
	menu.journey_requested.connect(func() -> void: _enqueue("journey"))
	menu.settings_changed_request.connect(_settings_requested)
	menu.difficulty_preference_requested.connect(_difficulty_requested)
	menu.retry_failed_operation_requested.connect(retry_pending_operations)
	get_tree().paused = true
	_old_auto_quit = get_tree().auto_accept_quit
	get_tree().auto_accept_quit = false
	if FileAccess.file_exists(_save_path) or FileAccess.file_exists(_save_path + ".bak"):
		_draining = true
		if _startup_registration_required():
			# Latch before yielding; always-mode Menu/HUD events only queue work.
			_draining = true
			_finish_startup_load.call_deferred()
		else:
			if not attempts.load_saved(): campaign_error = attempts.last_error
			else: campaign_error = attempts.last_warning
			_draining = false
	_dispose_validation_candidates()
	menu.show_title()
	if not campaign_error.is_empty():
		menu.show_error(campaign_error)
	if not _draining and not _operations.is_empty():
		_drain_queued = true
		_drain.call_deferred()

func get_difficulty_preference() -> String:
	return _difficulty_preference

func request_pause() -> void:
	if _preview_mode:
		super.open_bench()
	else:
		_enqueue("pause")

func _pause_at_barrier() -> void:
	request_pause()

func request_retry() -> void:
	if _preview_mode:
		super.reset_lab()
	else:
		_enqueue("retry")

func reset_lab() -> void:
	if _preview_mode:
		super.reset_lab()
	else:
		request_retry()

func resume_lab() -> void:
	if _preview_mode:
		super.resume_lab()
	else:
		resume_campaign()

func resume_campaign() -> void:
	if _preview_mode:
		super.resume_lab()
		return
	if _pause_request_pending or _draining or _drain_queued or not _failed_operations.is_empty():
		return
	if not is_instance_valid(active_level):
		_enqueue("load_active")
		return
	if not is_instance_valid(player) or player.dead:
		menu.show_pause()
		menu.show_error("Retry your saved checkpoint.")
		return
	_clear_gesture_chain()
	hud.hide_overlay()
	hud.visible = true
	menu.hide_menu()
	get_viewport().set_input_as_handled()
	get_tree().paused = false

func _enqueue(kind: String, data: Dictionary = {}) -> void:
	if _preview_mode:
		return
	if _registration_inflight and kind in ["retry", "leave_side", "quit"]:
		_cancel_registration_preparation()
	if kind == "retry" or kind == "leave_side":
		_failed_operations.clear()
	elif not _failed_operations.is_empty():
		# Navigation/focus events cannot replace a failed completion or transition.
		# An explicit checkpoint retry/side abandonment is the supported discard.
		get_tree().paused = true
		_clear_gesture_chain()
		if kind == "quit":
			if not _failed_operations.any(func(value: Dictionary) -> bool: return value.operation == "quit"):
				_failed_operations.append({"operation": "quit", "resume_after": false})
			retry_pending_operations.call_deferred()
		else:
			menu.show_pause() if is_instance_valid(active_level) else menu.show_title()
			menu.show_commit_error(campaign_error)
		return
	data = data.duplicate(true)
	data["operation"] = kind
	data["resume_after"] = not get_tree().paused and ["checkpoint", "complete"].has(kind)
	_operations.append(data)
	if not Engine.is_in_physics_frame():
		get_tree().paused = true
	_clear_gesture_chain()
	if not _drain_queued and not _draining:
		_drain_queued = true
		_drain.call_deferred()

func _drain() -> void:
	_drain_queued = false
	if _draining or not is_instance_valid(menu):
		return
	_draining = true
	get_tree().paused = true
	_clear_gesture_chain()
	# Pause notifications may queue quiet settlement of the final native tick.
	# Commit after those callbacks, with input and simulation still latched.
	_commit_drain.call_deferred()

func _commit_drain() -> void:
	if not _draining or not is_instance_valid(menu):
		return
	campaign_error = ""
	while not _operations.is_empty():
		var operation: Dictionary = _operations.pop_front()
		var performed: bool = await _perform(operation)
		if not is_inside_tree(): return
		_dispose_registration_scope()
		if not performed and _registration_cancelled:
			_registration_cancelled = false
			continue
		if not performed:
			_failed_operations = [operation]
			_failed_operations.append_array(_operations)
			_operations.clear()
			menu.show_pause() if is_instance_valid(active_level) else menu.show_title()
			menu.show_commit_error(campaign_error)
			break
	_dispose_validation_candidates()
	_draining = false
	if _failed_operations.is_empty() and _resume_after_drain:
		resume_campaign.call_deferred()

func retry_pending_operations() -> void:
	if _failed_operations.is_empty() or _draining or _drain_queued:
		return
	_operations.append_array(_failed_operations)
	_failed_operations.clear()
	get_tree().paused = true
	_clear_gesture_chain()
	_drain_queued = true
	_drain.call_deferred()

func _perform(operation: Dictionary) -> bool:
	if _registration_inflight: return _fail("Campaign operation cannot reenter registration preparation")
	_resume_after_drain = operation.get("resume_after", false)
	match operation.operation:
		"begin":
			var candidate: Dictionary = _prepare("A1-L1", Equipment.STARTER)
			if candidate.is_empty():
				return false
			var snapshot: Dictionary = _capture_fresh_candidate(candidate, _fresh_shell_state())
			if snapshot.is_empty():
				_dispose(candidate)
				return false
			if not await _prepare_registration([snapshot], {}, candidate):
				_dispose(candidate)
				return false
			if not attempts.begin_story(snapshot):
				_dispose(candidate)
				return _fail(attempts.last_error if not attempts.last_error.is_empty() else campaign_error)
			_install(candidate, snapshot.shell)
			menu.show_resume("story")
		"continue":
			if attempts.state().side_attempt != null:
				return await _leave_side(true)
			return await _load_active()
		"load_active":
			return await _load_active()
		"pause", "journey":
			if is_instance_valid(active_level) and not await _record_live(false):
				return false
			menu.show_journey() if operation.operation == "journey" else menu.show_pause()
		"checkpoint":
			# A request can precede actual death later in the same native tick.
			# Persist that fatal active unit, retaining the last living Retry unit.
			var living: bool = is_instance_valid(player) and not player.dead
			if operation.level_id != active_level.level_id or not await _record_live(living):
				return false
			if living:
				menu.show_resume(attempts.active_kind())
			else:
				_resume_after_drain = false
				menu.show_pause()
		"complete":
			var snapshot: Dictionary = capture_campaign_snapshot()
			if operation.level_id != active_level.level_id or snapshot.is_empty(): return false
			if not await _prepare_registration([snapshot]): return false
			if not attempts.complete_active(snapshot):
				return _fail(attempts.last_error)
			# Completion records progress. Contact exit remains an authored event.
			menu.show_resume(attempts.active_kind())
		"exit":
			if operation.level_id != active_level.level_id or not await _record_live(false):
				return false
			if attempts.state().side_attempt != null:
				return await _leave_side()
			var next_id: String = registry.next_main(active_level.level_id)
			if next_id.is_empty():
				menu.show_journey()
				return true
			var candidate: Dictionary = _prepare(next_id, player.equipment.snapshot(), {"hp": player.hp, "shells": player.shells, "reload_s": player.snapshot_state().clocks.reload_s})
			if candidate.is_empty():
				return false
			var state: Dictionary = _fresh_shell_state()
			state.anchor_normalized = [_swipe_end_normalized.x, _swipe_end_normalized.y]
			var snapshot: Dictionary = _capture_fresh_candidate(candidate, state)
			if snapshot.is_empty():
				_dispose(candidate)
				return false
			if not await _prepare_registration([snapshot], {}, candidate):
				_dispose(candidate)
				return false
			if not attempts.advance_story(snapshot):
				_dispose(candidate)
				return _fail(attempts.last_error)
			_install(candidate, snapshot.shell)
			menu.show_resume("story")
		"retry":
			var active: Variant = attempts.state().story if attempts.state().side_attempt == null else attempts.state().side_attempt
			if active == null:
				return _fail("No checkpoint to retry")
			if not await _prepare_registration([active.checkpoint], active.checkpoint): return false
			var candidate: Dictionary = _prepare_snapshot(active.checkpoint)
			if candidate.is_empty():
				return false
			if attempts.retry_snapshot().is_empty():
				_dispose(candidate)
				return _fail(attempts.last_error)
			_install(candidate, active.checkpoint.shell)
			menu.show_resume(attempts.active_kind())
		"side":
			if not is_instance_valid(active_level) and not await _load_active():
				return false
			if not await _record_live(false):
				return false
			var loadout: Dictionary = operation.get("loadout", player.equipment.snapshot())
			var candidate: Dictionary = _prepare(operation.level_id, loadout)
			if candidate.is_empty():
				return false
			var snapshot: Dictionary = _capture_fresh_candidate(candidate, _fresh_shell_state())
			if snapshot.is_empty():
				_dispose(candidate)
				return false
			if not await _prepare_registration([snapshot], {}, candidate):
				_dispose(candidate)
				return false
			if not attempts.begin_side(operation.kind, operation.level_id, snapshot):
				_dispose(candidate)
				return _fail(attempts.last_error)
			_install(candidate, snapshot.shell)
			menu.show_resume(operation.kind)
		"leave_side":
			return await _leave_side()
		"restart_replay":
			var candidate: Dictionary = _prepare(operation.level_id, operation.loadout)
			if candidate.is_empty():
				return false
			var snapshot: Dictionary = _capture_fresh_candidate(candidate, _fresh_shell_state())
			if snapshot.is_empty():
				_dispose(candidate)
				return false
			if not await _prepare_registration([snapshot], {}, candidate):
				_dispose(candidate)
				return false
			if not attempts.restart_replay(snapshot):
				_dispose(candidate)
				return _fail(attempts.last_error)
			_install(candidate, snapshot.shell)
			menu.show_resume("replay")
		"quit":
			if is_instance_valid(active_level) and not await _record_live(false):
				return false
			get_tree().quit()
	return true

func _load_active() -> bool:
	var snapshot: Dictionary = attempts.active_snapshot()
	if snapshot.is_empty():
		return _fail("Begin the story first.")
	if not await _prepare_registration([snapshot], snapshot): return false
	var candidate: Dictionary = _prepare_snapshot(snapshot)
	if candidate.is_empty():
		return false
	_install(candidate, snapshot.shell)
	# A latched authored exit may have awaited an unavailable accepted scene or
	# a disk retry. Continue is the explicit consumer; never require a duplicate
	# contact event that the restored level correctly suppresses.
	if not String(snapshot.level.progress.get("contact_exit_id", "")).is_empty():
		if attempts.state().side_attempt != null:
			return await _leave_side()
		var next_id: String = registry.next_main(snapshot.level_id)
		if next_id.is_empty() or registry.is_playable(next_id):
			return await _perform({"operation": "exit", "level_id": snapshot.level_id})
	menu.show_resume(attempts.active_kind())
	return true

func _leave_side(continue_story: bool = false) -> bool:
	var preserved: Dictionary = attempts.story_snapshot()
	if not await _prepare_registration([preserved], preserved): return false
	var candidate: Dictionary = _prepare_snapshot(preserved)
	if candidate.is_empty():
		return false
	if attempts.leave_side().is_empty():
		_dispose(candidate)
		return _fail(attempts.last_error)
	_install(candidate, preserved.shell)
	if not continue_story or _story_exit_complete():
		menu.show_journey()
	else:
		menu.show_resume("story")
	menu.show_notice("Story equipment restored.")
	return true

func _story_exit_complete() -> bool:
	var saved: Dictionary = attempts.story_snapshot()
	return attempts.state().completed_main.size() == registry.main_route().size() and not String(saved.get("level", {}).get("progress", {}).get("contact_exit_id", "")).is_empty()

func _record_live(checkpoint: bool) -> bool:
	var snapshot: Dictionary = capture_campaign_snapshot()
	if snapshot.is_empty():
		return false
	if not await _prepare_registration([snapshot]): return false
	return attempts.record_snapshot(snapshot, checkpoint) or _fail(attempts.last_error)

func capture_campaign_snapshot() -> Dictionary:
	if not get_tree().paused or not is_instance_valid(active_level) or not is_instance_valid(player):
		_fail("Capture requires an active level at a paused deferred boundary")
		return {}
	return _capture(player, active_level, _shell_state())

func _capture(actor: CinderPlayer, level: CinderLevel, shell_state: Dictionary) -> Dictionary:
	var player_state: Dictionary = actor.snapshot_state()
	var local_state: Dictionary = level.snapshot_state()
	if player_state.is_empty() or local_state.is_empty():
		_fail(actor.last_snapshot_error if player_state.is_empty() else level.last_snapshot_error)
		return {}
	if Codec.read_vector3(shell_state.camera_focus).is_zero_approx():
		shell_state.camera_focus = Codec.vector3(actor.global_position + Vector3.UP * 0.75)
	return {"schema_version": 1, "level_id": level.level_id, "scene_path": level.scene_file_path, "paused": true, "equipment_ids": actor.equipment.snapshot(), "player": player_state, "level": local_state, "shell": shell_state}

## Only begin/exit/side/restart fresh constructors use this path.
## Saved restoration retains its independent quiet commit + saved-focus gate.
func _capture_fresh_candidate(candidate: Dictionary, shell_state: Dictionary) -> Dictionary:
	var error: String = _fresh_capture_binding_error(candidate)
	if not error.is_empty():
		_fail("Fresh candidate presentation failed: " + error)
		return {}
	var original_bindings: Dictionary = candidate.duplicate()
	var actor: CinderPlayer = candidate.player
	var level: CinderLevel = candidate.level
	var actual_camera: Camera3D = candidate.camera
	var actor_script: Script = actor.get_script()
	var level_script: Script = level.get_script()
	var effects_script: Script = candidate.fx.get_script()
	var player_state: Dictionary = actor.snapshot_state()
	var actor_before: String = FreshCaptureExact.stringify(player_state)
	if player_state.is_empty() or actor_before.is_empty():
		_fail("Fresh candidate capture requires a complete bounded actual Player snapshot")
		return {}
	error = _shell_state_error(shell_state, player_state)
	if not error.is_empty() or Codec.read_vector3(shell_state.camera_focus) != Vector3.ZERO:
		_fail("Fresh candidate capture requires original fresh Shell state, never a saved focus")
		return {}
	var outer_size: Vector2 = hud.get_viewport().get_visible_rect().size
	if not outer_size.is_finite() or outer_size.x < 1.0 or outer_size.y < 1.0 or outer_size.x > 16384.0 or outer_size.y > 16384.0 or Vector2(Vector2i(outer_size)) != outer_size:
		_fail("Fresh candidate requires bounded integral outer HUD pixels")
		return {}
	var hud_viewport := SubViewport.new()
	hud_viewport.name = "FreshCaptureHUDViewport"
	hud_viewport.size = Vector2i(outer_size)
	hud_viewport.disable_3d = true
	hud_viewport.handle_input_locally = false
	hud_viewport.gui_disable_input = true
	hud_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(hud_viewport)
	var framing_hud: GameHUD = HUDScript.new()
	framing_hud.name = "FreshCaptureHUD"
	framing_hud.visible = false
	hud_viewport.add_child(framing_hud)
	framing_hud.set_campaign_mode()
	framing_hud.hide_overlay()
	var objective: String = level.objective_text
	framing_hud.update_status(actor.hp, actor.max_hp, actor.shells, actor.max_shells, 0, objective)
	var hud_before: String = _fresh_capture_hud_wire(framing_hud)
	if hud_before.is_empty(): error = "Actual canonical staging HUD shape unavailable"
	var points: Array = level.camera_framing_points()
	if not level.last_camera_framing_error.is_empty(): error = level.last_camera_framing_error
	var mandatory: Array = player_camera_framing_points_for(actor, actual_camera)
	var points_before: String = _fresh_capture_points_wire(points)
	var mandatory_before: String = _fresh_capture_points_wire(mandatory)
	if points_before.is_empty() or mandatory_before.is_empty() or mandatory.is_empty(): error = "Bounded actual required source/Player corners unavailable"
	var plan: Dictionary = {}
	if error.is_empty():
		plan = camera_framing_plan_for_context(points, actor.global_position + Vector3.UP * 0.75, actor, actual_camera, framing_hud)
		if not plan.get("accepted", false): error = String(plan.get("reason", "Actual fresh full-union framing rejected"))
	var focus: Vector3 = Vector3.ZERO
	var prepared_state: Dictionary = shell_state.duplicate(true)
	var local_state: Dictionary = {}
	# All writes stay in this hidden candidate, never installed Game aliases.
	if error.is_empty():
		focus = plan.focus
		actual_camera.global_position = focus + CAMERA_OFFSET
		prepared_state.camera_focus = Codec.vector3(focus)
		var contained: Array = points if not points.is_empty() else mandatory
		error = camera_framing_error_for_context(contained, actor, actual_camera, framing_hud)
	if error.is_empty():
		local_state = level.snapshot_state_for_presentation(actual_camera, framing_hud)
		if local_state.is_empty(): error = level.last_snapshot_error if not level.last_snapshot_error.is_empty() else "Actual fresh local capture refused"
	if error.is_empty(): error = _fresh_capture_binding_error(candidate)
	if error.is_empty():
		for key: String in original_bindings:
			if candidate[key] != original_bindings[key]:
				error = "Fresh hook replaced an original native constructor node"
				break
	if error.is_empty() and (candidate.player != actor or candidate.level != level or candidate.camera != actual_camera or actor.get_script() != actor_script or level.get_script() != level_script or candidate.fx.get_script() != effects_script): error = "Fresh capture replaced actual retained native bindings or Scripts"
	# Preserve ordinary whole-level validation before any Attempts/disk commit.
	# This runs outside the writer, with no wider busy/reentry allowance.
	if error.is_empty(): error = level.snapshot_error(local_state)
	if error.is_empty(): error = _fresh_capture_binding_error(candidate)
	if error.is_empty():
		for key: String in original_bindings:
			if candidate[key] != original_bindings[key]:
				error = "Fresh hook replaced an original native constructor node"
				break
	if error.is_empty() and (candidate.player != actor or candidate.level != level or candidate.camera != actual_camera or actor.get_script() != actor_script or level.get_script() != level_script or candidate.fx.get_script() != effects_script): error = "Fresh validator replaced actual retained bindings or Scripts"
	if error.is_empty() and _fresh_capture_hud_wire(framing_hud) != hud_before: error = "Fresh hook changed actual canonical HUD pixels, objective or safe rectangle"
	if error.is_empty():
		var actor_after: String = FreshCaptureExact.stringify(actor.snapshot_state())
		var actual_points: Array = level.camera_framing_points()
		var actual_mandatory: Array = player_camera_framing_points_for(actor, actual_camera)
		if actor_after.is_empty() or actor_after != actor_before or level.objective_text != objective or _fresh_capture_points_wire(actual_points) != points_before or _fresh_capture_points_wire(actual_mandatory) != mandatory_before or not level.last_camera_framing_error.is_empty() or actual_camera.global_position != focus + CAMERA_OFFSET:
			error = "Fresh capture hook changed actual Player, required bounds, objective or planned camera"
		else:
			error = camera_framing_error_for_context(actual_points if not actual_points.is_empty() else actual_mandatory, actor, actual_camera, framing_hud)
	# No callbacks/yields are authorized in the trusted capture method. A broken
	# hook is rejected, never healed; its candidate is disposed by the caller.
	if is_instance_valid(hud_viewport): hud_viewport.free()
	if not error.is_empty():
		_fail("Fresh candidate presentation failed: " + error)
		return {}
	return {"schema_version": 1, "level_id": level.level_id, "scene_path": level.scene_file_path, "paused": true, "equipment_ids": actor.equipment.snapshot(), "player": player_state, "level": local_state, "shell": prepared_state}

func _fresh_capture_binding_error(candidate: Dictionary) -> String:
	if not get_tree().paused or not is_instance_valid(hud) or not hud.is_inside_tree() or not hud.is_node_ready() or hud.is_queued_for_deletion() or hud.get_script() != HUDScript or hud.custom_viewport != null:
		return "Paused Shell and actual canonical outer HUD required"
	if not Codec.keys_error(candidate, ["container", "viewport", "stage", "camera", "level", "player", "fx"]).is_empty(): return "Complete original fresh constructor required"
	for key: String in ["container", "viewport", "stage", "camera", "level", "player", "fx"]:
		var value: Variant = candidate[key]
		if not is_instance_valid(value) or not value is Node or not value.is_inside_tree() or not value.is_node_ready() or value.is_queued_for_deletion() or value.get_tree() != get_tree(): return "Fresh constructor lost a ready native binding"
	if not candidate.container is SubViewportContainer or not candidate.viewport is SubViewport or not candidate.stage is Node3D or not candidate.camera is Camera3D or not candidate.level is CinderLevel or not candidate.player is CinderPlayer or not candidate.fx is PixelEffects: return "Actual typed fresh constructor required"
	if candidate.container.get_parent() != self or candidate.container.visible or candidate.viewport.get_parent() != candidate.container or not candidate.viewport.own_world_3d or candidate.stage.get_parent() != candidate.viewport or candidate.camera.get_parent() != candidate.stage or candidate.level.get_parent() != candidate.stage or candidate.player.get_parent() != candidate.stage or candidate.fx.get_parent() != candidate.stage: return "Original hidden fresh World3D constructor hierarchy required"
	if candidate.container.get_script() != null or candidate.viewport.get_script() != null or candidate.stage.get_script() != null: return "Original native Script-free constructor container/viewport/stage required"
	if candidate.player.get_script() != FreshCapturePlayer or candidate.fx.get_script() != EffectsScript or candidate.level.get_script() == null: return "Actual canonical Player/effects and retained authored level Script required"
	if candidate.level.is_restore_candidate() or candidate.level.hero != candidate.player or candidate.level.effects != candidate.fx or candidate.level.shared_shell != self or candidate.player.fx != candidate.fx or candidate.camera == camera or candidate.player == player or candidate.level == active_level: return "Fresh ordinary bindings cannot substitute saved recipients or installed aliases"
	return _camera_player_binding_error(candidate.player, candidate.camera)

func _fresh_capture_hud_wire(framing_hud: GameHUD) -> String:
	if not is_instance_valid(framing_hud) or not framing_hud.is_inside_tree() or not framing_hud.is_node_ready() or framing_hud.is_queued_for_deletion() or framing_hud.get_script() != HUDScript or framing_hud.custom_viewport != null or not is_instance_valid(framing_hud._objective_label): return ""
	var pixels: Vector2 = framing_hud.get_viewport().get_visible_rect().size
	var safe: Rect2 = framing_hud.combat_safe_rect()
	return FreshCaptureExact.stringify({"pixels": [float(pixels.x), float(pixels.y)], "objective": framing_hud._objective_label.text, "safe_rect": [float(safe.position.x), float(safe.position.y), float(safe.size.x), float(safe.size.y)]})

func _fresh_capture_points_wire(points: Array) -> String:
	if points.size() > 256: return ""
	var encoded: Array = []
	for value: Variant in points:
		if not value is Vector3 or not value.is_finite() or maxf(absf(value.x), maxf(absf(value.y), absf(value.z))) > 1024.0: return ""
		encoded.append(Codec.vector3(value))
	return FreshCaptureExact.stringify(encoded)

func _prepare(id: String, loadout: Dictionary, carried_resources: Dictionary = {}, restore_snapshot: Dictionary = {}, raw_restore: bool = false) -> Dictionary:
	if not restore_snapshot.is_empty() and (not get_tree().paused or not carried_resources.is_empty() or not restore_snapshot.get("level") is Dictionary or not restore_snapshot.get("player") is Dictionary):
		_fail("Restore candidate construction requires paused whole saved units and no carried-resource seed")
		return {}
	campaign_error = registry.scene_error(id)
	if not campaign_error.is_empty():
		return {}
	# Keep the accepted candidate in its original tree/world. Reparenting a
	# ready level invokes _exit_tree and correctly destroys its entered lifecycle.
	# Instead reveal its already-owned portrait container only after commit.
	var container := SubViewportContainer.new()
	container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	container.stretch = true
	container.stretch_shrink = 2
	container.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	container.visible = false
	add_child(container)
	var viewport := SubViewport.new()
	viewport.name = "PreparedCampaignWorld"
	viewport.own_world_3d = true
	viewport.size = Vector2i(270, 585)
	viewport.handle_input_locally = false
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	container.add_child(viewport)
	var stage := Node3D.new()
	viewport.add_child(stage)
	for child: Node in world.get_children():
		if child is WorldEnvironment or child is DirectionalLight3D:
			stage.add_child(child.duplicate())
	var stage_camera := Camera3D.new()
	stage_camera.projection = camera.projection
	stage_camera.keep_aspect = camera.keep_aspect
	stage_camera.size = camera.size
	stage_camera.transform = camera.transform
	stage.add_child(stage_camera)
	stage_camera.current = true
	var level_node: Node = (load(registry.entry(id).scene_path) as PackedScene).instantiate()
	if not level_node is CinderLevel:
		level_node.free()
		container.free()
		_fail("Accepted scene must instantiate a CinderLevel")
		return {}
	var level: CinderLevel = level_node as CinderLevel
	stage.add_child(level)
	var staged_fx: PixelEffects = EffectsScript.new()
	stage.add_child(staged_fx)
	if staged_fx.has_method("configure_policy"):
		staged_fx.configure_policy(settings.cosmetic_policy())
	var actor: CinderPlayer = PlayerScene.instantiate()
	actor.set_presentation(LabSprite.presentation_for_act(int(id.substr(1, 1))))
	if not actor.equipment.restore(loadout):
		container.free()
		_fail("Fresh actor loadout is unavailable or mismatched")
		return {}
	actor.fx = staged_fx
	stage.add_child(actor)
	actor.global_position = level.spawn_position()
	actor.hp = actor.max_hp
	actor.shells = actor.max_shells
	var candidate: Dictionary = {"container": container, "viewport": viewport, "stage": stage, "camera": stage_camera, "level": level, "player": actor, "fx": staged_fx}
	if raw_restore:
		if restore_snapshot.is_empty():
			_dispose(candidate)
			_fail("Raw registration requires an exact restore packet")
			return {}
		return candidate
	if not restore_snapshot.is_empty() and level.restore_candidate_physics_registration_required():
		_dispose(candidate)
		_fail("Opted fresh World3D requires operation-scoped paused registration before restore entry")
		return {}
	if restore_snapshot.is_empty():
		level.enter_level(actor, staged_fx, self)
	elif not level.enter_restore_candidate(actor, staged_fx, self, restore_snapshot.level, restore_snapshot.player):
		var construction_error: String = level.last_snapshot_error
		_dispose(candidate)
		_fail("Restore candidate construction failed: " + construction_error)
		return {}
	if not carried_resources.is_empty():
		var fresh: Dictionary = actor.snapshot_state()
		fresh.resources.hp = carried_resources.hp
		fresh.resources.shells = carried_resources.shells
		fresh.clocks.reload_s = carried_resources.reload_s
		if not actor.restore_state(fresh):
			_dispose(candidate)
			_fail(actor.last_snapshot_error)
			return {}
	return candidate

func _prepare_snapshot(snapshot: Dictionary) -> Dictionary:
	var error: String = _snapshot_problem(snapshot)
	if not error.is_empty():
		_fail(error)
		return {}
	# Fresh pure validation owns the exact constructed candidate. Never rebuild
	# it through ordinary entry or reuse an ID-only stale construction.
	var candidate: Dictionary
	var wire: String = FreshCaptureExact.stringify(snapshot)
	if _registered_snapshots.has(wire):
		candidate = _registered_install_candidate(snapshot)
	else:
		candidate = _validation_candidates.get(snapshot.level_id, {})
		_validation_candidates.erase(snapshot.level_id)
		if candidate.is_empty():
			candidate = _prepare(snapshot.level_id, snapshot.equipment_ids, {}, snapshot)
	if candidate.is_empty():
		return {}
	# Prevalidation completed for every component before either commit hook.
	if not candidate.player.restore_state(snapshot.player) or not candidate.level.restore_state(snapshot.level):
		_dispose(candidate)
		_fail("Validated aggregate commit hook failed")
		return {}
	# Only the real quietly restored candidate can certify current presentation.
	# Reject before retry/leave operations, donor disposal or Shell alias changes.
	error = _candidate_presentation_error(candidate, snapshot.shell)
	if not error.is_empty():
		_dispose(candidate)
		_fail("Restore candidate presentation failed: " + error)
		return {}
	return candidate

## Construction happens after all mechanical proof and quiet unit commits.
## The temporary HUD has its own offscreen native viewport at the OUTER pixel
## dimensions; using the 270x585 world viewport would shape different fonts.
## It has no campaign button observers and is freed on every outcome.
func _candidate_presentation_error(candidate: Dictionary, shell_state: Dictionary) -> String:
	if not get_tree().paused or not is_instance_valid(hud) or not hud.is_inside_tree() or not hud.is_node_ready() or hud.is_queued_for_deletion() or hud.get_script() != HUDScript or hud.custom_viewport != null:
		return "Ready canonical outer HUD and paused candidate required"
	var outer_size: Vector2 = hud.get_viewport().get_visible_rect().size
	if not outer_size.is_finite() or outer_size.x < 1.0 or outer_size.y < 1.0 or outer_size.x > 16384.0 or outer_size.y > 16384.0 or Vector2(Vector2i(outer_size)) != outer_size:
		return "Outer HUD requires bounded integral native pixel dimensions"
	if not is_instance_valid(candidate.get("player")) or not is_instance_valid(candidate.get("level")) or not is_instance_valid(candidate.get("camera")):
		return "Quietly restored native candidate bindings unavailable"
	# Saved focus changes only this candidate Camera3D. Installed focus, shake,
	# aim, HUD, resources and donor aliases remain untouched until installation.
	candidate.camera.global_position = Codec.read_vector3(shell_state.camera_focus) + CAMERA_OFFSET
	var hud_viewport := SubViewport.new()
	hud_viewport.name = "RestorePresentationHUDViewport"
	hud_viewport.size = Vector2i(outer_size)
	hud_viewport.disable_3d = true
	hud_viewport.handle_input_locally = false
	hud_viewport.gui_disable_input = true
	hud_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(hud_viewport)
	var framing_hud: GameHUD = HUDScript.new()
	framing_hud.name = "RestorePresentationHUD"
	framing_hud.visible = false
	hud_viewport.add_child(framing_hud)
	framing_hud.set_campaign_mode()
	framing_hud.hide_overlay()
	framing_hud.update_status(candidate.player.hp, candidate.player.max_hp, candidate.player.shells, candidate.player.max_shells, 0, candidate.level.objective_text)
	var error: String = ""
	if hud_viewport.get_visible_rect().size != outer_size:
		error = "Staging HUD viewport differs from the actual outer pixel dimensions"
	else:
		error = candidate.level.restore_candidate_presentation_error(candidate.camera, framing_hud)
	if is_instance_valid(hud_viewport): hud_viewport.free()
	return error

func _snapshot_problem_unlocked(snapshot: Dictionary) -> String:
	if not get_tree().paused:
		return "Aggregate validation requires a paused candidate boundary"
	# Legacy submissions retain fresh construction/destruction. Only opted
	# exact packets may retain uncommitted construction within this operation.
	_dispose_validation_candidates()
	var error: String = Codec.value_error(snapshot)
	if not error.is_empty():
		return error
	if not snapshot.get("level_id") is String or not snapshot.get("player") is Dictionary or not snapshot.get("level") is Dictionary or not snapshot.get("shell") is Dictionary or not snapshot.get("equipment_ids") is Dictionary:
		return "Missing live aggregate components"
	var id: String = snapshot.level_id
	if snapshot.get("scene_path") != registry.entry(id).get("scene_path") or snapshot.level.get("level_id") != id or snapshot.level.get("scene_path") != snapshot.scene_path:
		return "Aggregate scene identity differs from accepted registry"
	if not Codec.same_values(snapshot.equipment_ids, snapshot.player.get("equipment")):
		return "Actor gear differs from aggregate equipment"
	var candidate: Dictionary = {}
	var registered_row: Dictionary = {}
	var wire: String = FreshCaptureExact.stringify(snapshot)
	if _registered_snapshots.has(wire):
		registered_row = _registered_snapshots[wire].validation
		candidate = _enter_registered_candidate(snapshot, registered_row)
		if candidate.is_empty(): return _registration_error
	elif is_instance_valid(active_level) and active_level.level_id == id and active_level.scene_file_path == snapshot.scene_path and not active_level.restore_candidate_construction_required() and not active_level.restore_candidate_physics_registration_required():
		candidate = {"player": player, "level": active_level}
	else:
		candidate = _prepare(id, snapshot.equipment_ids, {}, snapshot)
		if candidate.is_empty():
			return campaign_error
		_validation_candidates[id] = candidate
	error = candidate.player.snapshot_error(snapshot.player)
	if error.is_empty():
		# Cross-component local proof uses this validated saved actor, not a
		# fresh candidate's spawn pose. Commit still restores actor before level.
		error = candidate.level.snapshot_error_with_player(snapshot.level, snapshot.player)
	if error.is_empty():
		error = _shell_state_error(snapshot.shell, snapshot.player)
	if not registered_row.is_empty():
		if error.is_empty(): error = _registration_row_error(registered_row)
		if not error.is_empty(): _reject_registration_row(registered_row)
	return error

func _install(candidate: Dictionary, shell_state: Dictionary) -> void:
	if not candidate.level.finish_restore_candidate():
		_dispose(candidate)
		_fail("Uncommitted restore candidate cannot become playable")
		return
	_clear_gesture_chain()
	var old_container: Node = world.get_parent().get_parent()
	if is_instance_valid(active_level):
		active_level.exit_level()
	if is_instance_valid(player):
		player.cancel_world_action_capture()
	if is_instance_valid(fx):
		fx.clear_lab()
	active_level = candidate.level
	player = candidate.player
	fx = candidate.fx
	world = candidate.stage
	camera = candidate.camera
	level_scene_path = active_level.scene_file_path
	old_container.free()
	candidate.container.visible = true
	_restore_shell_state(shell_state)
	active_level.completion_requested.connect(func(id: String, _completion_id: String) -> void: _enqueue("complete", {"level_id": id}))
	active_level.checkpoint_requested.connect(func(id: String, _checkpoint_id: String, _boundary: String) -> void: _enqueue("checkpoint", {"level_id": id}))
	active_level.contact_exit_requested.connect(func(id: String, _exit_id: String) -> void: _enqueue("exit", {"level_id": id}))
	player.fired.connect(_on_fired)
	player.died.connect(func() -> void: _enqueue("pause"))
	player.equipment_changed.connect(func(id: String) -> void: hud.flash_message("Equipped " + player.equipment.item_name(id)))
	hud.visible = true
	hud.hide_overlay()
	_apply_cosmetic_policy()
	_update_status()

func _dispose(candidate: Dictionary) -> void:
	if is_instance_valid(candidate.get("level")):
		candidate.level.exit_level()
	if is_instance_valid(candidate.get("fx")):
		candidate.fx.clear_lab()
	if is_instance_valid(candidate.get("container")):
		candidate.container.free()

func _dispose_validation_candidates() -> void:
	for candidate: Dictionary in _validation_candidates.values():
		_dispose(candidate)
	_validation_candidates.clear()

func _fresh_shell_state() -> Dictionary:
	return {"api_revision": SHELL_API, "anchor_normalized": [0.5, 0.5], "input_sequence": 0, "last_input_observation": {}, "camera_focus": [0.0, 0.0, 0.0], "shake_left_s": 0.0, "difficulty_at_entry": _difficulty_preference}

func _shell_state() -> Dictionary:
	var observation: Dictionary = _last_input_observation.duplicate(true)
	if not observation.is_empty():
		observation.screen_position_normalized = [observation.screen_position_normalized.x, observation.screen_position_normalized.y]
		observation.anchor_normalized = [observation.anchor_normalized.x, observation.anchor_normalized.y]
		observation.direction = Codec.vector3(observation.direction)
	return {"api_revision": SHELL_API, "anchor_normalized": [_swipe_end_normalized.x, _swipe_end_normalized.y], "input_sequence": _input_sequence, "last_input_observation": observation, "camera_focus": Codec.vector3(_camera_focus), "shake_left_s": _shake, "difficulty_at_entry": _difficulty_at_entry}

func _shell_state_error(state: Dictionary, actor: Dictionary) -> String:
	var error: String = Codec.keys_error(state, ["api_revision", "anchor_normalized", "input_sequence", "last_input_observation", "camera_focus", "shake_left_s", "difficulty_at_entry"])
	if not error.is_empty() or state.api_revision != SHELL_API:
		return "Unsupported campaign shell state"
	if not _screen_pair(state.anchor_normalized) or not Codec.is_integer(state.input_sequence) or not Codec.is_vector3(state.camera_focus) or not Codec.in_range(state.shake_left_s, 0.0, 1.0) or not ["assisted", "standard", "challenge"].has(state.difficulty_at_entry) or not state.last_input_observation is Dictionary:
		return "Invalid input/camera/profile state"
	var record: Dictionary = state.last_input_observation
	if record.is_empty():
		return "" if state.input_sequence == 0 else "Missing last input observation"
	error = Codec.keys_error(record, ["schema_version", "sequence", "kind", "screen_position_normalized", "anchor_normalized", "direction", "accepted", "world_action_sequence", "action_clock_s"])
	if not error.is_empty() or not Codec.is_integer(record.sequence, 1) or record.sequence != state.input_sequence or record.schema_version != 1 or not ["swipe_release", "primary_tap", "blast_tap"].has(record.kind) or not _screen_pair(record.screen_position_normalized) or not _screen_pair(record.anchor_normalized) or not Codec.is_vector3(record.direction) or not record.accepted is bool or not Codec.is_integer(record.world_action_sequence, 0, int(actor.world_actions.sequence)) or not Codec.in_range(record.action_clock_s, 0.0, float(actor.world_actions.clock_s)):
		return "Invalid teaching-observer state"
	if not Codec.same_values(record.anchor_normalized, state.anchor_normalized):
		return "Observer and exact release anchor disagree"
	return ""

func _screen_pair(value: Variant) -> bool:
	return value is Array and value.size() == 2 and Codec.is_number(value[0]) and Codec.is_number(value[1]) and absf(float(value[0])) <= 1000000.0 and absf(float(value[1])) <= 1000000.0

func _restore_shell_state(state: Dictionary) -> void:
	_swipe_end_normalized = Vector2(float(state.anchor_normalized[0]), float(state.anchor_normalized[1]))
	_input_sequence = int(state.input_sequence)
	_last_input_observation = (state.last_input_observation as Dictionary).duplicate(true)
	if not _last_input_observation.is_empty():
		_last_input_observation.sequence = int(_last_input_observation.sequence)
		_last_input_observation.world_action_sequence = int(_last_input_observation.world_action_sequence)
		_last_input_observation.screen_position_normalized = Vector2(float(_last_input_observation.screen_position_normalized[0]), float(_last_input_observation.screen_position_normalized[1]))
		_last_input_observation.anchor_normalized = Vector2(float(_last_input_observation.anchor_normalized[0]), float(_last_input_observation.anchor_normalized[1]))
		_last_input_observation.direction = Codec.read_vector3(_last_input_observation.direction)
	_camera_focus = Codec.read_vector3(state.camera_focus)
	_shake = float(state.shake_left_s)
	_difficulty_at_entry = state.difficulty_at_entry
	camera.global_position = _camera_focus + CAMERA_OFFSET

func _settings_requested(changes: Dictionary) -> void:
	if _draining or _drain_queued:
		menu.acknowledge_settings(false, "Finish the pending campaign operation first")
		return
	var accepted: bool = settings.update(changes)
	if accepted:
		settings.apply_runtime()
		_apply_cosmetic_policy()
	menu.acknowledge_settings(accepted, settings.last_error if not accepted else "")

func _difficulty_requested(profile_id: String) -> void:
	if _draining or _drain_queued:
		menu.set_difficulty_preference(_difficulty_preference)
		return
	var candidate: Dictionary = {"schema_version": 1, "profile_id": profile_id}
	if not _preferences_error(candidate).is_empty() or not _preferences_store.write_payload(candidate):
		menu.set_difficulty_preference(_difficulty_preference)
		menu.show_error(_preferences_store.last_error)
		return
	_difficulty_preference = profile_id
	menu.set_difficulty_preference(profile_id)
	# Active scheduler profiles live in the local encounter snapshot. Only the
	# next authored fresh boundary reads this preference; no live retuning.

func _preferences_error(candidate: Dictionary) -> String:
	return "" if candidate.size() == 2 and candidate.get("schema_version") == 1 and ["assisted", "standard", "challenge"].has(candidate.get("profile_id")) else "Invalid fresh-encounter preference"

func _apply_cosmetic_policy() -> void:
	if is_instance_valid(fx) and settings != null and fx.has_method("configure_policy"):
		fx.configure_policy(settings.cosmetic_policy())

func _process(delta: float) -> void:
	if _preview_mode:
		super._process(delta)
		return
	if not is_instance_valid(player) or _registration_inflight:
		return
	_shake = maxf(_shake - delta, 0.0)
	# Frame against the HUD this frame renders, including newly wrapped text.
	_update_status()
	_update_camera(delta)
	var shake_scale: float = 1.0
	if fx.has_method("camera_shake_scale"):
		shake_scale = fx.camera_shake_scale()
	if _shake > 0.0 and shake_scale > 0.0:
		camera.position.x += randf_range(-0.035, 0.035) * shake_scale
		camera.position.z += randf_range(-0.035, 0.035) * shake_scale

func _update_status() -> void:
	if is_instance_valid(player) and is_instance_valid(active_level):
		hud.update_status(player.hp, player.max_hp, player.shells, player.max_shells, 0, active_level.objective_text)
		hud.update_lab(player, get_aim_anchor(), false)

func handle_tap(screen_pos: Vector2) -> void:
	if not _preview_mode and (_draining or _drain_queued or menu == null or menu.is_open()):
		return
	super.handle_tap(screen_pos)

func _unhandled_input(event: InputEvent) -> void:
	if not _preview_mode and (menu == null or menu.is_open() or _draining or _drain_queued):
		return
	super._unhandled_input(event)

func _notification(what: int) -> void:
	if _preview_mode:
		super._notification(what)
	elif is_instance_valid(menu):
		if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
			# Idle menus have no simulation or live unit to pause/persist.
			if is_instance_valid(active_level):
				request_pause()
		elif what == NOTIFICATION_WM_CLOSE_REQUEST:
			_enqueue("quit")

func _exit_tree() -> void:
	if not _preview_mode:
		_registration_epoch += 1
		_registration_cancelled = true
		_registration_pending = false
		_dispose_registration_scope()
		_dispose_validation_candidates()
		if is_instance_valid(active_level):
			active_level.exit_level()
		if is_instance_valid(fx):
			fx.clear_lab()
		get_tree().auto_accept_quit = _old_auto_quit

func _fail(error: String) -> bool:
	campaign_error = error if not error.is_empty() else "Campaign operation could not commit"
	return false

## Opted-in registration is construction custody only. Every semantic callback
## runs the unchanged complete validators against these actual native nodes.
func _registration_packets(session: Dictionary) -> Array[Dictionary]:
	var packets: Array[Dictionary] = []
	for kind: String in ["story", "side_attempt"]:
		var attempt: Variant = session.get(kind)
		if not attempt is Dictionary: continue
		for slot: String in ["snapshot", "checkpoint"]:
			if attempt.get(slot) is Dictionary: packets.append(attempt[slot])
	return packets

func _registration_disk_guard() -> String:
	var rows: Array = []
	for path: String in [_save_path, _save_path + ".bak"]:
		var file: FileAccess = FileAccess.open(path, FileAccess.READ)
		if file == null:
			rows.append([path, false])
			continue
		var size: int = file.get_length()
		file.close()
		rows.append([path, size, FileAccess.get_sha256(path) if size <= Store.MAX_FILE_BYTES else "oversized-refused"])
	return FreshCaptureExact.stringify(rows)

func _registration_donor_guard() -> String:
	var rows: Array = [_shell_state(), attempts.state(), str(active_level.get_instance_id()) if is_instance_valid(active_level) else "", str(player.get_instance_id()) if is_instance_valid(player) else ""]
	if is_instance_valid(player): rows.append(player.snapshot_state())
	if is_instance_valid(active_level):
		# Observe through the actual shared capture API, including a retained
		# refusal. An unavailable donor capture is not accepted saved state.
		var snapshot_diagnostic: String = active_level.last_snapshot_error
		var framing_diagnostic: String = active_level.last_camera_framing_error
		rows.append(active_level.snapshot_state_for_presentation(camera, hud))
		rows.append(active_level.last_snapshot_error)
		rows.append([snapshot_diagnostic, framing_diagnostic])
		# Capture is mechanically pure but its shared API writes diagnostics.
		# Preserve those existing diagnostics; never repair gameplay/native data.
		active_level.last_snapshot_error = snapshot_diagnostic
		active_level.last_camera_framing_error = framing_diagnostic
	# Native camera/input are not allowed to drift during registration staging.
	rows.append(var_to_bytes([camera.global_transform, get_input_observation_state()]).hex_encode())
	return FreshCaptureExact.stringify(rows)

func _registration_floor_guard(candidate: Dictionary) -> String:
	var rows: Array = []
	var pending: Array[Node] = [candidate.stage]
	var seen: int = 0
	while not pending.is_empty():
		var node: Node = pending.pop_back()
		seen += 1
		if seen > 4096: return ""
		pending.append_array(node.get_children())
		if not node is StaticBody3D: continue
		var body: StaticBody3D = node as StaticBody3D
		if (body.collision_layer & 1) == 0: continue
		var shapes: Array = []
		for child: Node in body.get_children():
			if child is CollisionShape3D:
				var collision: CollisionShape3D = child as CollisionShape3D
				var shape: Shape3D = collision.shape
				shapes.append([str(collision.get_instance_id()), collision.transform, collision.disabled, str(shape.get_instance_id()) if is_instance_valid(shape) else "", (shape as BoxShape3D).size if shape is BoxShape3D else Vector3.ZERO])
		rows.append([str(body.get_instance_id()), str(body.get_rid()), str(body.get_world_3d().get_instance_id()), body.global_transform, body.collision_layer, body.collision_mask, body.constant_linear_velocity, body.constant_angular_velocity, shapes])
	return var_to_bytes(rows).hex_encode()

func _registration_row(candidate: Dictionary, wire: String) -> Dictionary:
	return {"candidate": candidate, "bindings": candidate.duplicate(), "wire": wire, "epoch": _registration_epoch, "entered": false, "rejected": false, "world": candidate.stage.get_world_3d(), "level_script": candidate.level.get_script(), "player_script": candidate.player.get_script(), "fx_script": candidate.fx.get_script(), "player_wire": FreshCaptureExact.stringify(candidate.player.snapshot_state()), "floor_guard": _registration_floor_guard(candidate)}

func _registration_row_error(row: Dictionary) -> String:
	if row.is_empty() or row.get("rejected", true) or row.get("epoch") != _registration_epoch or not _registration_ready or not is_inside_tree() or not get_tree().paused:
		return "Exact current paused registration custody required"
	var candidate: Dictionary = row.candidate
	if not Codec.keys_error(candidate, ["container", "viewport", "stage", "camera", "level", "player", "fx"]).is_empty(): return "Original registered candidate hierarchy required"
	for key: String in candidate:
		var node: Variant = candidate[key]
		if node != row.bindings.get(key): return "Registered original native constructor identity changed"
		if not is_instance_valid(node) or not node is Node or not node.is_inside_tree() or not node.is_node_ready() or node.is_queued_for_deletion() or node.get_tree() != get_tree(): return "Registered candidate lost a ready native binding"
	if not candidate.container is SubViewportContainer or not candidate.viewport is SubViewport or not candidate.stage is Node3D or not candidate.camera is Camera3D or not candidate.level is CinderLevel or not candidate.player is CinderPlayer or not candidate.fx is PixelEffects: return "Original typed registered native constructor required"
	if candidate.container.get_parent() != self or candidate.container.visible or candidate.viewport.get_parent() != candidate.container or not candidate.viewport.own_world_3d or candidate.stage.get_parent() != candidate.viewport or candidate.level.get_parent() != candidate.stage or candidate.player.get_parent() != candidate.stage or candidate.fx.get_parent() != candidate.stage or candidate.camera.get_parent() != candidate.stage: return "Registered candidate native ownership changed"
	if candidate.container.get_script() != null or candidate.viewport.get_script() != null or candidate.stage.get_script() != null or candidate.camera.get_script() != null: return "Registered native containers cannot be replaced by Scripts"
	if candidate.stage.get_world_3d() != row.world or candidate.level.get_world_3d() != row.world or candidate.player.get_world_3d() != row.world or candidate.level == active_level or candidate.player == player: return "Registered fresh World3D or donor separation changed"
	if candidate.level.get_script() != row.level_script or candidate.player.get_script() != row.player_script or candidate.fx.get_script() != row.fx_script or not candidate.level.restore_candidate_physics_registration_required(): return "Registered authored/canonical Scripts changed"
	if row.player_wire.is_empty() or FreshCaptureExact.stringify(candidate.player.snapshot_state()) != row.player_wire or row.floor_guard.is_empty() or _registration_floor_guard(candidate) != row.floor_guard: return "Registered pristine Player or immutable floor bindings changed"
	return candidate.level.restore_candidate_registration_error(candidate.player, candidate.fx, self, row.entered)

func _reject_registration_row(row: Dictionary) -> void:
	if row.is_empty() or row.get("rejected", false): return
	row.rejected = true
	var candidate: Dictionary = row.get("bindings", row.get("candidate", {}))
	row.candidate = {}
	row.bindings = {}
	if not candidate.is_empty():
		_dispose(candidate)
		# Even a reparented original stays owned; never dispose a substitution.
		for original: Variant in candidate.values():
			if is_instance_valid(original): original.free()

func _enter_registered_candidate(snapshot: Dictionary, row: Dictionary) -> Dictionary:
	_registration_error = _registration_row_error(row)
	if _registration_error.is_empty() and row.wire != FreshCaptureExact.stringify(snapshot): _registration_error = "Registered construction requires the exact full saved packet"
	if not _registration_error.is_empty():
		_reject_registration_row(row)
		return {}
	var candidate: Dictionary = row.candidate
	if not row.entered:
		# Set before invoking trusted authored code; nested validation is refused.
		row.entered = true
		if not candidate.level.enter_restore_candidate(candidate.player, candidate.fx, self, snapshot.level, snapshot.player):
			_registration_error = candidate.level.last_snapshot_error if not candidate.level.last_snapshot_error.is_empty() else "Restore candidate construction returned false"
		else:
			# This opt-in cannot add or alter floor bodies inside its constructor.
			_registration_error = _registration_row_error(row)
	if not _registration_error.is_empty():
		_reject_registration_row(row)
		return {}
	return candidate

func _dispose_registration_scope() -> void:
	_registration_ready = false
	var previous: Dictionary = _registered_snapshots
	_registered_snapshots = {}
	for entry: Dictionary in previous.values():
		for role: String in ["validation", "installation"]:
			var row: Dictionary = entry.get(role, {})
			if not row.is_empty(): _reject_registration_row(row)

func _cancel_registration_preparation() -> void:
	if not _registration_inflight: return
	_registration_epoch += 1
	_registration_cancelled = true
	_registration_pending = false
	_dispose_registration_scope()

func _prepare_registration(extra: Array = [], install_snapshot: Dictionary = {}, fresh_candidate: Dictionary = {}) -> bool:
	if _registration_inflight or _snapshot_validation_busy or not _draining or not is_inside_tree() or not get_tree().paused:
		return _fail("Registration preparation requires the exclusive paused operation")
	# Covers every callback, including disposal, capability, _ready and capture.
	_registration_inflight = true
	var prepared: bool = await _prepare_registration_unlocked(extra, install_snapshot, fresh_candidate)
	_registration_inflight = false
	return prepared

func _prepare_registration_unlocked(extra: Array, install_snapshot: Dictionary, fresh_candidate: Dictionary) -> bool:
	_dispose_registration_scope()
	_registration_epoch += 1
	_registration_cancelled = false
	var epoch: int = _registration_epoch
	var disk_before: String = ""
	var donor_before: String = ""
	var attempt_before: String = ""
	var fresh_before: String = ""
	var packets: Array[Dictionary] = _registration_packets(attempts.state())
	for packet: Variant in extra:
		if packet is Dictionary: packets.append(packet)
	# Discovery is bounded codec/checksum parsing ONLY. Original Store/Attempts
	# semantic callbacks still decide primary/backup/side acceptance afterwards.
	var discovery: CinderSaveStore = Store.new(_save_path)
	for path: String in [_save_path, _save_path + ".bak"]:
		var envelope: Dictionary = discovery._read_file(path)
		if not envelope.is_empty(): packets.append_array(_registration_packets(envelope.payload))
	var wires: Dictionary = {}
	var bytes: int = 0
	var install_wire: String = FreshCaptureExact.stringify(install_snapshot) if not install_snapshot.is_empty() else ""
	for snapshot: Dictionary in packets:
		var wire: String = FreshCaptureExact.stringify(snapshot)
		if wire.is_empty() or wires.has(wire): continue
		wires[wire] = true
		bytes += wire.to_utf8_buffer().size()
		if wires.size() > 16 or bytes > 32 * 1024 * 1024:
			_dispose_registration_scope()
			return _fail("Registration packet discovery exceeds bounded operation scope")
		if not snapshot.get("level_id") is String or not snapshot.get("equipment_ids") is Dictionary or not snapshot.get("level") is Dictionary or not snapshot.get("player") is Dictionary: continue
		var id: String = snapshot.level_id
		if not registry.scene_error(id).is_empty() or snapshot.get("scene_path") != registry.entry(id).get("scene_path"): continue
		# Pure capability can be queried before entering a tree. Legacy levels
		# never enter the pool and keep the existing per-submission destruction.
		var probe: Node = (load(registry.entry(id).scene_path) as PackedScene).instantiate()
		var opted: bool = probe is CinderLevel and (probe as CinderLevel).restore_candidate_physics_registration_required()
		if is_instance_valid(probe): probe.free()
		if epoch != _registration_epoch or _registration_cancelled: return false
		if not opted: continue
		if donor_before.is_empty():
			disk_before = _registration_disk_guard()
			donor_before = _registration_donor_guard()
			attempt_before = FreshCaptureExact.stringify(attempts.state())
			if not fresh_candidate.is_empty(): fresh_before = _registration_fresh_guard(fresh_candidate, extra[0])
			if epoch != _registration_epoch or _registration_cancelled: return false
		var prior_error: String = campaign_error
		var raw: Dictionary = _prepare(id, snapshot.equipment_ids, {}, snapshot, true)
		campaign_error = prior_error
		if epoch != _registration_epoch or _registration_cancelled:
			if not raw.is_empty(): _dispose(raw)
			return false
		if raw.is_empty(): continue # Ordinary semantic callback still rejects it.
		var entry: Dictionary = {"validation": _registration_row(raw, wire), "installation": {}}
		_registered_snapshots[wire] = entry
		if wire == install_wire:
			var installation: Dictionary = _prepare(id, snapshot.equipment_ids, {}, snapshot, true)
			campaign_error = prior_error
			if epoch != _registration_epoch or _registration_cancelled:
				if not installation.is_empty(): _dispose(installation)
				return false
			if installation.is_empty():
				_dispose_registration_scope()
				return _fail("Distinct raw install candidate could not be constructed")
			entry.installation = _registration_row(installation, wire)
	if _registered_snapshots.is_empty(): return true
	if donor_before.is_empty() or attempt_before.is_empty() or (not fresh_candidate.is_empty() and fresh_before.is_empty()):
		_dispose_registration_scope()
		return _fail("Bounded paused donor/attempt custody unavailable")
	_registration_pending = true
	var started: int = Time.get_ticks_msec()
	var frame: int = Engine.get_process_frames()
	var tree: SceneTree = get_tree()
	await tree.process_frame
	# A physics-deferred drain can see this iteration's process signal before
	# the Engine process counter advances. Allow only one additional signal.
	# Keep the original total wait bound; full authored guards run once below.
	if is_inside_tree() and epoch == _registration_epoch and not _registration_cancelled and Engine.get_process_frames() == frame:
		if not tree.paused or Time.get_ticks_msec() - started > 2000:
			_registration_pending = false
			_dispose_registration_scope()
			return _fail("Paused registration frame lost bounded donor/disk/native custody")
		await tree.process_frame
	_registration_pending = false
	if not is_inside_tree() or epoch != _registration_epoch or _registration_cancelled:
		_dispose_registration_scope()
		return false
	if not tree.paused or Engine.get_process_frames() <= frame or Time.get_ticks_msec() - started > 2000 or _registration_disk_guard() != disk_before or _registration_donor_guard() != donor_before or FreshCaptureExact.stringify(attempts.state()) != attempt_before:
		_dispose_registration_scope()
		return _fail("Paused registration frame lost bounded donor/disk/native custody")
	if not fresh_candidate.is_empty() and _registration_fresh_guard(fresh_candidate, extra[0]) != fresh_before:
		_dispose_registration_scope()
		return _fail("Fresh entry candidate changed during paused registration")
	_registration_ready = true
	for entry: Dictionary in _registered_snapshots.values():
		for role: String in ["validation", "installation"]:
			var row: Dictionary = entry[role]
			if row.is_empty(): continue
			var error: String = _registration_row_error(row)
			# Unused backup or recoverably bad side rows cannot veto a valid
			# primary. Original semantic callbacks reject only a selected row.
			if not error.is_empty(): _reject_registration_row(row)
	if epoch != _registration_epoch or _registration_cancelled: return false
	return true

func _registered_install_candidate(snapshot: Dictionary) -> Dictionary:
	var wire: String = FreshCaptureExact.stringify(snapshot)
	var entry: Dictionary = _registered_snapshots.get(wire, {})
	if entry.is_empty(): return {}
	var row: Dictionary = entry.get("installation", {})
	if row.is_empty():
		_fail("Exact opted restore target requires its own prepared install candidate")
		return {}
	if _snapshot_validation_busy:
		_fail("Registered install validation cannot reenter a validator")
		return {}
	_snapshot_validation_busy = true
	var candidate: Dictionary = _enter_registered_candidate(snapshot, row)
	var error: String = _registration_error
	if not candidate.is_empty():
		error = candidate.player.snapshot_error(snapshot.player)
		if error.is_empty(): error = candidate.level.snapshot_error_with_player(snapshot.level, snapshot.player)
		if error.is_empty(): error = _shell_state_error(snapshot.shell, snapshot.player)
		if error.is_empty(): error = _registration_row_error(row)
	_snapshot_validation_busy = false
	if not error.is_empty() or candidate.is_empty():
		_reject_registration_row(row)
		_fail(error)
		return {}
	# Transfer before quiet commit. Later synchronous Retry/Store callbacks
	# retain only the separate pristine validation instance, never this one.
	entry.installation = {}
	row.candidate = {}
	return candidate

func _finish_startup_load() -> void:
	var prepared: bool = await _prepare_registration()
	if not is_inside_tree(): return
	if prepared:
		if not attempts.load_saved(): campaign_error = attempts.last_error
		else: campaign_error = attempts.last_warning
	_dispose_validation_candidates()
	_dispose_registration_scope()
	# Startup owns this cancellation; queued operations start a new outcome.
	_registration_cancelled = false
	_draining = false
	menu.show_title()
	if not campaign_error.is_empty(): menu.show_error(campaign_error)
	if not _operations.is_empty():
		_drain_queued = true
		_drain.call_deferred()

func _snapshot_problem(snapshot: Dictionary) -> String:
	if _snapshot_validation_busy or _registration_inflight: return "Whole saved validation cannot reenter registration/validation"
	_snapshot_validation_busy = true
	var error: String = _snapshot_problem_unlocked(snapshot)
	_snapshot_validation_busy = false
	return error


func _startup_registration_required() -> bool:
	# Capability hooks are pure, but reentrant callbacks still fail closed.
	_registration_inflight = true
	var required: bool = _startup_registration_required_unlocked()
	_registration_inflight = false
	return required

func _startup_registration_required_unlocked() -> bool:
	var discovery: CinderSaveStore = Store.new(_save_path)
	for path: String in [_save_path, _save_path + ".bak"]:
		var envelope: Dictionary = discovery._read_file(path)
		if envelope.is_empty(): continue
		for snapshot: Dictionary in _registration_packets(envelope.payload):
			if not snapshot.get("level_id") is String or not registry.scene_error(snapshot.level_id).is_empty(): continue
			var probe: Node = (load(registry.entry(snapshot.level_id).scene_path) as PackedScene).instantiate()
			var opted: bool = probe is CinderLevel and (probe as CinderLevel).restore_candidate_physics_registration_required()
			if is_instance_valid(probe): probe.free()
			if opted: return true
	return false

func _registration_fresh_guard(candidate: Dictionary, snapshot: Dictionary) -> String:
	# Pure re-observation: never refit, restore, normalize or replace the packet.
	if not _fresh_capture_binding_error(candidate).is_empty(): return ""
	var original_bindings: Dictionary = candidate.duplicate()
	var original_scripts: Array = [candidate.level.get_script(), candidate.player.get_script(), candidate.fx.get_script()]
	if FreshCaptureExact.stringify(candidate.player.snapshot_state()) != FreshCaptureExact.stringify(snapshot.player): return ""
	var pixels: Vector2 = hud.get_viewport().get_visible_rect().size
	if not pixels.is_finite() or pixels.x < 1.0 or pixels.y < 1.0 or pixels.x > 16384.0 or pixels.y > 16384.0 or Vector2(Vector2i(pixels)) != pixels: return ""
	var view := SubViewport.new()
	view.size = Vector2i(pixels)
	view.disable_3d = true
	view.handle_input_locally = false
	view.gui_disable_input = true
	view.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(view)
	var actual_hud: GameHUD = HUDScript.new()
	actual_hud.visible = false
	view.add_child(actual_hud)
	actual_hud.set_campaign_mode()
	actual_hud.hide_overlay()
	actual_hud.update_status(candidate.player.hp, candidate.player.max_hp, candidate.player.shells, candidate.player.max_shells, 0, candidate.level.objective_text)
	var local: Dictionary = candidate.level.snapshot_state_for_presentation(candidate.camera, actual_hud)
	var safe: String = _fresh_capture_hud_wire(actual_hud)
	var points: Array = candidate.level.camera_framing_points()
	var framing_error: String = candidate.level.last_camera_framing_error
	var mandatory: Array = player_camera_framing_points_for(candidate.player, candidate.camera)
	if framing_error.is_empty(): framing_error = camera_framing_error_for_context(points if not points.is_empty() else mandatory, candidate.player, candidate.camera, actual_hud)
	view.free()
	if not _fresh_capture_binding_error(candidate).is_empty(): return ""
	for key: String in original_bindings:
		if candidate[key] != original_bindings[key]: return ""
	if [candidate.level.get_script(), candidate.player.get_script(), candidate.fx.get_script()] != original_scripts: return ""
	if not framing_error.is_empty() or local.is_empty() or FreshCaptureExact.stringify(local) != FreshCaptureExact.stringify(snapshot.level) or safe.is_empty(): return ""
	var identities: Array = []
	for key: String in ["container", "viewport", "stage", "camera", "level", "player", "fx"]: identities.append(str(candidate[key].get_instance_id()))
	return var_to_bytes([identities, candidate.camera.global_transform, candidate.camera.projection, candidate.camera.size, candidate.camera.keep_aspect, candidate.camera.current, candidate.viewport.size, candidate.stage.get_world_3d().get_instance_id(), _registration_floor_guard(candidate), safe, points, mandatory, FreshCaptureExact.stringify(local), FreshCaptureExact.stringify(candidate.player.snapshot_state())]).hex_encode()
